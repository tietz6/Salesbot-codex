def handle(text:str)->str:
    return 'Подскажите, как вы познакомились и сколько вы вместе? '