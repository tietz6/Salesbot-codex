
from typing import Dict, List
from . import rules

class StageContext:
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.stage = "greeting"
        self.history: List[Dict] = []
        self.scores: Dict[str, int] = {}

class StageManager:
    def __init__(self, storage=None):
        self.storage = storage  # optional external state store

    def snapshot(self, ctx: StageContext) -> Dict:
        return {
            "session_id": ctx.session_id,
            "stage": ctx.stage,
            "scores": ctx.scores,
            "turns": len(ctx.history),
            "history_tail": ctx.history[-6:],
        }

    def apply(self, ctx: StageContext, user_text: str) -> Dict:
        # record manager utterance
        ctx.history.append({"role": "manager", "content": user_text, "stage": ctx.stage})
        # score
        sc = rules.score_snippet(user_text, ctx.stage)
        ctx.scores[ctx.stage] = max(sc, ctx.scores.get(ctx.stage, 0))
        # transition deterministically forward
        guessed = rules.guess_stage(user_text, ctx.stage)
        if guessed == ctx.stage:
            ctx.stage = rules.next_stage(ctx.stage)
        else:
            ctx.stage = guessed
        return {"ok": True, "stage": ctx.stage, "score": sc}
