
from __future__ import annotations
import os, json
from typing import Dict, Any, Optional
from .storage import create_session, load_state, save_state

def _load_json(name: str) -> dict:
    path = os.path.join(os.path.dirname(__file__), "data", name)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

CFG = _load_json("config.json")
KW  = _load_json("keywords.json")

class MultiDemoEngine:
    def start(self, manager_id: str, sid: str | None = None) -> dict:
        if not sid:
            sid = create_session(manager_id)
        state = load_state(sid)
        return {"ok": True, "sid": sid, "state": state["state"]}

    def attach_demo(self, sid: str, label: str, url_or_note: str) -> dict:
        st = load_state(sid)
        if not st: return {"ok": False, "error": "session_not_found"}
        label = label.strip().upper()
        if label not in ("A","B"): return {"ok": False, "error": "bad_label"}
        st["state"]["demos"][label] = url_or_note
        st["history"].append({"type": "demo_attach", "label": label, "value": url_or_note})
        save_state(sid, st)
        return {"ok": True, "attached": label}

    def react(self, sid: str, client_text: str) -> dict:
        st = load_state(sid)
        if not st: return {"ok": False, "error": "session_not_found"}
        t = (client_text or "").lower()
        pref = None
        if any(k in t for k in KW["prefer_a"]): pref = "A"
        if any(k in t for k in KW["prefer_b"]): pref = "B"
        if any(k in t for k in KW["price"]):
            offer = self._ladder_offer()
            reply = f"Понимаю важность бюджета. {offer}"
            st["state"]["offers"].append({"type":"ladder_2to4"})
            st["state"]["score"] += 4
        elif any(k in t for k in KW["video"]):
            offer = self._video_offer()
            reply = f"Сделаем красиво: {offer}"
            st["state"]["offers"].append({"type":"video_bundle"})
            st["state"]["score"] += 6
        elif pref in ("A","B"):
            st["state"]["selection"] = pref
            offer = self._second_version_offer(pref)
            reply = f"Принято, берём вариант {pref}. {offer}"
            st["state"]["offers"].append({"type":"take_two_versions", "picked": pref})
            st["state"]["score"] += 8
        elif any(k in t for k in KW["like"]):
            offer = self._two_versions_discount()
            reply = f"Супер, чувствую отклик. {offer}"
            st["state"]["offers"].append({"type":"two_versions_discount"})
            st["state"]["score"] += 7
        elif any(k in t for k in KW["unsure"]):
            reply = "Понимаю сомнения. Давайте сделаю мини-сравнение A/B в двух фразах и подскажу, что лучше под ваш повод?"
            st["state"]["score"] += 3
        else:
            reply = "Могу подсветить разницу A vs B по настроению и вокалу. Какой настрой ближе — романтика или кинематографичность?"
        st["history"].append({"type":"client_react","text":client_text,"reply":reply})
        save_state(sid, st)
        return {"ok": True, "reply": reply, "state": st["state"]}

    def _two_versions_discount(self) -> str:
        p = CFG["offer"]["two_versions_discount_percent"]
        return f"Часто берут обе версии — сделаем {p}% на вторую, чтобы можно было чередовать эмоции."
    def _second_version_offer(self, picked: str) -> str:
        other = "B" if picked=="A" else "A"
        p = CFG["offer"]["two_versions_discount_percent"]
        return f"Предлагаю взять и {other} как вторую версию со скидкой {p}% — разные настроения на разные дни."
    def _ladder_offer(self) -> str:
        L = CFG["offer"]["ladder_2_to_4"]
        if not L.get("enabled"): return "Сейчас выгодных акций нет."
        add = L["third_add_price_kgs"]
        copy = L["copy"]
        return f"{copy} Добавив третью — всего +{add} сом."
    def _video_offer(self) -> str:
        V = CFG["offer"]["video_bundle"]
        if not V.get("enabled"): return "Видео-пакет сейчас недоступен."
        return f"{V['copy']} {V['benefit']}"
