# extra simulator logic
