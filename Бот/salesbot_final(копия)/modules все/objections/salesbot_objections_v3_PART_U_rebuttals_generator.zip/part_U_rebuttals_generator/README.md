# Dynamic Rebuttals Generator
Part **U** · objections/v3

Генерация живых контраргументов и микро-обоснований ценности (LLM).

## How it works
- `routes.py` exposes fastapi routes under `/objections/v3/part_U_rebuttals_generator`
- `service.py` hosts orchestration and calls LLM through `deepllm.py`
- `prompts/` houses system/assistant/user templates
- `data/` contains seed dialogues (jsonl) and eval checks
- `tests/` has smoke tests for routing & generation

## Env
- `DEEPSEEK_API_KEY` required (read from `os.environ`).