# Package X — Knowledge & Patterns & Tips
- x_knowledge_base/*_snippets.json — 2000 фраз на язык (RU/KY/EN)
- x_pattern_mining/* — майнинг паттернов и шаблоны советов
- x_auto_tips/tips_*.json — авто‑советы по типовым ошибкам (3 языка)
- x_localization/strings_*.json — лейблы этапов и UI‑строки
