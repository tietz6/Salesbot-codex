
try:
    from integrations.patch_v4.env import get_env
except Exception:  # shim or bare
    def get_env(name, default=None, cast=str):
        import os
        val = os.environ.get(name, None)
        if val is None: 
            return default
        try:
            return cast(val)
        except Exception:
            return val

DEEPSEEK_ROLE = get_env("DEEPSEEK_ROLE", "coach", str)
GLUE_TIMEOUT = get_env("GLUE_TIMEOUT", 8.0, float)
ENABLE_PSYCOTYPES = bool(int(get_env("ARENA_ENABLE_PSYCOTYPES", 1, int)))
ENABLE_PERSONA = bool(int(get_env("ARENA_ENABLE_PERSONA", 1, int)))
ENABLE_RUBRICS = bool(int(get_env("ARENA_ENABLE_RUBRICS", 1, int)))
ENABLE_DRAGON = bool(int(get_env("ARENA_ENABLE_DRAGON", 1, int)))
ENABLE_OBJECTIONS = bool(int(get_env("ARENA_ENABLE_OBJECTIONS", 1, int)))
ENABLE_UPSELL = bool(int(get_env("ARENA_ENABLE_UPSELL", 1, int)))
