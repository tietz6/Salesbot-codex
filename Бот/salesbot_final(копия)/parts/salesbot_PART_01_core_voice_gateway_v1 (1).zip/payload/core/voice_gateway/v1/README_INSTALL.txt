
Place this into salesbot/core/voice_gateway/v1
Requirements (choose):
  - assemblyai (pip install assemblyai) for ASR
  - pyttsx3 for offline TTS (pip install pyttsx3)
Env:
  DEEPSEEK_API_KEY=...
  ASSEMBLYAI_API_KEY=...
  TTS_PROVIDER=pyttsx3
