Arena Runtime Core v1
---------------------------------
Назначение: минимальный рабочий слой Арены.
Подключение: ADD_ONLY, автосборщик подхватит по manifest.json
Маршруты: /arena/v1/*

Зависимости (мягкие):
- core.voice_gateway.v1 (VoicePipeline) — если нет, будет fallback.
- modules.deepseek_persona.v1 — если нет, обычный тёплый стиль.
- core.state.v1 (StateStore) — если нет, временные JSON-файлы.
- Контент из modules/arena/v1 (personas, scenarios, language_kits, rubrics, datasets)

Проверка: GET /arena/v1/health
