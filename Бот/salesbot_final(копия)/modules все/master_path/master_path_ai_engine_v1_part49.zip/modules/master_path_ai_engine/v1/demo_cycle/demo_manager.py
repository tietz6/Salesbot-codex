
# demo_cycle/demo_manager.py
from __future__ import annotations
import json
from pathlib import Path

class DemoCycle:
    def __init__(self, transitions_path: str):
        self.transitions = json.loads(Path(transitions_path).read_text(encoding="utf-8"))

    def next(self, state: dict) -> dict:
        step = state.get("step","init")
        table = self.transitions.get("graph",{})
        out = table.get(step, {}).get(state.get("reaction","neutral"), table.get(step, {}).get("neutral"))
        return {"next_step": out or "finish"}

    def ab_payload(self, text_a: str, text_b: str) -> dict:
        return {
            "demos":[
                {"id":"A","length_sec":45,"text":text_a},
                {"id":"B","length_sec":45,"text":text_b}
            ],
            "note":"Отправьте оба варианта. Предложите оставить оба со скидкой."
        }
