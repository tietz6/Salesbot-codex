
def _fallback_offer(tier:str="premium"):
    return {"tier": tier, "currency":"KGS", "total": 4500, "savings": "Экономия ~500 сом", "pitch": "Добавим второй жанр со скидкой, чтобы было два настроения 🎧"}
try:
    from modules.upsell_pricing_glue.v1 import compute_offer, suggest_upsell
    def make_offer(catalog=None, tier="premium", currency="KGS", discount=0.1, coupon=None, vat=0.12):
        try:
            return compute_offer(catalog, tier, currency, discount, coupon, vat)
        except Exception:
            return _fallback_offer(tier)
    def make_pitch(catalog=None, current_tier="basic", target_tier="premium", currency="KGS", discount=0.1, coupon=None, vat=0.12, context=""):
        try:
            return suggest_upsell(catalog, current_tier, target_tier, currency, discount, coupon, vat, context)
        except Exception:
            off = _fallback_offer(target_tier)
            off["pitch"] = "Разница заметная по эмоциям, а по цене — мягко. Готов отправить сравнение?"
            return off
except Exception:
    make_offer = lambda *a, **k: _fallback_offer(k.get("tier","premium"))
    def make_pitch(*a, **k):
        return _fallback_offer(k.get("target_tier","premium"))
