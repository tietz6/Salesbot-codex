
from typing import Dict, Any, Optional
from .engine import ArenaEngine

_engine: Optional[ArenaEngine] = None

def get_engine() -> ArenaEngine:
    global _engine
    if _engine is None:
        _engine = ArenaEngine(db_path="salesbot.db")
    return _engine

def start(manager_id: str, context: Optional[str]=None) -> Dict[str, Any]:
    return get_engine().start(manager_id, context)

def step(sid: str, text: str) -> Dict[str, Any]:
    return get_engine().step(sid, text)

def stop(sid: str) -> Dict[str, Any]:
    return get_engine().stop(sid)

def snapshot(sid: str) -> Dict[str, Any]:
    return get_engine().snapshot(sid)
