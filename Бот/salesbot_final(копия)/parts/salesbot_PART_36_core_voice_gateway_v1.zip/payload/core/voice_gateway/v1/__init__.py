from .pipeline import VoicePipeline
__all__=['VoicePipeline']
