
import json, os
P = os.path.join(os.path.dirname(__file__), 'persona_rules.json')
try:
    RULES = json.load(open(P,'r',encoding='utf-8'))
except Exception:
    RULES = {'prefix':'','suffix':'','emoji':'🌿'}
def apply_brand(text:str)->str:
    return f"{RULES.get('prefix','')}{text} {RULES.get('emoji','')} {RULES.get('suffix','')}".strip()
