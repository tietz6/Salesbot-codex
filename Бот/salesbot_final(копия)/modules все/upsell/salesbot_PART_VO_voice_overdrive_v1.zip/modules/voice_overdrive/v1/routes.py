from fastapi import APIRouter, Body
from typing import Optional, Dict, Any
from .engine import create_session, tune_session, VoiceOverdriveSession

router = APIRouter(prefix="/voice_overdrive/v1", tags=["voice_overdrive"])

@router.get("/health")
def health():
    return {"ok": True, "service": "voice_overdrive", "v": 1}

@router.post("/start")
def start(payload: Dict[str, Any] = Body(...)):
    manager_id = str(payload.get("manager_id","unknown"))
    context = str(payload.get("context",""))
    sid = create_session(manager_id, context=context)
    return {"ok": True, "session_id": sid}

@router.post("/tune")
def tune(payload: Dict[str, Any] = Body(...)):
    sid = str(payload.get("session_id",""))
    params = payload.get("params",{})
    return tune_session(sid, params or {})

@router.post("/step")
def step(payload: Dict[str, Any] = Body(...)):
    sid = str(payload.get("session_id",""))
    manager_text = str(payload.get("text","")).strip()
    features = payload.get("features",{}) or {}
    sess = VoiceOverdriveSession.load(sid)
    if not sess:
        return {"ok": False, "error": "session_not_found"}
    res = sess.step(manager_text, features=features)
    return {"ok": True, **res}

@router.get("/stop/{session_id}")
def stop(session_id: str):
    sess = VoiceOverdriveSession.load(session_id)
    if not sess:
        return {"ok": False, "error": "session_not_found"}
    history = sess.state.get("history", [])
    # simple wrap-up score
    turns = max(1, len([h for h in history if h.get("role")=="manager"]))
    avg_clarity = sum(h.get("metrics",{}).get("clarity",0.5) for h in history if h.get("role")=="manager")/turns
    avg_empathy = sum(h.get("metrics",{}).get("empathy",0.5) for h in history if h.get("role")=="manager")/turns
    score = round((avg_clarity*0.6 + avg_empathy*0.4) * 100)
    return {"ok": True, "score": score, "turns": turns, "last_emotion": sess.state.get("emotion")}
