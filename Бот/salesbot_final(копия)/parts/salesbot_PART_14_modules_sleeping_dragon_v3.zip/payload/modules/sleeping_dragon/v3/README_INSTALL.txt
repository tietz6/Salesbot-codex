
Sleeping Dragon v3
Diagnostic engine for detecting manager mistakes:
  - Detects missing qualification
  - Detects broken client flow
  - Detects incorrect tone usage
  - Gives LLM-based feedback + rule-based scan
