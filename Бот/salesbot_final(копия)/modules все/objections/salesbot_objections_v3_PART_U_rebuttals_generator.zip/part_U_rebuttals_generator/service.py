from fastapi import HTTPException
from .api.deepllm import DeepLLM
import yaml, json, os, pathlib

pkg_dir = pathlib.Path(__file__).parent
cfg = yaml.safe_load((pkg_dir / "config.yaml").read_text(encoding="utf-8"))

def run(context: str, utterance: str) -> dict:
    try:
        llm = DeepLLM()
        sys_prompt = (pkg_dir / "prompts" / "system.md").read_text(encoding="utf-8")
        user_tmpl = (pkg_dir / "prompts" / "user_template.md").read_text(encoding="utf-8")
        user = user_tmpl.replace("{context}", context).replace("{utterance}", utterance)
        resp = llm.chat([
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user},
        ], **cfg.get("llm", {}))
        if not resp.get("ok"):
            raise RuntimeError("LLM error")
        return {
            "part": "U",
            "module": "part_U_rebuttals_generator",
            "answer": resp["message"],
            "usage": resp.get("usage", {})
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))