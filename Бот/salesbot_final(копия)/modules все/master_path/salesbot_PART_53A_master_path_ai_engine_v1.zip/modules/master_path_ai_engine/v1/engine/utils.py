
import time, re, uuid
def now_ms(): return int(time.time()*1000)
def new_sid(prefix='mp'): return f"{prefix}-" + uuid.uuid4().hex[:12]
def has_question(text:str)->bool: return '?' in text
def is_aggressive(text:str)->bool: return bool(re.search(r"\b(дурак|чушь|бред|нах)\b", text.lower()))
