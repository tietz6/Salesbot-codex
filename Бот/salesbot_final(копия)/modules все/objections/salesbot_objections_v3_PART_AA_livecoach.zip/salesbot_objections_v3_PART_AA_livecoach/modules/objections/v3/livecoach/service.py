
import asyncio, os, json
from .schema import CoachRequest, CoachResponse

class LiveCoachService:
    def __init__(self):
        # place where DeepSeek/API keys are read; kept flexible
        self.model = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
        self.api_key = os.getenv("DEEPSEEK_API_KEY", "")

    async def coach(self, module_slug: str, payload: CoachRequest) -> CoachResponse:
        # Here we'd call DeepSeek; to keep module runnable offline,
        # we simulate a structured response that downstream UI can render.
        tips = [
            "Поприсоединяйтесь к чувствам клиента, перефразируйте возражение.",
            "Спросите уточняющий вопрос, чтобы выявить истинную причину.",
            "Предложите микро-выбор из 2 вариантов, подтвердите выгоду."
        ]
        plan = [
            {"step": 1, "say": "Понимаю, цена важна. Давайте разберёмся, за что вы платите."},
            {"step": 2, "say": "Что для вас важнее: скорость или индивидуальность текста?"},
            {"step": 3, "say": "Могу показать примеры и сделать демо в 2 вариантах."}
        ]
        return CoachResponse(
            trace_id=f"{module_slug}-trace",
            module=module_slug,
            next_utterance=f"Давайте сделаем демо в 2-х вариантах и выберем ближе по эмоциям?",
            rationale="Снимаем напряжение: признание + уточнение + альтернатива",
            micro_tips=tips,
            plan=plan
        )

_svc = LiveCoachService()
def get_service():
    return _svc
