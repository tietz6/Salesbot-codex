
from __future__ import annotations
import os, json
from typing import Dict, Any

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def _load(name: str) -> dict:
    with open(os.path.join(DATA_DIR, name), "r", encoding="utf-8") as f:
        return json.load(f)

PERSONA = _load("persona.json")
TPL = _load("templates.json")

def _join(lines):
    return " ".join([s.strip() for s in lines if s and s.strip()])

def suggest(stage: str, context: Dict[str, Any] | None = None):
    ctx = context or {}
    s = (stage or "").strip().lower()
    blocks = []

    if s == "pre_texts":
        blocks += TPL["pre_texts"]
    elif s == "after_texts":
        blocks += TPL["after_texts"]
    elif s == "ladder":
        add = ctx.get("third_add_price_kgs", 1000)
        blocks += [TPL["ladder2to4_intro"][0], TPL["ladder2to4_intro"][1].format(third_add_price_kgs=add)]
    elif s == "video_bundle":
        blocks += TPL["video_bundle"]
    elif s == "answer_price":
        percent = ctx.get("discount_percent", 20)
        blocks += [line.format(discount_percent=percent) for line in TPL["answers"]["price"]]
    elif s == "answer_why_more":
        blocks += TPL["answers"]["why_more"]
    elif s == "answer_think_later":
        blocks += TPL["answers"]["think_later"]
    else:
        blocks = ["Могу предложить мягкий путь: две версии демо со скидкой на вторую, затем акция 2→4 и, при желании, пакет «Песня + Видео 9:16». Если откликается — начнём?"]

    outro = " Если откликается — начнём?"
    text = _join(blocks) + outro
    return {"ok": True, "stage": s, "persona": PERSONA["tone"]["upsell"], "text": text}
