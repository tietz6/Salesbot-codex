
import json, os, time
from .dialog_state import DialogState
from .pipeline import DeepSeekPipeline
from ..stage_manager.manager import StageManager
from ..heuristics.analyzer import score_reply

class MasterPathEngine:
    def __init__(self):
        self.sessions = {}
        self.pipeline = DeepSeekPipeline()
        self.stage_mgr = StageManager()

    def start_session(self, sid: str):
        self.sessions[sid] = DialogState(sid=sid)
        self.sessions[sid].set_stage("greeting")

    def handle(self, sid: str, text: str):
        st = self.sessions.setdefault(sid, DialogState(sid=sid))
        st.append("manager", text)

        # stage decision
        next_stage = self.stage_mgr.next_stage(st.stage, text)
        if next_stage:
            st.set_stage(next_stage)

        # persona-aware client reply (LLM or fallback)
        sys_prompt = self.stage_mgr.system_prompt(st.stage)
        reply = self.pipeline.chat(system=sys_prompt, history=st.history)

        st.append("client", reply)
        score = score_reply(text, stage=st.stage)

        coach_note = self.pipeline.coach_suggest(stage=st.stage, manager_text=text)

        return {
            "ok": True,
            "sid": sid,
            "stage": st.stage,
            "client_reply": reply,
            "coach_suggestion": coach_note,
            "score": score,
            "history_tail": st.history[-6:]
        }

    def snapshot(self, sid: str):
        st = self.sessions.get(sid)
        if not st:
            return {"ok": False, "error": "no_session"}
        return {"ok": True, "sid": sid, "stage": st.stage, "history": st.history}

    def reset(self, sid: str):
        self.sessions.pop(sid, None)
