# Sleeping Dragon — PART E: Error Detection
Содержимое:
- rules.json — 40 правил с примерами и подсказками (RU/KY/EN)
- penalty_matrix.json — множители штрафов по этапам
- samples/tagged_samples.json — 50 примеров с размеченными ошибками

Использование:
- Читай `rules.json` в свой rule-engine (без кода)
- Применяй множители из `penalty_matrix.json` по этапу
- Тестируй на `samples/tagged_samples.json`
