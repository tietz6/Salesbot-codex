Upsell Session Orchestrator v1
-----------------------------------
Задача: связать весь апсейл в единую линию (warmup → texts → demos → ladder 2→4 → payment_offer → done),
вести историю, генерировать мягкие ответы клиента (через deepseek_persona), считать цену (через upsell_pricing_recommender),
и формировать финальный отчёт + запись в dialog_memory.

API:
  GET  /upsell_session/v1/health
  POST /upsell_session/v1/start          {manager_id, context?}
  GET  /upsell_session/v1/status/{sid}
  POST /upsell_session/v1/step           {session_id, manager_id, step, text}
  POST /upsell_session/v1/offer          {session_id, manager_id, tier, currency, discount}
  POST /upsell_session/v1/finalize       {session_id, manager_id}

UI:
  GET /upsell_session/v1/ui/{manager_id}/{sid}?sid=<sid>&manager_id=<mid>
