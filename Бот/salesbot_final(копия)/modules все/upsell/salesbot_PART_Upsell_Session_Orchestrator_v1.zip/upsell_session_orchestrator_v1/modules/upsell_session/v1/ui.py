
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import os

templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))
router = APIRouter(prefix="/upsell_session/v1/ui", tags=["upsell_session_ui"])

@router.get("/{manager_id}/{sid}", response_class=HTMLResponse)
def ui_panel(request: Request, manager_id: str, sid: str):
    return templates.TemplateResponse("ui.html", {"request": request})
