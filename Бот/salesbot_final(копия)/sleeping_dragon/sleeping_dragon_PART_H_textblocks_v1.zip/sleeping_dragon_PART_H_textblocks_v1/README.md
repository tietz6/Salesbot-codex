Textblocks for Sleeping Dragon
