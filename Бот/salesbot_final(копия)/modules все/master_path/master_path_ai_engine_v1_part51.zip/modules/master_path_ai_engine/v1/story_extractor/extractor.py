
from __future__ import annotations
import re, json
from pathlib import Path
from typing import Dict, List

KEYS = {
    "names": [r"(?:зовут|имя)\s+([A-ЯЁA-Z][а-яёa-z]+)"],
    "dates": [r"(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})"],
    "children": [r"(?:дет(?:и|ок)|сын|дочь)\s*[:,-]?\s*(.+)"],
    "meeting": [r"(?:познакомил[ась|ись]|встретил[ась|ись])\s*(.+)"],
    "pets": [r"(?:кот|кошка|пёс|собака|питомец)\s*(?:по имени)?\s*([A-ЯЁA-Z][а-яёa-z]+)"],
    "moments": [r"(?:запомнил[ось|ся]|момент|история)\s*[:,-]?\s*(.+)"]
}

def extract(text: str, patterns_path: str) -> Dict:
    patterns = json.loads(Path(patterns_path).read_text(encoding="utf-8"))
    out = { "names":[], "dates":[], "children":[], "meeting":[], "pets":[], "moments":[] }
    for key, regs in {**KEYS, **patterns.get("extra",{})}.items():
        vals: List[str] = []
        for rgx in regs:
            for m in re.finditer(rgx, text, flags=re.IGNORECASE|re.DOTALL):
                vals.append(" ".join(g for g in m.groups() if g))
        if vals:
            out[key] = list(dict.fromkeys([v.strip() for v in vals if v.strip()]))
    out["raw_len"] = len(text)
    return out
