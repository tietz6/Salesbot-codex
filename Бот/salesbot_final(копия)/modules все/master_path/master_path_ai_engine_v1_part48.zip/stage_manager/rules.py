
RULES = {
 "greeting": {"must":["привет","добрый","здравствуйте"], "penalty":1},
 "qualification": {"must":["как","кто","сколько"], "penalty":2},
 "payment": {"must":["оплата","предоплата","к оплате"], "penalty":2},
 "finish": {"must":["спасибо","подарок","готово"], "penalty":1}
}
