PART 53-K — payment_flow

Папка: modules/master_path_ai_engine/v1/payment_flow/

Назначение
----------
Единый поток оплаты внутри ПУТИ МАСТЕРА:
- запрос удобного способа (предоплата/полная),
- создание инвойса через payments/v2 (если доступен) или локальный fallback,
- отслеживание статуса (waiting_payment → paid/failed),
- запись таймлайна в KV.

Интеграции
----------
1) Предпочтительно: modules/payments/v2 (API):
   - POST /payments/v2/invoice/{deal_id}
   - POST /payments/v2/webhook
   - GET  /payments/v2/status/{deal_id}

2) Fallback: локальное хранилище KV + имитация статуса.

Пример
------
from modules.master_path_ai_engine.v1.payment_flow.engine import PaymentFlow

pf = PaymentFlow(state_store)
sid = "session-123"
pf.start(sid, deal_id="D-1001", amount=1500, currency="KGS")
res = pf.create_invoice(sid)      # -> redirect_url / payment_id
st = pf.status(sid)               # -> waiting_payment/paid/failed
