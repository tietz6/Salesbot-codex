
import os, asyncio, json, re
from .schema import *

class ObjectionsService:
    def __init__(self):
        self.api_key = os.getenv("DEEPSEEK_API_KEY", "")

    async def coach(self, module_slug: str, payload: CoachRequest) -> CoachResponse:
        tips = [
            "Присоединиться к эмоции клиента.",
            "Сформулировать уточняющий вопрос.",
            "Дать мини-альтернативу и мягкое CTA."
        ]
        plan = [
            {"step":1,"say":"Понимаю, важна ценность. Давайте коротко сверим ожидания."},
            {"step":2,"say":"Сделаю два варианта — выберем ближе к вашему настроению."},
            {"step":3,"say":"Далее пришлю демо и перейдём к оплате удобным способом."},
        ]
        next_line = "Могу показать 2 демо в разных настроениях и вы выберете ближе по сердцу?"
        return CoachResponse(
            trace_id=f"{module_slug}-trace",
            module=module_slug,
            next_utterance=next_line,
            rationale="Признание ценности + вопрос + альтернатива + CTA.",
            micro_tips=tips,
            plan=plan,
        )

    async def analyze(self, module_slug: str, payload: AnalysisRequest) -> AnalysisResponse:
        p = payload.utterance.strip().lower()
        penalties = []
        if len(p) < 4:
            penalties.append("too_short")
        if not re.search(r"[?]", p):
            penalties.append("no_question")
        if re.search(r"[!]{2,}|[?]{2,}", p):
            penalties.append("many_punct")
        score = max(0, 10 - len(penalties)*2)
        advice = "Добавьте уточняющий вопрос и мягкий следующий шаг."
        return AnalysisResponse(ok=True, module=module_slug, penalties=penalties, score=score, advice=advice)

_svc = ObjectionsService()
def get_service():
    return _svc
