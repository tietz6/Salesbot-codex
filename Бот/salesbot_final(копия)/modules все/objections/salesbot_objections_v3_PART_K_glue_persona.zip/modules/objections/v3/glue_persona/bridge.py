
try:
    from modules.deepseek_persona.v1 import persona_chat
except Exception:
    def persona_chat(prompt:str, role:str="client_emotional"):
        # мягкий fallback без внешних вызовов
        return f"[{role}] " + (prompt or "Давайте аккуратно продолжим. ")

def client_reply(context:str)->str:
    prompt = "Ты — клиент бренда. Ответь натурально и кратко: " + (context or "")
    return persona_chat(prompt, role="client_emotional")

def coach_hint(context:str)->str:
    prompt = "Ты — коуч бренда. Дай тёплый и точный совет менеджеру: " + (context or "")
    return persona_chat(prompt, role="coach")
