# Package H — Full Rule Engine & Patterns
- rules/full_rule_engine.json — 900 правил
- patterns/negative.json — 300 негативных паттернов
- patterns/positive.json — 300 позитивных паттернов
- empathy/empathy_rules.json — 70 правил
- story/story_patterns.json — 70 правил
- scoring/penalty_matrix.json + formulas.json
