from fastapi import APIRouter
from pydantic import BaseModel
from .service import run

router = APIRouter(prefix="/objections/v3/part_U_rebuttals_generator", tags=["objections/v3/part_U_rebuttals_generator"])

class Inp(BaseModel):
    context: str = ""
    utterance: str

@router.post("/run")
def _run(inp: Inp):
    return run(inp.context, inp.utterance)