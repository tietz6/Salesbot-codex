
"""
Lightweight heuristic analyzer for Master Path turns.
Produces per-turn metrics and an aggregate score.
"""
import re
from typing import Dict, List

DEFAULT_WEIGHTS = {
    "greeting": {"warmth": 0.35, "empathy": 0.25, "clarity": 0.20, "questions": 0.20},
    "qualification": {"warmth": 0.20, "empathy": 0.20, "clarity": 0.20, "questions": 0.40},
    "warmup": {"warmth": 0.30, "empathy": 0.30, "clarity": 0.20, "questions": 0.20},
    "texts": {"warmth": 0.25, "empathy": 0.20, "clarity": 0.35, "questions": 0.20},
    "genre": {"warmth": 0.20, "empathy": 0.15, "clarity": 0.35, "questions": 0.30},
    "payment": {"warmth": 0.20, "empathy": 0.15, "clarity": 0.35, "payment_readiness": 0.30},
    "demo_cycle": {"warmth": 0.25, "empathy": 0.15, "clarity": 0.30, "upsell": 0.30},
    "finish": {"warmth": 0.30, "empathy": 0.25, "clarity": 0.25, "cta": 0.20}
}

KEYSETS = {
    "warmth": ["спасибо", "буду рада", "с теплом", "приятно", "серд", "🥰", "🌸", "💛"],
    "empathy": ["понимаю", "здорово", "трогательно", "красиво", "бережно", "важно", "эмоци"],
    "clarity": ["сделаем", "готово", "отправлю", "получите", "будет", "срок", "формат", "полная версия"],
    "questions": ["как", "кто", "когда", "где", "кому", "сколько", "почему"],
    "payment_readiness": ["оплат", "перевод", "к оплате", "предоплат", "реквизит"],
    "upsell": ["второй", "оба", "пакет", "скид", "в подарок", "2 демо", "два демо", "песня + видео"],
    "cta": ["давайте", "начинаем", "приступаем", "готовы", "хотите", "предлагаю"]
}

NEGATIVES = {
    "aggressive": ["срочно", "быстрее", "давайте уже", "ну что", "обязаны"],
    "many_punct": r"[!?]{3,}",
    "too_short": r"^.{0,8}$"
}

def _score_presence(text: str, keys: List[str]) -> float:
    t = text.lower()
    hit = 0
    for k in keys:
        if k in t:
            hit += 1
    # normalize: >=2 hits -> full
    return min(1.0, hit / 2.0)

def _penalties(text: str) -> Dict[str, int]:
    t = text.strip()
    p = {}
    if re.search(NEGATIVES["many_punct"], t):
        p["many_punct"] = 1
    if re.search(NEGATIVES["too_short"], t, flags=re.DOTALL):
        p["too_short"] = 2
    if any(w in t.lower() for w in NEGATIVES["aggressive"]):
        p["aggressive"] = 2
    return p

def analyze_turn(text: str, stage: str, weights: Dict[str, Dict[str, float]] = None) -> Dict:
    """Return metric scores 0..1 and aggregate 0..100 with issues list."""
    weights = weights or DEFAULT_WEIGHTS
    wmap = weights.get(stage, {})
    metrics = {}
    metrics["warmth"] = _score_presence(text, KEYSETS["warmth"])
    metrics["empathy"] = _score_presence(text, KEYSETS["empathy"])
    metrics["clarity"] = _score_presence(text, KEYSETS["clarity"])
    metrics["questions"] = _score_presence(text, KEYSETS["questions"])
    metrics["payment_readiness"] = _score_presence(text, KEYSETS["payment_readiness"])
    metrics["upsell"] = _score_presence(text, KEYSETS["upsell"])
    metrics["cta"] = _score_presence(text, KEYSETS["cta"])

    # weighted sum -> 0..100
    agg = 0.0
    total_w = 0.0
    for k, w in wmap.items():
        agg += metrics.get(k, 0.0) * w
        total_w += w
    agg = (agg / total_w) * 100.0 if total_w > 0 else 0.0

    # apply penalties
    pens = _penalties(text)
    penalty_points = 0
    if "many_punct" in pens:
        penalty_points += 5
    if "too_short" in pens:
        penalty_points += 10
    if "aggressive" in pens:
        penalty_points += 15
    final = max(0, round(agg - penalty_points, 2))

    issues = []
    for k, w in sorted(wmap.items(), key=lambda x: -x[1]):
        if metrics.get(k, 0.0) < 0.5:
            issues.append(f"Низкий показатель «{k}» для этапа «{stage}».")
    for k in pens:
        if k == "many_punct":
            issues.append("Слишком много восклицаний/вопросительных знаков.")
        if k == "too_short":
            issues.append("Реплика слишком короткая.")
        if k == "aggressive":
            issues.append("Тон грубоват/давящий — смягчить.")

    return {
        "stage": stage,
        "metrics": metrics,
        "weighted": round(agg, 2),
        "penalties": pens,
        "score": final,
        "issues": issues
    }

def analyze_history(history: List[Dict], weights: Dict[str, Dict[str, float]] = None) -> Dict:
    """Analyze last manager turn per stage and produce stage_scores + total."""
    by_stage = {}
    for h in history:
        if h.get("role") == "manager":
            st = h.get("stage") or "greeting"
            by_stage[st] = h  # keep last
    results = {}
    total = 0.0
    used = 0
    for st, h in by_stage.items():
        res = analyze_turn(h.get("content", ""), st, weights)
        results[st] = res
        total += res["score"]
        used += 1
    return {
        "stage_scores": results,
        "total": round(total / max(1, used), 2) if used else 0.0
    }
