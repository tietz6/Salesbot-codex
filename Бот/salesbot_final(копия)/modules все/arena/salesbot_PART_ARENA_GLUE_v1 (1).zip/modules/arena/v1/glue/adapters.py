
import time
from .config import (
    DEEPSEEK_ROLE, GLUE_TIMEOUT,
    ENABLE_PSYCOTYPES, ENABLE_PERSONA, ENABLE_RUBRICS, ENABLE_DRAGON,
    ENABLE_OBJECTIONS, ENABLE_UPSELL
)

def _fallback_ok(data=None): 
    return {"ok": True, **(data or {})}

def _fallback_err(msg, data=None):
    return {"ok": False, "error": msg, **(data or {})}

class Glue:
    """Безопасный слой: подключает внешние модули, но не ломается при их отсутствии."""

    # -------- Persona (firm brand voice) --------
    def persona_chat(self, prompt: str, role: str = None):
        if not ENABLE_PERSONA:
            return _fallback_ok({"text": f"[persona disabled] {prompt}"})
        try:
            from modules.deepseek_persona.v1 import persona_chat as _persona_chat
        except Exception:
            # мягкий фолбэк
            return _fallback_ok({"text": f"[persona fallback] {prompt}"})
        try:
            out = _persona_chat(prompt, role=role or DEEPSEEK_ROLE)
            return {"ok": True, "text": out}
        except Exception as e:
            return _fallback_err(f"persona_chat error: {e}")

    # -------- Psychotypes (Arena dynamics) --------
    def psy_spawn(self, difficulty: str = "medium", type: str = None, context: str = ""):
        if not ENABLE_PSYCOTYPES:
            return _fallback_ok({"state": {"difficulty": difficulty, "type": type or "neutral", "context": context}, "client_reply": "Здравствуйте! Начнём диалог."})
        try:
            from modules.arena.v4.glue_psychotypes import psy_spawn as _spawn
        except Exception:
            return _fallback_ok({"state": {"difficulty": difficulty, "type": type or "neutral", "context": context}, "client_reply": "Здравствуйте! (fallback)"})
        try:
            return _spawn(difficulty, type, context)
        except Exception as e:
            return _fallback_err(f"psy_spawn error: {e}")

    def psy_step(self, state: dict, manager_reply: str):
        if not ENABLE_PSYCOTYPES:
            # простая генерация на брендовом стиле, если доступно
            pc = self.persona_chat(f"Ответ клиента на: {manager_reply}", role="client_emotional")
            return _fallback_ok({"state": state, "client_reply": pc.get("text", "Хорошо, продолжайте."), "penalty": 0})
        try:
            from modules.arena.v4.glue_psychotypes import psy_step as _step
        except Exception:
            pc = self.persona_chat(f"Ответ клиента на: {manager_reply}", role="client_emotional")
            return _fallback_ok({"state": state, "client_reply": pc.get("text", "Понимаю, а расскажите подробнее?"), "penalty": 0})
        try:
            return _step(state, manager_reply)
        except Exception as e:
            return _fallback_err(f"psy_step error: {e}")

    # -------- Master Path rubrics --------
    def master_score(self, history: list):
        if not ENABLE_RUBRICS:
            return _fallback_ok({"total": 60, "stage_scores": {}, "issues": ["rubrics disabled"], "tips": ["добавьте уточняющий вопрос", "подчеркните выгоду"]})
        try:
            from modules.master_path.v3.glue_rubrics import compute_master_score
        except Exception:
            return _fallback_ok({"total": 62, "stage_scores": {}, "issues": ["rubrics fallback"], "tips": ["приветствие короче", "мягко к оплате"]})
        try:
            return {"ok": True, **compute_master_score(history)}
        except Exception as e:
            return _fallback_err(f"master_score error: {e}")

    # -------- Sleeping Dragon rules --------
    def dragon_score(self, reply: str, history=None, stage=None):
        if not ENABLE_DRAGON:
            return _fallback_ok({"combined": 6, "rule": {"rule_score": 7, "penalties": []}, "llm": {"llm_score": 5, "reasons": ["dragon disabled"]}})
        try:
            from modules.sleeping_dragon.v4.glue_rules import dragon_analyze, dragon_suggest
        except Exception:
            # вычислим простую эвристику
            base = 7
            if len(reply.strip()) < 8: base -= 2
            if "?" not in reply: base -= 1
            return _fallback_ok({"combined": max(0, base), "rule": {"rule_score": base, "penalties": []}, "llm": {"llm_score": base-1, "reasons": ["fallback"]}})
        try:
            res = dragon_analyze(history or [], reply, stage=stage)
            return {"ok": True, **res}
        except Exception as e:
            return _fallback_err(f"dragon_score error: {e}")

    def dragon_suggest(self, reply: str, history=None, stage=None):
        try:
            from modules.sleeping_dragon.v4.glue_rules import dragon_suggest
        except Exception:
            # короткий совет
            fixed = "Добавьте ценность, 1 уточняющий вопрос и мягкое приглашение к следующему шагу."
            return _fallback_ok({"suggestion": fixed})
        try:
            res = dragon_suggest(history or [], reply, stage=stage)
            return {"ok": True, **res}
        except Exception as e:
            return _fallback_err(f"dragon_suggest error: {e}")

    # -------- Objections classifier --------
    def classify_objection(self, utterance: str, history=None):
        if not ENABLE_OBJECTIONS:
            return _fallback_ok({"type": "neutral", "confidence": 0.4, "advice": "уточните причину сомнения"})
        try:
            from modules.objections_classifier.v1 import classify
        except Exception:
            # простая эвристика
            u = utterance.lower()
            if "дорог" in u or "цена" in u: t = "price"
            elif "довер" in u or "обман" in u: t = "trust"
            elif "подума" in u or "позже" in u: t = "timing"
            else: t = "need"
            return _fallback_ok({"type": t, "confidence": 0.55, "advice": "коротко подчеркните ценность и задайте 1 вопрос"})
        try:
            return {"ok": True, **classify(utterance, history or [])}
        except Exception as e:
            return _fallback_err(f"classify_objection error: {e}")

    # -------- Upsell pricing glue --------
    def upsell_offer(self, catalog=None, tier="premium", currency="KGS", discount=0.0, coupon=None, vat=0.12, context=None, current_tier="basic"):
        if not ENABLE_UPSELL:
            return _fallback_ok({"offer": {"total": 3500, "currency": currency}, "pitch": "Предлагаю расширить подарок — это усилит эмоции."})
        try:
            from modules.upsell_pricing_glue.v1 import compute_offer, suggest_upsell
        except Exception:
            return _fallback_ok({"offer": {"total": 3500, "currency": currency}, "pitch": "Добавим видео-открытку: больше эмоций за разумную доплату. Что для вас важнее — видео или история?"})
        try:
            offer = compute_offer(catalog or {}, tier=tier, currency=currency, discount=discount, coupon=coupon, vat=vat)
            pitch = suggest_upsell(catalog or {}, current_tier=current_tier, target_tier=tier, currency=currency, discount=discount, coupon=coupon, vat=vat, context=context or "")
            return {"ok": True, "offer": offer, "pitch": pitch}
        except Exception as e:
            return _fallback_err(f"upsell_offer error: {e}")
