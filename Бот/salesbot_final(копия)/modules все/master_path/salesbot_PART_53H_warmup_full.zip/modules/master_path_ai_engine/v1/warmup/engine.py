
from __future__ import annotations
import json, os, random
from typing import Dict, Any, List, Tuple

DATA_DIR = os.path.dirname(__file__)

def _read_json(p: str):
    with open(os.path.join(DATA_DIR, p), "r", encoding="utf-8") as f:
        return json.load(f)

# Load data files (lazy)
_templates = None
_emotional = None
_story_boosters = None
_intents = None
_transitions = None
_brand_q = None

def load():
    global _templates, _emotional, _story_boosters, _intents, _transitions, _brand_q
    if _templates is None:
        _templates = _read_json("templates.json")
    if _emotional is None:
        _emotional = _read_json("emotional_ramps.json")
    if _story_boosters is None:
        _story_boosters = _read_json("story_boosters.json")
    if _intents is None:
        _intents = _read_json("intent_map.json")
    if _transitions is None:
        _transitions = _read_json("transitions.json")
    if _brand_q is None:
        _brand_q = _read_json("brand_questions.json")

def suggest_openers(locale="ru", style="gentle", n=3) -> List[str]:
    load()
    pool = [t["text"] for t in _templates if t["tag"]=="opener" and (locale in t["locales"]) and (style in t["styles"])]
    if not pool:
        pool = [t["text"] for t in _templates if t["tag"]=="opener"]
    random.shuffle(pool)
    return pool[:n]

def next_emotional_step(current="gentle") -> str:
    load()
    ladder = _emotional.get("ladder", ["gentle","warm","deep","intimate"])
    try:
        idx = ladder.index(current)
        return ladder[min(idx+1, len(ladder)-1)]
    except ValueError:
        return ladder[0]

def coach_reply(manager_text: str, stage_hint: str="warmup", locale="ru") -> Dict[str, Any]:
    """
    Returns a warm, branded coach suggestion that nudges to a next step.
    This is LLM-agnostic: you can wrap this content as a system prompt for DeepSeek.
    """
    load()
    # very light heuristics
    has_question = "?" in manager_text
    sentiment = "gentle"
    if any(w in manager_text.lower() for w in ["спасибо","здорово","класс","супер","прекрасно","отлично"]):
        sentiment = "warm"
    style = next_emotional_step(sentiment if has_question else "gentle")
    # pick a template
    candidates = [t for t in _templates if t["tag"]=="coach" and style in t["styles"] and locale in t["locales"]]
    if not candidates:
        candidates = [t for t in _templates if t["tag"]=="coach"]
    text = random.choice(candidates)["text"]
    # attach brand micro-questions
    bqs = [q["text"] for q in _brand_q if q["stage"]==stage_hint and locale in q["locales"]]
    random.shuffle(bqs)
    follow = bqs[:1] if bqs else []
    return {
        "style": style,
        "text": text + (" " + follow[0] if follow else ""),
        "stage_hint": stage_hint,
        "has_question": has_question
    }

def extract_story_hints(history: List[Dict[str,str]], locale="ru") -> Dict[str, Any]:
    """
    Pull small structured hints to bring into DeepSeek context.
    """
    load()
    words = " ".join([h["content"] for h in history[-6:]]).lower()
    hints = []
    for rule in _story_boosters.get("rules", []):
        if any(k in words for k in rule.get("keywords", [])):
            hints.append({"key": rule["key"], "tip": random.choice(rule["tips"]).get(locale, rule["tips"][0].get("ru",""))})
    return {"hints": hints[:5]}

def transition(state: Dict[str, Any]) -> str:
    """
    Return next stage according to transitions.json and simple counters.
    """
    load()
    current = state.get("stage","warmup")
    turns = state.get("turns", 0)
    rules = _transitions.get(current, [])
    for r in rules:
        if turns >= r.get("min_turns", 2):
            return r.get("next", "texts")
    return current

def intent_of(text: str) -> str:
    load()
    txt = text.lower()
    for it in _intents.get("intents", []):
        if any(k in txt for k in it["keywords"]):
            return it["name"]
    return "unknown"

def demo():
    load()
    print("Openers:", suggest_openers())
    print("Coach:", coach_reply("Прекрасно, давайте уточню пару моментов?"))
    print("Intent:", intent_of("Сколько стоит?"))
    history=[{"role":"manager","content":"Мы создаём песни по вашей истории"},
             {"role":"client","content":"Это на годовщину свадьбы"}]
    print("Story:", extract_story_hints(history))

if __name__ == "__main__":
    demo()
