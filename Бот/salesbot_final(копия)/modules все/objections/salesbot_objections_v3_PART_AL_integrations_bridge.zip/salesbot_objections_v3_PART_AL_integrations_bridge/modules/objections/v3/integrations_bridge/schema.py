
from pydantic import BaseModel, Field, validator
from typing import List, Dict, Any, Optional

class CoachRequest(BaseModel):
    dialog: List[Dict[str, Any]] = []
    goal: str = "soft_close"
    persona: str = "mentor"

class CoachResponse(BaseModel):
    trace_id: str
    module: str
    next_utterance: str
    rationale: str
    micro_tips: List[str]
    plan: List[Dict[str, Any]]

class AnalysisRequest(BaseModel):
    utterance: str = Field(..., min_length=1)
    stage: str = "offer"
    @validator("stage")
    def stg(cls, v):
        allowed = {"greeting","qualification","support","offer","demo","final"}
        return v if v in allowed else "offer"

class AnalysisResponse(BaseModel):
    ok: bool = True
    module: str
    penalties: List[str] = []
    score: int = 7
    advice: str = ""

class PatternsResponse(BaseModel):
    ok: bool = True
    module: str
    patterns: Dict[str, Any]

class HealthResponse(BaseModel):
    ok: bool
    module: str
    ts: int
