
Video Bundle Engine v1
----------------------
Эндпоинты:
  GET  /upsell/video_bundle/v1/health
  POST /upsell/video_bundle/v1/build   {song?, video?, story?}
  POST /upsell/video_bundle/v1/price   {bundle? | song?,video?,story?, currency?, coupon?, promo?, vat?}
Манифест: ADD_ONLY, post_hooks: rebuild_routes, touch_startup
