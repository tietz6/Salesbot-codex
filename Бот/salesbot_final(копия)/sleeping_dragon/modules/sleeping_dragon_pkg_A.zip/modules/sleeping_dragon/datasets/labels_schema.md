# Схема разметки dialogs_*.jsonl
{"turn_id": "str", "role": "user|assistant", "text": "str", "intent": "silence|price|postpay|confidence|sing_self|other", "quality": 0-2}
