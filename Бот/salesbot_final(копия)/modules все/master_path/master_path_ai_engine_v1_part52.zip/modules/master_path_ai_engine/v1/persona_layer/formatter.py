from __future__ import annotations
import json
from pathlib import Path
def apply_persona(text: str, role: str, rules_path: str) -> str:
    rules = json.loads(Path(rules_path).read_text(encoding="utf-8"))
    prefix = rules.get("prefix", {}).get(role, "")
    suffix = rules.get("suffix", {}).get(role, "")
    style = rules.get("style", {}).get(role, {})
    t = text.strip()
    if style.get("emoji", False):
        t = t + " " + style.get("emoji_mark", "🌿")
    if style.get("soften", False):
        t = t.replace("!", "🙂")
    return f"{prefix}{t}{suffix}"
