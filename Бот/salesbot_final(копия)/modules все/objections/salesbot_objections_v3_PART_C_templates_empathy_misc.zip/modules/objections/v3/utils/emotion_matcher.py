
def match_emotion(text:str)->str:
    text = (text or '').lower()
    if any(x in text for x in ['дорог','цена']): return 'doubt'
    if any(x in text for x in ['злой','плохо']): return 'annoyed'
    return 'neutral'
