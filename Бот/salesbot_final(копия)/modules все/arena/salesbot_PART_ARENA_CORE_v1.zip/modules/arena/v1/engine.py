
from typing import List, Dict, Any, Optional
import json, os, random, time

try:
    from core.state.v1 import StateStore as _KV  # SQLite KV
except Exception:
    _KV = None

try:
    from core.voice_gateway.v1 import VoicePipeline as _VP
except Exception:
    _VP = None

def _local_llm(messages: List[Dict[str, str]]) -> str:
    last = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            last = m.get("content","")
            break
    return (
        "Понимаю вас 🌿. Давайте уточню один момент, чтобы сделать ответ точнее: "
        + (last[:140] if last else "расскажите, кому вы готовите подарок и к какому событию?")
        + " Если хотите, предложу два коротких варианта и вы выберете сердцем."
    )

class ArenaEngine:
    def __init__(self, db_path: str = "salesbot.db"):
        self.db_path = db_path
        self.kv = None
        if _KV:
            try:
                self.kv = _KV(self.db_path)
            except Exception:
                self.kv = None

        self.vp = _VP() if _VP else None

        self.root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
        self.content_paths = {
            "prompts_ru": os.path.join(self.root_dir, "arena", "v1", "system_prompts", "arena_system_ru.md"),
            "personas_core": os.path.join(self.root_dir, "arena", "v1", "personas", "personas_core.jsonl"),
            "scoring_rubric": os.path.join(self.root_dir, "arena", "v1", "rubrics", "scoring_rubric.yaml"),
            "dragon_rules": os.path.join(self.root_dir, "arena", "v1", "rubrics", "dragon_mistakes.yaml"),
            "qa_pairs": os.path.join(self.root_dir, "arena", "v1", "datasets", "qa_pairs.jsonl"),
        }

    def _kget(self, key: str) -> Optional[str]:
        try:
            if self.kv:
                return self.kv.get(key)
        except Exception:
            pass
        return None

    def _kset(self, key: str, val: str) -> None:
        try:
            if self.kv:
                self.kv.set(key, val)
        except Exception:
            pass

    def start(self, manager_id: str, context: Optional[str]=None) -> Dict[str, Any]:
        sid = f"A-{int(time.time())}-{random.randint(1000,9999)}"
        state = {
            "sid": sid,
            "manager_id": manager_id,
            "started_at": int(time.time()),
            "history": [],
            "meta": {"context": context or ""},
            "score": {"rounds": 0, "penalties": 0, "value_hits": 0}
        }
        self._save_session(state)
        return {"ok": True, "sid": sid, "state": state}

    def step(self, sid: str, text: str) -> Dict[str, Any]:
        state = self._load_session(sid)
        if not state:
            return {"ok": False, "error": "session_not_found"}

        state["history"].append({"role": "manager", "content": text, "ts": int(time.time())})

        pen = 0
        if len(text.strip()) < 3:
            pen += 2
        if "?" not in text:
            pen += 1
        if any(x in text for x in ("!!","??")):
            pen += 1
        state["score"]["penalties"] += pen
        state["score"]["rounds"] += 1
        if any(w in text.lower() for w in ("эмоции","история","по вашей истории","для кого","повод")):
            state["score"]["value_hits"] += 1

        reply = self._ask_llm(state)
        state["history"].append({"role": "client", "content": reply, "ts": int(time.time())})

        self._save_session(state)
        return {"ok": True, "reply": reply, "penalty": pen, "rounds": state["score"]["rounds"]}

    def stop(self, sid: str) -> Dict[str, Any]:
        state = self._load_session(sid)
        if not state:
            return {"ok": False, "error": "session_not_found"}
        rounds = max(1, state["score"]["rounds"])
        base = 10 - min(9, state["score"]["penalties"])
        bonus = min(5, state["score"]["value_hits"])
        total = max(1, min(10, base + bonus))
        summary = {
            "rounds": rounds,
            "penalties": state["score"]["penalties"],
            "value_hits": state["score"]["value_hits"],
            "score_10": total,
            "tips": [
                "Держите тёплый тон и задавайте 1–2 мягких уточняющих вопроса.",
                "Связывайте предложение с их историей и эмоциями.",
                "Давайте выбор без давления и завершайте мягким CTA."
            ]
        }
        return {"ok": True, "sid": sid, "summary": summary, "history": state["history"]}

    def snapshot(self, sid: str) -> Dict[str, Any]:
        state = self._load_session(sid)
        if not state:
            return {"ok": False, "error": "session_not_found"}
        return {"ok": True, "state": state}

    def _load_session(self, sid: str) -> Optional[Dict[str, Any]]:
        raw = self._kget(f"arena:v1:{sid}")
        if not raw:
            return None
        try:
            return json.loads(raw)
        except Exception:
            return None

    def _save_session(self, state: Dict[str, Any]) -> None:
        try:
            self._kset(f"arena:v1:{state['sid']}", json.dumps(state, ensure_ascii=False))
        except Exception:
            pass

    def _ask_llm(self, state: Dict[str, Any]) -> str:
        messages = [{"role":"system","content": "Ты клиент бренда «На Счастье»: тёплый, реалистичный. Отвечай коротко, по делу, с лёгкими эмодзи."}]
        for turn in state.get("history", [])[-10:]:
            messages.append({"role": "user" if turn["role"]=="manager" else "assistant", "content": turn["content"]})
        if self.vp:
            try:
                out = self.vp.llm.chat(messages)  # type: ignore
                if isinstance(out, str) and out.strip():
                    return out.strip()
            except Exception:
                pass
        return _local_llm(messages)
