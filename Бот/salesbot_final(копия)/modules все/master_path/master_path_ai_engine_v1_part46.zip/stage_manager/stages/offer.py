# offer stage logic placeholder
