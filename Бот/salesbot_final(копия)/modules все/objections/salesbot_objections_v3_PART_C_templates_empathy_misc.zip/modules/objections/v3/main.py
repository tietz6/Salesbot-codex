
# Entry point (FastAPI router loader placeholder)
from fastapi import APIRouter
router = APIRouter(prefix="/objections/v3")

@router.get("/health")
def health():
    return {"ok": True, "module": "objections.v3"}
