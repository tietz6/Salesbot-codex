from .manager import StageManager, StageContext
