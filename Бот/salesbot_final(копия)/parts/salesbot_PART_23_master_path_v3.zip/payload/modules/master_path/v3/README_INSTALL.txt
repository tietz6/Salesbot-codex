
master_path/v3 — advanced deal flow
-----------------------------------
Этапы:
  1) greeting
  2) qualification
  3) support
  4) offer
  5) demo
  6) final

Фичи:
  - state machine
  - autosave в core/state/v1
  - LLM-driven suggestions
  - scoring per stage
  - restore() / snapshot()
