# Package N — Multilingual (RU/KY/EN)
- templates.json (warmup, payment_soft, ladder_2to4)
- corrections.json (before→after)
