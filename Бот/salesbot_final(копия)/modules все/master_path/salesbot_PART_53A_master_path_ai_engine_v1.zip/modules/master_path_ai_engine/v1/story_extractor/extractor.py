
import re, json, os
P = os.path.join(os.path.dirname(__file__), 'patterns.json')
PAT = json.load(open(P,'r',encoding='utf-8'))
def extract_facts(text:str)->dict:
    out={k:[] for k in PAT}
    for k, pats in PAT.items():
        for rx in pats:
            for m in re.finditer(rx, text, flags=re.IGNORECASE):
                out[k].append(m.group(0))
    return out
