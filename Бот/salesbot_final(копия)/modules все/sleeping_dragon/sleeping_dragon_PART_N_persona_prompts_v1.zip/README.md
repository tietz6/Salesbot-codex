Persona prompts module placeholder.
