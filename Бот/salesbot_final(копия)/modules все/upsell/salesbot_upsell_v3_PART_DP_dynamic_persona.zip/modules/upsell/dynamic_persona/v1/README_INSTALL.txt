
Dynamic Persona v1
------------------
Эндпоинты:
  POST /upsell/dynamic_persona/v1/spawn  {type?, emotion?, interest?, pressure?}
  POST /upsell/dynamic_persona/v1/step   {state, manager_reply}
  GET  /upsell/dynamic_persona/v1/health

Призвание: реалистичное поведение клиента в апсейле.
