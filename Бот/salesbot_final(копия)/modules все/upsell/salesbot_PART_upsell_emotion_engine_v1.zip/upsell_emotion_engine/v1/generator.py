# generator stub
