Context:
{{context}}

Customer message:
{{utterance}}

Task: produce the next assistant message that addresses the objection,
keeps empathy, and moves toward soft closing when appropriate.