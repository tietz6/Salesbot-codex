
import random, json, os
E_FILE = os.path.join(os.path.dirname(__file__),'emotional_model.json')
R_FILE = os.path.join(os.path.dirname(__file__),'reactions.json')
EMO = json.load(open(E_FILE,'r',encoding='utf-8'))
REA = json.load(open(R_FILE,'r',encoding='utf-8'))
def react(stage:str)->str:
    return random.choice(REA.get(stage, ['Хорошо'])) + ' ' + random.choice(EMO.get('emoji',['🙂']))
