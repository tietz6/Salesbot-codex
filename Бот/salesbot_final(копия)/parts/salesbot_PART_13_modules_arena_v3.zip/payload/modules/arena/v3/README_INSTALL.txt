
Arena v3
Dynamic role‑play simulator:
  - Soft/Hard/Funny client modes
  - DeepSeek-driven dialog engine
  - Score system (tempo, empathy, clarity)
  - Session memory
