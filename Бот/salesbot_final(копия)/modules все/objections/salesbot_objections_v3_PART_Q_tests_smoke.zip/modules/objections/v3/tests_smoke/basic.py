
import requests, sys, json
base = sys.argv[1] if len(sys.argv)>1 else "http://127.0.0.1:8080"
def check(path, method="get", **kw):
    url = base+path
    r = getattr(requests, method)(url, **kw, timeout=10)
    print(path, r.status_code)
    try: print(json.dumps(r.json(), ensure_ascii=False)[:200])
    except: print(r.text[:200])
if __name__=="__main__":
    check("/api/public/v1/health")
    check("/objections/v3/metrics_rt/analyze","post", json={"text":"Спасибо! Уточню: кому дарите?"})
