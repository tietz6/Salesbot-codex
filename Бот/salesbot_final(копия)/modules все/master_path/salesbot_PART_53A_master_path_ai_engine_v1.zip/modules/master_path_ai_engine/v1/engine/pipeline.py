
from .core import MasterPathCore
from .utils import new_sid

class MasterPathPipeline:
    def __init__(self, db_path='salesbot.db'):
        self.core = MasterPathCore(db_path=db_path)

    def start(self):
        sid = new_sid('mp')
        return self.core.start(sid)

    def step(self, sid, text):
        return self.core.handle(sid, text)

    def snapshot(self, sid):
        return self.core.snapshot(sid)
