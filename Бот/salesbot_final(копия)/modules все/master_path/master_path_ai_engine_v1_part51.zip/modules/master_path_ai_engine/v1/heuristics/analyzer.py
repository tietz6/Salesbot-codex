
from __future__ import annotations
import json, math
from pathlib import Path
from typing import Dict

class HeuristicAnalyzer:
    def __init__(self, weights_path: str):
        self.w = json.loads(Path(weights_path).read_text(encoding="utf-8"))
    def score(self, story: Dict) -> Dict:
        s = 0.0
        details = {}
        for k, conf in self.w.get("weights", {}).items():
            v = len(story.get(k, [])) if isinstance(story.get(k), list) else (1 if story.get(k) else 0)
            p = min(v / max(1, conf.get("target",1)), 1.0)
            pts = p * conf.get("weight", 1.0)
            details[k] = {"count": v, "pct": round(p,2), "points": round(pts,2)}
            s += pts
        total = round(100 * s / max(1.0, self.w.get("total_weight", 10.0)), 2)
        tier = "weak" if total < 40 else ("good" if total < 75 else "great")
        return {"total": total, "tier": tier, "details": details}
