
Place into salesbot/products/bundle/v1

Module provides:
  - ProductBundle(dataclass): defines product compositions (song + video + extras)
  - build_bundle(): helper to assemble bundles for CRM deals / payments
  - Pricing rules
  - Utilities for deal naming and metadata
