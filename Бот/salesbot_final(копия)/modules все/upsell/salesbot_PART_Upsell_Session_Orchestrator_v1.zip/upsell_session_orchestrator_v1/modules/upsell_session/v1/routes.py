
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from .engine import new_session, get_session, step, build_offer, finalize

router = APIRouter(prefix="/upsell_session/v1", tags=["upsell_session"])

class StartIn(BaseModel):
    manager_id: str
    context: Optional[str] = ""

class StepIn(BaseModel):
    session_id: str
    manager_id: str
    step: str
    text: str

class OfferIn(BaseModel):
    session_id: str
    manager_id: str
    tier: str = "premium"
    currency: str = "KGS"
    discount: float = 0.1

class FinalizeIn(BaseModel):
    session_id: str
    manager_id: str

@router.get("/health")
def health():
    return {"ok": True, "module": "upsell_session.v1"}

@router.post("/start")
def api_start(inp: StartIn):
    return new_session(inp.manager_id, inp.context)

@router.get("/status/{sid}")
def api_status(sid: str):
    try:
        st = get_session(sid)
    except KeyError:
        raise HTTPException(404, "session not found")
    return {"sid": sid, "stage": st["stage"], "history": st["history"], "meta": st["meta"]}

@router.post("/step")
def api_step(inp: StepIn):
    st = get_session(inp.session_id)
    if st["manager_id"] != inp.manager_id:
        raise HTTPException(403, "manager mismatch")
    return step(st, inp.step, inp.text)

@router.post("/offer")
def api_offer(inp: OfferIn):
    st = get_session(inp.session_id)
    if st["manager_id"] != inp.manager_id:
        raise HTTPException(403, "manager mismatch")
    return build_offer(st, inp.tier, inp.currency, inp.discount)

@router.post("/finalize")
def api_finalize(inp: FinalizeIn):
    st = get_session(inp.session_id)
    if st["manager_id"] != inp.manager_id:
        raise HTTPException(403, "manager mismatch")
    return finalize(st)
