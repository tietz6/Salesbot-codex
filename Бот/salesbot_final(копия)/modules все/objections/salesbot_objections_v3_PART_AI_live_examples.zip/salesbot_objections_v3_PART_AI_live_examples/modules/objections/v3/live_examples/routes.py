
from fastapi import APIRouter, HTTPException, Depends
from .schema import *
from .service import get_service

router = APIRouter(prefix="/objections/{module_slug}", tags=["objections"])

@router.post("/coach", response_model=CoachResponse)
async def coach(module_slug: str, payload: CoachRequest, svc=Depends(get_service)):
    try:
        return await svc.coach(module_slug, payload)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/metrics", response_model=MetricsResponse)
async def metrics(module_slug: str, payload: MetricsRequest, svc=Depends(get_service)):
    try:
        return await svc.metrics(module_slug, payload)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
