
# Orchestrator — управляет цепочкой логики upsell_v3
def next_step(state: dict):
    stage = state.get("stage","start")

    flow = {
        "start": "warmup",
        "warmup": "after_demo",
        "after_demo": "ladder_2to4",
        "ladder_2to4": "cross_sell",
        "cross_sell": "finish"
    }

    return {"current": stage, "next": flow.get(stage,"finish")}
