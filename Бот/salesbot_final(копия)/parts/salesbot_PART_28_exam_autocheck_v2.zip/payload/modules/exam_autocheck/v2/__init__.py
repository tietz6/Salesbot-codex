from .engine import ExamAutoCheck
__all__=['ExamAutoCheck']
