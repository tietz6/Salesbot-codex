
from __future__ import annotations
import os, json
from typing import Dict, Any

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def _load(name: str) -> dict:
    with open(os.path.join(DATA_DIR, name), "r", encoding="utf-8") as f:
        return json.load(f)

CATALOG = _load("catalog.json")
CFG = _load("config.json")

def _fx(currency: str) -> float:
    currency = (currency or "").upper() or CATALOG.get("default_currency","KGS")
    rates = CFG.get("currencies",{})
    return float(rates.get(currency, 1.0)), currency

def price_tier(tier: str, currency: str = "KGS", vat: float | None = None,
               discount: float = 0.0, coupon_percent: float | None = None,
               promo_amount_kgs: float | None = None) -> Dict[str, Any]:
    tier = (tier or "basic").lower()
    t = CATALOG["tiers"].get(tier)
    if not t:
        raise ValueError(f"Unknown tier '{tier}'")

    kgs = float(t["base_kgs"])
    promo_kgs = float(promo_amount_kgs) if promo_amount_kgs else 0.0
    kgs_after_promo = max(0.0, kgs - promo_kgs)

    cp = float(coupon_percent) if coupon_percent is not None else float(CFG.get("coupon_percent_default", 0))
    kgs_after_coupon = kgs_after_promo * (1 - cp/100.0)

    disc = max(0.0, min(0.5, float(discount)))
    kgs_after_disc = kgs_after_coupon * (1 - disc)

    vat_rate = float(vat) if vat is not None else float(CATALOG.get("vat_default", 0.0))
    kgs_total = kgs_after_disc * (1 + vat_rate)

    fx, cur = _fx(currency)
    total = round(kgs_total * fx, 2)

    return {
        "tier": tier,
        "items": t["items"],
        "vat_rate": vat_rate,
        "coupon_percent": cp,
        "manager_discount": disc,
        "promo_amount_kgs": promo_kgs,
        "base_kgs": kgs,
        "total_in": "KGS",
        "total_kgs": round(kgs_total, 2),
        "currency": cur,
        "total": total
    }

def compare(from_tier: str, to_tier: str, currency: str = "KGS",
            discount: float = 0.0, coupon_percent: float | None = None,
            promo_amount_kgs: float | None = None, vat: float | None = None) -> Dict[str, Any]:
    a = price_tier(from_tier, currency, vat, discount, coupon_percent, promo_amount_kgs)
    b = price_tier(to_tier, currency, vat, discount, coupon_percent, promo_amount_kgs)
    diff = round(b["total"] - a["total"], 2)
    upsell_gain = [x for x in CATALOG["tiers"][to_tier]["items"] if x not in CATALOG["tiers"][from_tier]["items"]]
    return {"from": a, "to": b, "diff": diff, "gain_items": upsell_gain}

def pitch(from_tier: str, to_tier: str, currency: str = "KGS", context: str = "",
          discount: float = 0.1) -> Dict[str, Any]:
    comp = compare(from_tier, to_tier, currency, discount=discount)
    items = ", ".join(comp["gain_items"]) if comp["gain_items"] else "расширенный пакет"
    text = (
        f"Предлагаю перейти с {from_tier} на {to_tier}: добавятся {items}. "
        f"Сделаем дополнительную скидку {int(discount*100)}%, чтобы решение было комфортным. "
        f"Это заметный апгрейд по впечатлениям, особенно под ваш запрос: {context}. "
        f"Если откликается — оформлю {to_tier}?"
    )
    return {"ok": True, "compare": comp, "pitch": text}
