Upsell Pricing Recommender v1
---------------------------------
Расчёт цен/скидок/НДС/валют + питч апсейла.

API:
  GET  /upsell_pricing/v1/health
  POST /upsell_pricing/v1/price    {tier, currency, vat?, discount?, coupon_percent?, promo_amount_kgs?}
  POST /upsell_pricing/v1/compare  {from_tier, to_tier, ...}
  POST /upsell_pricing/v1/pitch    {from_tier, to_tier, context, discount}

Каталог и курсы лежат в data/catalog.json и data/config.json.
