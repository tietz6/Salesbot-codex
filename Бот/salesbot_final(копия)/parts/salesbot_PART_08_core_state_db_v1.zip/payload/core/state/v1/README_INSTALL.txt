State manager for salesbot
