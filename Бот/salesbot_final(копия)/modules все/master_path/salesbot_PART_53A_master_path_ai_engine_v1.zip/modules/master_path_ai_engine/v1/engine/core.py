
import json, os
from .dialog_state import DialogState
from .utils import has_question, is_aggressive

try:
    from core.state.v1 import StateStore
    KV=True
except Exception:
    KV=False
    StateStore=None

try:
    from ..deepseek_pipeline.client import chat as ds_chat
except Exception:
    ds_chat=None

CFG_ROOT = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config')
def _load(name):
    p = os.path.join(CFG_ROOT, name)
    try:
        with open(p,'r',encoding='utf-8') as f: return json.load(f)
    except Exception: return {}

TRANSITIONS = _load('transitions.json')
PROMPTS = _load('prompts_brand.json')

class MasterPathCore:
    def __init__(self, db_path='salesbot.db', prefix='mp:'):
        self.kv = StateStore(db_path) if KV else None
        self.prefix = prefix

    def _k(self, sid): return f"{self.prefix}{sid}"
    def save(self, st:DialogState):
        if self.kv: self.kv.set(self._k(st.sid), json.dumps(st.to_dict(), ensure_ascii=False))
    def load(self, sid)->DialogState|None:
        if self.kv:
            raw = self.kv.get(self._k(sid))
            if raw:
                try: return DialogState.from_dict(json.loads(raw))
                except Exception: return None
        return None

    def _coach(self, stage:str, manager_text:str)->str:
        sys = PROMPTS.get('system_templates',{}).get('coach','Ты тёплый наставник.')
        prompt = f"Этап: {stage}. Реплика менеджера: {manager_text}\nДай: 1) короткий совет (1–2 фразы), 2) один уточняющий вопрос."
        if ds_chat:
            try: return ds_chat([{'role':'system','content':sys},{'role':'user','content':prompt}], fallback_note='коуч-совет')
            except Exception: pass
        base = "Добавь ценность и одну мягкую фразу поддержки. Заверши вопросом."
        if not has_question(manager_text): base += " Пример: Что для вас важнее — текст или эмоция в голосе?"
        if is_aggressive(manager_text): base += " Убери жёсткость: бренд говорит мягко и с уважением."
        return base

    def _next(self, stage:str, manager_text:str)->str:
        t = manager_text.lower()
        if stage=='greeting': return 'qualification'
        if stage=='qualification' and ('текст' in t or 'вариант' in t or 'история' in t): return 'texts'
        if stage=='texts' and ('жанр' in t or 'голос' in t): return 'genre'
        if 'оплат' in t or 'карту' in t or 'к оплате' in t: return 'payment'
        opts = TRANSITIONS.get(stage, [])
        return opts[0] if opts else stage

    def start(self, sid:str)->DialogState:
        st = DialogState(sid=sid, stage='greeting'); self.save(st); return st

    def handle(self, sid:str, text:str):
        st = self.load(sid) or self.start(sid)
        st.history.append({'role':'manager','content':text,'stage':st.stage})
        coach = self._coach(st.stage, text)
        st.history.append({'role':'coach','content':coach,'stage':st.stage})
        nxt = self._next(st.stage, text)
        st.stage = nxt
        self.save(st)
        return {'sid':sid,'reply':coach,'stage':st.stage,'next':nxt}

    def snapshot(self, sid:str):
        st = self.load(sid)
        return st.to_dict() if st else {'sid':sid,'missing':True}
