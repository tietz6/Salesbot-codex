# Автоподхват модулей objections/v3
import importlib, pkgutil
def load():
    loaded = []
    pkg = __name__.rsplit(".",1)[0] + ".v3"
    for m in pkgutil.iter_modules([__path__[0]]):
        if m.name in ("__pycache__",): 
            continue
        try:
            loaded.append(importlib.import_module(f"{pkg}.{m.name}"))
        except Exception as e:
            loaded.append({"name": m.name, "error": str(e)})
    return loaded