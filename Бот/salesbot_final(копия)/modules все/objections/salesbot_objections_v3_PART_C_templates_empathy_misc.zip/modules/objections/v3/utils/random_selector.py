
import random
def pick(items): 
    return random.choice(items) if items else None
