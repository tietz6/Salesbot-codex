Upsell Coach Prompter v1
--------------------------------
Стилизованные под бренд подсказки для апсейла:
- pre_texts (подогрев перед текстами)
- after_texts (дожим после демо)
- ladder (акция 2→4, +1000 сом за 3-ю)
- video_bundle (Песня + Видео 9:16)
- answers: price / think_later / why_more

Эндпоинты:
  GET  /upsell_prompter/v1/health
  POST /upsell_prompter/v1/suggest {stage, context?}
