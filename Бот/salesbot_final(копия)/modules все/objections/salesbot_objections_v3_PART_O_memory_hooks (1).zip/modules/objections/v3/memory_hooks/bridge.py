
import json
try:
    from modules.dialog_memory.v1 import append_message, start_session, analyze_session
except Exception:
    def start_session(manager_id:str)->str: return "mem-"+manager_id
    def append_message(manager_id:str, session_id:str, role:str, content:str, stage:str=None):
        return {"ok": True}
    def analyze_session(manager_id:str, session_id:str):
        return {"ok": True, "score": 72, "errors": ["коротко","нет вопроса"], "strengths": ["тон тёплый","ценность"]}

def ensure_session(manager_id:str, sid:str=None)->str:
    return sid or start_session(manager_id)

def log_turn(manager_id:str, sid:str, role:str, content:str, stage:str=None):
    return append_message(manager_id, sid, role, content, stage)

def finalize(manager_id:str, sid:str):
    return analyze_session(manager_id, sid)
