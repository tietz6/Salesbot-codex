# Arena Runtime v1

Эндпоинты:
- `GET /arena/v1/health`
- `POST /arena/v1/start` — {manager_id, difficulty?, persona?, context?}
- `POST /arena/v1/handle/{sid}` — {text}
- `GET /arena/v1/snapshot/{sid}`
- `POST /arena/v1/stop/{sid}`

Зависимости через glue:
- deepseek_persona, dialog_memory, arena_psychotypes, sleeping_dragon_rules.
Есть мягкие fallback-и: модуль работает даже без внешних ключей.