
"""
Glue к modules.arena_psychotypes.v1
spawn/step с безопасным фолбэком.
"""
from typing import Dict, Any

def psy_spawn(difficulty: str = "medium", type: str = "emotional", context: str = "") -> Dict[str, Any]:
    try:
        from modules.arena_psychotypes.v1 import psy_spawn as _spawn  # type: ignore
        return _spawn(difficulty=difficulty, type=type, context=context)
    except Exception:
        return {"state": {"difficulty": difficulty, "type": type, "context": context, "emotion":"neutral"},
                "client_reply": "Здравствуйте! О чем именно песня и к какому событию? 😊"}

def psy_step(state: Dict[str, Any], manager_reply: str) -> Dict[str, Any]:
    try:
        from modules.arena_psychotypes.v1 import psy_step as _step  # type: ignore
        return _step(state=state, manager_reply=manager_reply)
    except Exception:
        return {"state": state, "client_reply": "Понимаю. А кому вы хотите подарить песню — и когда дата?", "penalty": 0}
