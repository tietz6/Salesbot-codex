
def handle(text: str, ctx: dict) -> dict:
    return {"stage": "demo_cycle", "ok": True, "hint": "brand-tone"}
