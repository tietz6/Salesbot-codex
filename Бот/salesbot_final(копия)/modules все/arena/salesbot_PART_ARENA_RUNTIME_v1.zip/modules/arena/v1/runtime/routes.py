
from fastapi import APIRouter, Body
from .engine import ArenaEngine

router = APIRouter(prefix="/arena/v1", tags=["Arena Runtime"])
_engine = ArenaEngine()

@router.get("/health")
def health():
    return {"ok": True, "engine": "arena_runtime_v1"}

@router.post("/start")
def start(payload: dict = Body(...)):
    manager_id = payload.get("manager_id","anon")
    difficulty = payload.get("difficulty","medium")
    persona = payload.get("persona","emotional")
    context = payload.get("context","")
    return _engine.start(manager_id, difficulty, persona, context)

@router.post("/handle/{sid}")
def handle(sid: str, payload: dict = Body(...)):
    return _engine.handle(sid, payload.get("text",""))

@router.get("/snapshot/{sid}")
def snapshot(sid: str):
    return _engine.snapshot(sid)

@router.post("/stop/{sid}")
def stop(sid: str):
    return _engine.stop(sid)
