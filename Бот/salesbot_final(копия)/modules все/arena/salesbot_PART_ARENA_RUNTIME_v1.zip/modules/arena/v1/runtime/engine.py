
from typing import Dict, Any, List
import time, os, json, random

# Fallbacks if content pack not present
CONTENT_BASE = os.path.join(os.path.dirname(__file__), "..")  # modules/arena/v1
SCENARIOS = {
    "warm_path": "scenarios/warm_path.jsonl",
    "objections": "scenarios/objections.jsonl",
    "upsell": "scenarios/upsell.jsonl",
    "reengage": "scenarios/reengage.jsonl",
    "endings": "scenarios/endings.jsonl",
}
LEXICON = "language_kits/ru/lexicon.jsonl"

def _read_jsonl(rel_path: str) -> List[dict]:
    path = os.path.join(CONTENT_BASE, rel_path)
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rows.append(json.loads(line))
    except Exception:
        pass
    return rows

def _pick_lexicon(tag: str, default: str) -> str:
    rows = _read_jsonl(LEXICON)
    for r in rows:
        if r.get("tag") == tag:
            return r.get("text", default)
    return default

class ArenaState:
    def __init__(self, sid: str, manager_id: str, persona: str, difficulty: str, context: str):
        self.sid = sid
        self.manager_id = manager_id
        self.persona = persona
        self.difficulty = difficulty
        self.context = context
        self.history: List[Dict[str, Any]] = []
        self.created_at = int(time.time())
        self.stage = "greeting"
        self.metrics = {"round": 0, "combined_avg": 0}

    def to_dict(self):
        return {
            "sid": self.sid,
            "manager_id": self.manager_id,
            "persona": self.persona,
            "difficulty": self.difficulty,
            "context": self.context,
            "stage": self.stage,
            "history": self.history,
            "metrics": self.metrics,
            "created_at": self.created_at,
        }

class ArenaEngine:
    def __init__(self):
        # lazy imports of glue
        from ..glue_psychotypes import psy_spawn, psy_step  # type: ignore
        from ..glue_deepseek_persona import persona_chat  # type: ignore
        from ..glue_rules import dragon_analyze  # type: ignore
        from ..glue_dialog_memory import start_session, append_message, analyze_session  # type: ignore

        self.psy_spawn = psy_spawn
        self.psy_step = psy_step
        self.persona_chat = persona_chat
        self.dragon_analyze = dragon_analyze
        self.mem_start = start_session
        self.mem_append = append_message
        self.mem_analyze = analyze_session

        self.sessions: Dict[str, ArenaState] = {}

    def start(self, manager_id: str, difficulty: str = "medium", persona_type: str = "emotional", context: str = "") -> Dict[str, Any]:
        sid = f"A-{int(time.time()*1000)}-{random.randint(100,999)}"
        psy = self.psy_spawn(difficulty=difficulty, type=persona_type, context=context)
        state = ArenaState(sid, manager_id, persona_type, difficulty, context)
        greeting = _pick_lexicon("greet", "Здравствуйте! О чём будет песня и к какому событию?")
        client_reply = psy.get("client_reply") or greeting
        state.history.append({"role":"client","content":client_reply,"stage":"greeting"})
        state.metrics["round"] = 0
        self.sessions[sid] = state

        # dialog memory hooks
        mm = self.mem_start(manager_id) or sid
        self.mem_append(manager_id, mm, "client", client_reply, "greeting")

        return {"sid": sid, "state": state.to_dict(), "client_reply": client_reply}

    def handle(self, sid: str, manager_reply: str) -> Dict[str, Any]:
        st = self.sessions.get(sid)
        if not st:
            return {"ok": False, "error": "session_not_found"}

        # store manager reply
        st.history.append({"role":"manager","content":manager_reply,"stage":st.stage})
        self.mem_append(st.manager_id, sid, "manager", manager_reply, st.stage)

        # analyze via dragon rules
        rating = self.dragon_analyze(manager_reply, stage=st.stage)
        combined = rating.get("combined", 6)
        # next persona turn
        step = self.psy_step({"difficulty": st.difficulty, "type": st.persona, "context": st.context}, manager_reply)
        client_reply = step.get("client_reply") or self.persona_chat("Ответь как клиент, коротко и по делу", role="client_emotional")

        # stage progression (simple heuristic)
        order = ["greeting","qualification","support","offer","demo","final"]
        try:
            idx = order.index(st.stage)
            if combined >= 7 and idx < len(order)-1:
                st.stage = order[idx+1]
        except Exception:
            pass

        st.metrics["round"] += 1
        st.metrics["combined_avg"] = round((st.metrics.get("combined_avg",0)*(st.metrics["round"]-1)+combined)/st.metrics["round"],2)

        st.history.append({"role":"client","content":client_reply,"stage":st.stage})
        self.mem_append(st.manager_id, sid, "client", client_reply, st.stage)

        return {"ok": True, "state": st.to_dict(), "client_reply": client_reply, "rating": rating}

    def snapshot(self, sid: str) -> Dict[str, Any]:
        st = self.sessions.get(sid)
        if not st:
            return {"ok": False, "error": "session_not_found"}
        return {"ok": True, "state": st.to_dict()}

    def stop(self, sid: str) -> Dict[str, Any]:
        st = self.sessions.get(sid)
        if not st:
            return {"ok": False, "error": "session_not_found"}
        # final analyze
        report = self.mem_analyze(st.manager_id, sid)
        return {"ok": True, "final": report, "state": st.to_dict()}
