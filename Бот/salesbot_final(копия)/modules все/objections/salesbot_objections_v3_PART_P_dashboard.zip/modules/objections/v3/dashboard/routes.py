
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, Response
from fastapi.templating import Jinja2Templates
import os
router = APIRouter(prefix="/objections/v3/dashboard", tags=["objections.dashboard"])
BASE = os.path.dirname(__file__)
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))
@router.get("/static/dash.css")
def css():
    with open(os.path.join(BASE,"static","dash.css"),"rb") as f:
        return Response(f.read(), media_type="text/css")
@router.get("/", response_class=HTMLResponse)
def view(request: Request):
    kpi = {"avg": 78, "sessions": 12}
    errors = ["нет вопроса","слишком коротко","нет ценности"]
    recs = ["добавьте уточняющий вопрос","обозначьте выгоду","мягкий CTA"]
    return templates.TemplateResponse("dash.html", {"request": request, "kpi": kpi, "errors": errors, "recs": recs})
