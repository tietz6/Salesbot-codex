
"""
Glue к modules.dialog_memory.v1
Простые обертки: start/append/analyze/list. Если модуля нет — мягкий no-op.
"""
from typing import Optional, Dict, Any, List
import time

def start_session(manager_id: str) -> Optional[str]:
    try:
        from modules.dialog_memory.v1 import start_session as _start  # type: ignore
        return _start(manager_id=manager_id)
    except Exception:
        # фолбэк: псевдо-id на время
        return f"local-{manager_id}-{int(time.time())}"

def append_message(manager_id: str, session_id: str, role: str, content: str, stage: str = "arena") -> bool:
    try:
        from modules.dialog_memory.v1 import append_message as _append  # type: ignore
        _append(manager_id=manager_id, session_id=session_id, role=role, content=content, stage=stage)
        return True
    except Exception:
        return False

def analyze_session(manager_id: str, session_id: str) -> Dict[str, Any]:
    try:
        from modules.dialog_memory.v1 import analyze_session as _analyze  # type: ignore
        return _analyze(manager_id=manager_id, session_id=session_id)
    except Exception:
        return {"ok": False, "score": 0, "errors": ["dialog_memory недоступен"], "tips": []}

def list_sessions(manager_id: str) -> List[str]:
    try:
        from modules.dialog_memory.v1 import list_sessions as _list  # type: ignore
        return _list(manager_id=manager_id)
    except Exception:
        return []
