# objections/v3 — подмодуль

Работает от LLM, offline-стаб присутствует. Роуты: /coach, /analyze.
