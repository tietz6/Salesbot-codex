import time, random, hashlib
from typing import List, Dict, Any, Optional
from .storage import kv_get_json, kv_set_json

EMOTIONS = ["calm","neutral","annoyed","angry","excited"]
EMOTION_SHIFT = {
    "good": {"calm": "calm", "neutral": "calm", "annoyed": "neutral", "angry": "annoyed", "excited": "calm"},
    "bad":  {"calm": "neutral", "neutral": "annoyed", "annoyed": "angry", "angry": "angry", "excited": "neutral"}
}

def _now(): return int(time.time())

def _persona_reply(system_role: str, user_text: str) -> str:
    # LLM via VoicePipeline -> fallback
    try:
        from core.voice_gateway.v1 import VoicePipeline  # type: ignore
        pipe = VoicePipeline()
        out = pipe.llm.chat([
            {"role":"system","content":system_role},
            {"role":"user","content":user_text}
        ])
        if out and isinstance(out, str) and len(out.strip())>0:
            return out.strip()
    except Exception:
        pass
    # Fallback brand-style
    tips = [
        "Понимаю вас, давайте сделаем так, чтобы подарок чувствовался по‑настоящему личным.",
        "Сделаем мягко и красиво: без давления, с заботой и вниманием к деталям.",
        "Предложу пару вариантов — вы выберете сердцем, хорошо?"
    ]
    return f"Спасибо за ответ. {random.choice(tips)}"

def _score_reply(text: str) -> Dict[str, float]:
    tlen = len(text.strip())
    has_question = '?' in text
    exclam = text.count('!')
    penalties = 0
    if tlen < 10: penalties += 2
    if not has_question: penalties += 1
    if exclam > 2: penalties += 1
    base = 7.0 - penalties
    base = max(0.0, min(10.0, base))
    return {
        "tempo": min(1.0, max(0.0, 0.6 + (0.02 * (tlen/20)))),
        "empathy": min(1.0, max(0.0, 0.5 + (0.1 if "понимаю" in text.lower() else 0.0))),
        "clarity": min(1.0, max(0.0, base/10.0))
    }

class VoiceOverdriveSession:
    def __init__(self, sid: str, manager_id: str, context: str = ""):
        self.sid = sid
        self.manager_id = manager_id
        self.context = context
        self.created = _now()
        self.state = {
            "emotion": "neutral",
            "pressure": 0.4,  # 0..1
            "tempo": 0.6,
            "history": []
        }

    def save(self):
        kv_set_json(f"vo:session:{self.sid}", {
            "sid": self.sid,
            "manager_id": self.manager_id,
            "context": self.context,
            "created": self.created,
            "state": self.state
        })

    @staticmethod
    def load(sid: str) -> Optional["VoiceOverdriveSession"]:
        data = kv_get_json(f"vo:session:{sid}")
        if not data: return None
        sess = VoiceOverdriveSession(data["sid"], data["manager_id"], data.get("context",""))
        sess.created = data.get("created", _now())
        sess.state = data.get("state", sess.state)
        return sess

    def step(self, manager_text: str, features: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        features = features or {}
        # Update tempo from supplied features
        if "speed_wpm" in features:
            sp = features["speed_wpm"]
            self.state["tempo"] = max(0.4, min(1.0, 0.5 + (sp-110)/200.0))
        # Score manager reply
        s = _score_reply(manager_text)
        # Emotion dynamics
        if s["clarity"] >= 0.6 and s["empathy"] >= 0.55:
            new_em = EMOTION_SHIFT["good"][self.state["emotion"]]
            self.state["pressure"] = max(0.0, self.state["pressure"] - 0.1)
        else:
            new_em = EMOTION_SHIFT["bad"][self.state["emotion"]]
            self.state["pressure"] = min(1.0, self.state["pressure"] + 0.1)
        self.state["emotion"] = new_em
        # Compose system role
        sys = (
            "Ты — клиент бренда «На Счастье»: тёплый, реалистичный, но честный. "
            f"Текущая эмоция: {self.state['emotion']}. Уровень давления: {round(self.state['pressure'],2)}. "
            "Отвечай кратко (1–3 фразы), по сути, без канцелярита. "
            "Если слышишь ценность/заботу — смягчайся. Всегда заканчивай мини‑вопросом."
        )
        reply = _persona_reply(sys, manager_text)
        # Save history
        self.state["history"].append({
            "t": _now(),
            "role": "manager",
            "text": manager_text,
            "features": features,
            "metrics": s
        })
        self.state["history"].append({
            "t": _now(),
            "role": "client",
            "text": reply,
            "emotion": self.state["emotion"],
            "pressure": self.state["pressure"]
        })
        self.save()
        return {
            "reply": reply,
            "metrics": {
                "tempo": s["tempo"],
                "empathy": s["empathy"],
                "clarity": s["clarity"],
                "emotion": self.state["emotion"],
                "pressure": self.state["pressure"]
            }
        }

def create_session(manager_id: str, context: str = "") -> str:
    sid = hashlib.sha1(f"{manager_id}|{time.time()}|{random.random()}".encode()).hexdigest()[:12]
    sess = VoiceOverdriveSession(sid, manager_id, context=context)
    sess.save()
    return sid

def tune_session(sid: str, params: Dict[str, Any]) -> Dict[str, Any]:
    sess = VoiceOverdriveSession.load(sid)
    if not sess:
        return {"ok": False, "error": "session_not_found"}
    st = sess.state
    for k in ("emotion","pressure","tempo"):
        if k in params:
            if k == "emotion" and params[k] in ("calm","neutral","annoyed","angry","excited"):
                st["emotion"] = params[k]
            elif k in ("pressure","tempo"):
                try:
                    v = float(params[k])
                    st[k] = max(0.0, min(1.0, v))
                except Exception:
                    pass
    sess.save()
    return {"ok": True, "state": st}
