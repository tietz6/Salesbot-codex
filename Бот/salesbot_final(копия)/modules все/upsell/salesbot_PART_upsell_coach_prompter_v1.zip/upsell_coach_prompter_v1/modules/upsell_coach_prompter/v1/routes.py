
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional, Dict, Any
from .engine import suggest

router = APIRouter(prefix="/upsell_prompter/v1", tags=["upsell_prompter"])

class SuggestIn(BaseModel):
    stage: str
    context: Optional[Dict[str, Any]] = None

@router.get("/health")
def health():
    return {"ok": True, "module":"upsell_coach_prompter.v1"}

@router.post("/suggest")
def api_suggest(inp: SuggestIn):
    return suggest(inp.stage, inp.context)
