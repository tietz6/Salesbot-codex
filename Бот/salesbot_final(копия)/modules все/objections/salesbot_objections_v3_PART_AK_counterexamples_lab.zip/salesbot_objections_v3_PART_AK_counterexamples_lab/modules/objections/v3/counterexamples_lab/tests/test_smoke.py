
from .service import get_service
from .schema import AnalysisRequest, CoachRequest
import asyncio

async def _run():
    svc = get_service("SMOKE")
    a = await svc.analyze(AnalysisRequest(utterance="Понимаю. Что для вас важнее?"))
    c = await svc.coach(CoachRequest())
    assert a.ok and c.next_utterance

asyncio.run(_run())
