
import asyncio
from ..service import LiveCoachService
from ..schema import CoachRequest
async def run():
    svc = LiveCoachService()
    resp = await svc.coach("SMOKE", CoachRequest(dialog=[], goal="soft_close", persona="mentor"))
    assert resp.next_utterance
asyncio.run(run())
