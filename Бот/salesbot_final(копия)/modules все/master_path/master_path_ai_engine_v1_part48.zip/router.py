
from fastapi import APIRouter, Body
from .engine.core import MasterPathEngine

router = APIRouter(prefix="/master_path_ai_engine/v1", tags=["master_path_ai_engine"])
_engine = MasterPathEngine()

@router.get("/health")
def health():
    return {"ok": True, "engine": "master_path_ai_engine.v1", "version": "1.0.0-part48"}

@router.post("/start/{sid}")
def start(sid: str):
    _engine.start_session(sid)
    return {"ok": True, "sid": sid}

@router.post("/handle/{sid}")
def handle(sid: str, payload: dict = Body(...)):
    text = payload.get("text","")
    result = _engine.handle(sid, text=text)
    return result

@router.get("/snapshot/{sid}")
def snapshot(sid: str):
    return _engine.snapshot(sid)

@router.post("/reset/{sid}")
def reset(sid: str):
    _engine.reset(sid)
    return {"ok": True, "sid": sid, "reset": True}
