
import re, json, os
from ..v3.classifier.emotional_states import states if False else None  # placeholder for import style

PRICE = re.compile(r"(дорог|цена|стоим|прайс)", re.I)
TRUST = re.compile(r"(обман|гарант|качест|не уверен)", re.I)
DELAY = re.compile(r"(подумаю|позже|потом|завтра)", re.I)
COMP  = re.compile(r"(у других|дешевле|конкурент|suno)", re.I)

def guess(text:str)->str:
    if not text: return "thinking"
    t = text.lower()
    if PRICE.search(t): return "price"
    if TRUST.search(t): return "trust"
    if DELAY.search(t): return "delay"
    if COMP.search(t):  return "competitor"
    if t.strip()=="" or t.strip()=="...": return "silent"
    return "thinking"
