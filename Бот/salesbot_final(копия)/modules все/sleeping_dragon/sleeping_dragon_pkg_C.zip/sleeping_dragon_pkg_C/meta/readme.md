Package C metadata
