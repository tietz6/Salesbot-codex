import os, asyncio
from datetime import datetime

# Имитация вызова DeepSeek Chat (подключите свой клиент в core.deepllm)
async def deepseek_chat(prompt: str) -> str:
    # Здесь должен быть реальный вызов клиента DeepSeek.
    # Возвращаем заглушку с отметкой времени для проверки живости пайплайна.
    await asyncio.sleep(0)
    return "[deepseek.ok policy_guardrails] " + datetime.utcnow().isoformat() + "\n" + prompt[:400]

async def run_tool(payload: dict):
    context = payload.get("context", {})
    utterance = payload.get("utterance", "")
    task = payload.get("task", "")
    prompt = (
        "Смоделируй ответ менеджера по модулю: policy_guardrails\n"
        "Контекст: {context}\nКлиент: {utterance}\nЗадача: {task}\n"
        "Дай 1) короткий ответ, 2) следующий шаг менеджера, 3) подсказку коучу."
    ).format(context=context, utterance=utterance, task=task, slug="policy_guardrails")
    text = await deepseek_chat(prompt)
    return {{"ok": True, "module": "policy_guardrails", "result": text}}