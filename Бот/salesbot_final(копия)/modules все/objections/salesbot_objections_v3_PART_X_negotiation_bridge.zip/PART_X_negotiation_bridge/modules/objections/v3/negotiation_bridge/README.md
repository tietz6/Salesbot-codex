# PART_X — Negotiation Bridge (мост переговоров)
Модуль v3 для salesbot. Работает на LLM (DeepSeek). Подхватывается автозагрузчиком из `api/modules/`.