from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
from ..service import run_tool

router = APIRouter()

class Request(BaseModel):
    context: dict
    utterance: str
    task: str = ""

@router.post("/run")
async def run(req: Request):
    if not os.getenv("DEEPSEEK_API_KEY"):
        raise HTTPException(500, "DEEPSEEK_API_KEY not configured")
    return await run_tool(req.dict())