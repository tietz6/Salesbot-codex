
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from .engine import price_tier, compare, pitch

router = APIRouter(prefix="/upsell_pricing/v1", tags=["upsell_pricing"])

class PriceIn(BaseModel):
    tier: str
    currency: str = "KGS"
    vat: Optional[float] = None
    discount: float = 0.0
    coupon_percent: Optional[float] = None
    promo_amount_kgs: Optional[float] = None

class CompareIn(BaseModel):
    from_tier: str
    to_tier: str
    currency: str = "KGS"
    vat: Optional[float] = None
    discount: float = 0.0
    coupon_percent: Optional[float] = None
    promo_amount_kgs: Optional[float] = None

class PitchIn(BaseModel):
    from_tier: str
    to_tier: str
    currency: str = "KGS"
    context: str = ""
    discount: float = 0.1

@router.get("/health")
def health():
    return {"ok": True, "module": "upsell_pricing_recommender.v1"}

@router.post("/price")
def api_price(inp: PriceIn):
    return price_tier(inp.tier, inp.currency, inp.vat, inp.discount, inp.coupon_percent, inp.promo_amount_kgs)

@router.post("/compare")
def api_compare(inp: CompareIn):
    return compare(inp.from_tier, inp.to_tier, inp.currency, inp.discount, inp.coupon_percent, inp.promo_amount_kgs, inp.vat)

@router.post("/pitch")
def api_pitch(inp: PitchIn):
    return pitch(inp.from_tier, inp.to_tier, inp.currency, inp.context, inp.discount)
