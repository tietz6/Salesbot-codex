
from .templates_strings import BASE_HTML, SESSION_HTML

def render_start():
    return BASE_HTML.format(content="<h2>Arena UI</h2><p>Нажмите старт сессии.</p>")

def render_session(manager_id: str, sid: str, state: dict, last_reply: str):
    history_html = ""
    for msg in state.get("history", []):
        role = "Менеджер" if msg["role"] == "manager" else "Клиент"
        history_html += f'<div class="msg {msg["role"]}"><b>{role}:</b> {msg["content"]}</div>'
    bar = (
        '<div class="kpi">'
        f'<div>Сессия: <code>{sid}</code></div>'
        f'<div>Этап: <b>{state.get("stage","-")}</b></div>'
        f'<div>Раунд: <b>{state.get("metrics",{}).get("round",0)}</b></div>'
        f'<div>Средний балл: <b>{state.get("metrics",{}).get("combined_avg",0)}</b></div>'
        '</div>'
    )
    form = (
        '<form class="turn" onsubmit="sendTurn(event)">'
        f'<input type="hidden" id="sid" value="{sid}"/>'
        '<textarea id="msg" placeholder="Ваш ответ..."></textarea>'
        '<button type="submit">Отправить</button>'
        '<button type="button" onclick="stopSession()">Завершить</button>'
        '</form>'
    )
    content = bar + f'<div class="reply"><span>Клиент:</span> {last_reply}</div>' + '<div class="history">'+history_html+'</div>' + form
    return SESSION_HTML.format(manager_id=manager_id, sid=sid, content=content)
