
from __future__ import annotations
import json, random
from pathlib import Path

class WarmupEngine:
    def __init__(self, templates_path: str):
        self.data = json.loads(Path(templates_path).read_text(encoding="utf-8"))
    def pre_texts(self) -> str:
        return random.choice(self.data.get("pre_texts", []))
    def after_texts(self) -> str:
        return random.choice(self.data.get("after_texts", []))
    def ladder(self) -> str:
        return random.choice(self.data.get("ladder_2to4", []))
