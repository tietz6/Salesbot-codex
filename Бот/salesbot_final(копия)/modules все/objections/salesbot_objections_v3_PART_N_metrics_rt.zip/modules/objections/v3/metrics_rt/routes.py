
from fastapi import APIRouter
from .engine import analyze_turn
router = APIRouter(prefix="/objections/v3/metrics_rt", tags=["objections.metrics_rt"])
@router.post("/analyze")
def analyze(payload: dict):
    return {"ok": True, "metrics": analyze_turn(payload.get("text",""))}
