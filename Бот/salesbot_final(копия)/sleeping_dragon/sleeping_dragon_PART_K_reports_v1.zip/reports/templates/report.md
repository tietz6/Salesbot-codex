# Отчёт Sleeping Dragon

**Manager:** {{manager_id}}  
**Session:** {{session_id}}  
**Generated:** {{generated_at}}

## Сводка
{{summary}}

## Баллы
- Итог: **{{scores.total}}**
- Rule: **{{scores.rule}}/10**
- LLM: **{{scores.llm}}/10**
- Стадии: {{stages_inline}}

## Ошибки
{{issues_md}}

## Советы
{{tips_md}}

## Следующие шаги
{{next_actions_md}}

## Ссылки
{{links_md}}
