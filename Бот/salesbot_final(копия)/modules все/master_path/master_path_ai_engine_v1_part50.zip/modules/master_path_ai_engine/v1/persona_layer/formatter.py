
from __future__ import annotations
import json
from pathlib import Path

class PersonaFormatter:
    def __init__(self, rules_path: str):
        self.rules = json.loads(Path(rules_path).read_text(encoding="utf-8"))
    def apply(self, text: str, role: str = "coach") -> str:
        r = self.rules.get(role, {})
        prefix = r.get("prefix","")
        suffix = r.get("suffix","")
        tone = r.get("tone_hint","")
        return f"{prefix}{text.strip()} {suffix}".strip() + (f" ({tone})" if tone else "")
