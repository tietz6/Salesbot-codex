
from __future__ import annotations
import json, os, random
from typing import Dict, Any, List
try:
    from core.voice_gateway.v1 import VoicePipeline  # optional
    _HAS_VOICE = True
except Exception:
    _HAS_VOICE = False

CATALOG_PATH = os.path.join(os.path.dirname(__file__), "genres.json")

class GenreSelector:
    def __init__(self, catalog_path: str = CATALOG_PATH):
        with open(catalog_path, "r", encoding="utf-8") as f:
            self.catalog = json.load(f)

    def select(self, preferences: Dict[str, Any] | None = None, history: List[Dict[str, str]] | None = None) -> Dict[str, Any]:
        preferences = preferences or {}
        mood = preferences.get("mood"); tempo = preferences.get("tempo"); voice = preferences.get("voice")
        items = self.catalog["catalog"]; scored = []
        for it in items:
            score = 0.0
            if mood and it["mood"] == mood: score += 0.5
            if tempo and it["tempo"] == tempo: score += 0.3
            if voice and it["voice"] == voice: score += 0.2
            score += it["weights"]["emotion"] * 0.4
            score += it["weights"]["energy"] * 0.35
            score += it["weights"]["trend"] * 0.25
            score += random.uniform(-0.03, 0.03)
            scored.append((score, it))
        scored.sort(key=lambda x: x[0], reverse=True)
        primary = scored[0][1]; alts = [x[1] for x in scored[1:6]]
        return {"primary": primary, "alternatives": alts, "llm_hint": self._llm_hint(primary, preferences, history)}

    def _llm_hint(self, primary, preferences, history):
        try:
            if _HAS_VOICE:
                vp = VoicePipeline()
                messages = [
                    {"role":"system","content":"Ты тёплый музыкальный консультант бренда 'На Счастье'. Дай очень короткую рекомендацию жанра: 1–2 фразы."},
                    {"role":"user","content":json.dumps({"primary":primary,"preferences":preferences,"history_tail":history[-3:] if history else []}, ensure_ascii=False)}
                ]
                return vp.llm.chat(messages)[:300]
        except Exception:
            pass
        title = primary.get("title","Жанр"); mood = primary.get("mood","romantic")
        return f"Рекомендую {title}. Он подчеркнёт {('тёплые чувства' if mood in ('romantic','family','lyric') else 'энергию момента')}."
