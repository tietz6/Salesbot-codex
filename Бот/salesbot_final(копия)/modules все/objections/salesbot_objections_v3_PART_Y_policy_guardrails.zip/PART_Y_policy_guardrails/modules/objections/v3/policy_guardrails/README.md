# PART_Y — Policy Guardrails (правила и границы)
Модуль v3 для salesbot. Работает на LLM (DeepSeek). Подхватывается автозагрузчиком из `api/modules/`.