
from __future__ import annotations
import json
from pathlib import Path

class StageManager:
    def __init__(self, rules_path: str):
        self.rules = json.loads(Path(rules_path).read_text(encoding="utf-8"))
    def next_stage(self, current: str, event: str) -> str:
        table = self.rules.get("transitions", {})
        return table.get(current, {}).get(event, table.get(current, {}).get("default", current))
