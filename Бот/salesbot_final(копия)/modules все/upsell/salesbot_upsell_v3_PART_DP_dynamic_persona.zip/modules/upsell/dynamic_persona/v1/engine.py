
from dataclasses import dataclass, field
from typing import Dict, Any

@dataclass
class PersonaState:
    type: str = "neutral"       # cold | emotional | rational | haggler | fast | closed
    emotion: str = "neutral"    # calm | neutral | annoyed | angry | excited
    interest: float = 0.5       # 0..1
    pressure: float = 0.0       # 0..1

class DynamicPersona:
    def __init__(self, seed: Dict[str, Any] = None):
        cfg = seed or {}
        self.state = PersonaState(
            type = cfg.get("type", "cold"),
            emotion = cfg.get("emotion", "neutral"),
            interest = float(cfg.get("interest", 0.4)),
            pressure = float(cfg.get("pressure", 0.2)),
        )

    def step(self, manager_reply: str) -> Dict[str, Any]:
        reply = manager_reply.lower()
        delta_interest = 0.0
        delta_pressure = 0.0

        # простые эвристики
        if "пожалуйста" in reply or "расскажите" in reply or "подскажите" in reply:
            delta_interest += 0.08
        if "скид" in reply or "подар" in reply:
            delta_interest += 0.10
        if "!" in reply and reply.count("!") > 2:
            delta_pressure += 0.08
        if "?" in reply:
            delta_interest += 0.05
        if len(reply) < 12:
            delta_pressure += 0.05

        # нормализация и эмоции
        self.state.interest = min(1.0, max(0.0, self.state.interest + delta_interest - 0.03*delta_pressure))
        self.state.pressure = min(1.0, max(0.0, self.state.pressure + delta_pressure - 0.02*delta_interest))

        # обновить эмоцию
        if self.state.pressure > 0.7:
            self.state.emotion = "angry"
        elif self.state.pressure > 0.45:
            self.state.emotion = "annoyed"
        elif self.state.interest > 0.75:
            self.state.emotion = "excited"
        elif self.state.interest > 0.5:
            self.state.emotion = "neutral"
        else:
            self.state.emotion = "calm"

        # короткий ответ клиента под тип/эмоцию
        client_answer = self._speak_like_persona(manager_reply)
        return {
            "state": self.state.__dict__,
            "client_reply": client_answer
        }

    def _speak_like_persona(self, manager_reply: str) -> str:
        t = self.state.type
        e = self.state.emotion
        if t == "haggler":
            base = "Давайте по сути. Сколько это выйдет и где выгода?"
            if self.state.interest > 0.6:
                base = "Если будет пакет и выгода, можно обсудить."
        elif t == "emotional":
            base = "Хочу, чтобы было очень душевно… Расскажите, как это почувствует тот, кто получит?"
        elif t == "fast":
            base = "Коротко. Что получу и когда?"
        elif t == "closed":
            base = "Мне не до рассказов. Если быстро и без лишнего — продолжим."
        elif t == "rational":
            base = "Пожалуйста, сравните варианты по цене и ценности."
        else:  # cold/default
            base = "Я пока присматриваюсь. Объясните простыми словами, зачем это мне."

        if e == "angry":
            tone = " Говорите четче — у меня мало времени."
        elif e == "annoyed":
            tone = " Пожалуйста, без лишних деталей."
        elif e == "excited":
            tone = " Звучит любопытно, продолжайте."
        else:
            tone = ""
        return base + tone
