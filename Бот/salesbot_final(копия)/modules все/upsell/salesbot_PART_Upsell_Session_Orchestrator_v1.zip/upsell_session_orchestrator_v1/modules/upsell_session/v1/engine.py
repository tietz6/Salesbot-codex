
from __future__ import annotations
import time, json, os
from typing import Dict, List, Any, Optional

def _try_import(path: str):
    try:
        return __import__(path, fromlist=['*'])
    except Exception:
        return None

KV = _try_import("core.state.v1")
PRICER = _try_import("modules.upsell_pricing_recommender.v1.engine")
PERSONA = _try_import("modules.deepseek_persona.v1")
DIALOG = _try_import("modules.dialog_memory.v1")
PAYV2 = _try_import("modules.payments.v2")

class Store:
    def __init__(self, db_path: str = "salesbot.db"):
        if KV and hasattr(KV, "StateStore"):
            self.kv = KV.StateStore(db_path)
        else:
            self.kv = None
            self.fs = {}

    def get(self, key:str)->Optional[str]:
        if self.kv:
            return self.kv.get(key)
        return self.fs.get(key)

    def set(self, key:str, value:str):
        if self.kv:
            self.kv.set(key, value)
        else:
            self.fs[key] = value

    def scan(self, prefix:str, limit:int=200):
        if self.kv:
            return self.kv.scan(prefix, limit)
        return [(k, v) for k,v in self.fs.items() if k.startswith(prefix)][:limit]

STORE = Store()

STAGES = json.load(open(os.path.join(os.path.dirname(__file__), "data", "stages.json"), "r", encoding="utf-8"))
ORDER = STAGES["order"]

def _now():
    return int(time.time())

def _persona_reply(prompt:str, role:str="client_emotional")->str:
    if PERSONA and hasattr(PERSONA, "persona_chat"):
        try:
            return PERSONA.persona_chat(prompt, role=role).get("output","")
        except Exception:
            pass
    return f"[fallback] {prompt}"

def _append_history(state:Dict[str,Any], role:str, content:str):
    state["history"].append({"ts":_now(),"role":role,"content":content})

def new_session(manager_id:str, context:str="")->Dict[str,Any]:
    sid = f"S{_now()}_{abs(hash(manager_id))%100000}"
    state = {
        "sid": sid,
        "manager_id": manager_id,
        "stage": ORDER[0],
        "history": [],
        "meta": {"context": context, "pricing": None, "invoice": None},
        "scores": {}
    }
    _append_history(state, "coach", "Старт апсейла: начинаем с тёплого подогрева.")
    STORE.set(f"upsell_session:{sid}", json.dumps(state, ensure_ascii=False))
    if DIALOG and hasattr(DIALOG, "start_session"):
        try:
            DIALOG.start_session(manager_id=manager_id, session_id=sid, tag="upsell")
        except Exception:
            pass
    return state

def get_session(sid:str)->Dict[str,Any]:
    raw = STORE.get(f"upsell_session:{sid}")
    if not raw:
        raise KeyError("session not found")
    return json.loads(raw)

def save_session(state:Dict[str,Any]):
    STORE.set(f"upsell_session:{state['sid']}", json.dumps(state, ensure_ascii=False))

def advance_stage(state:Dict[str,Any]):
    cur = state["stage"]
    try:
        idx = ORDER.index(cur)
        if idx < len(ORDER)-1:
            state["stage"] = ORDER[idx+1]
    except ValueError:
        state["stage"] = ORDER[0]

def step(state:Dict[str,Any], step_name:str, manager_text:str)->Dict[str,Any]:
    _append_history(state, "manager", manager_text)

    if step_name == "warmup":
        reply_prompt = "Тёплый отклик клиента на подогрев, мягко делится деталями и поводом."
    elif step_name == "texts":
        reply_prompt = "Клиент благодарит за тексты, выбирает один вариант и добавляет пару деталей."
    elif step_name == "demos":
        reply_prompt = "Клиент послушал два демо и колеблется: оба нравятся, просит подсказать."
    elif step_name == "ladder_2to4":
        reply_prompt = "Клиент размышляет: выгодно ли 2→4? Сомневается, но открыт к выгоде и удобству."
    else:
        reply_prompt = "Клиент отвечает доброжелательно, готов двигаться дальше."

    client = _persona_reply(reply_prompt, role="client_emotional")
    _append_history(state, "client", client)

    if DIALOG and hasattr(DIALOG, "append"):
        try:
            DIALOG.append(manager_id=state["manager_id"], session_id=state["sid"], role="manager", content=manager_text, stage=state["stage"])
            DIALOG.append(manager_id=state["manager_id"], session_id=state["sid"], role="client", content=client, stage=state["stage"])
        except Exception:
            pass

    advance_stage(state)
    save_session(state)
    return {"ok": True, "state": state}

def build_offer(state:Dict[str,Any], tier:str="premium", currency:str="KGS", discount:float=0.1)->Dict[str,Any]:
    pricing = None
    if PRICER and hasattr(PRICER, "price_tier"):
        try:
            pricing = PRICER.price_tier(tier=tier, currency=currency, discount=discount)
        except Exception as e:
            pricing = {"error": str(e)}
    else:
        pricing = {"tier": tier, "currency": currency, "total": 7500, "note": "fallback pricing"}
    state["meta"]["pricing"] = pricing

    gain = ""
    if PRICER and hasattr(PRICER, "compare"):
        try:
            comp = PRICER.compare("basic", tier, currency, discount)
            gain = ", ".join(comp.get("gain_items") or [])
        except Exception:
            pass
    pitch = _persona_reply(f"Короткий питч апсейла {tier} с выгодой и мягким CTA. Добавится: {gain}.", role="coach")
    _append_history(state, "coach", pitch)

    advance_stage(state)
    save_session(state)
    return {"ok": True, "pricing": pricing, "pitch": pitch, "stage": state["stage"]}

def finalize(state:Dict[str,Any])->Dict[str,Any]:
    score = 60
    if state["meta"].get("pricing"):
        score += 15
    if any(h["role"]=="manager" for h in state["history"]):
        score += 10
    score = min(100, score)
    state["scores"]["final"] = score
    _append_history(state, "coach", f"Спасибо! Итоговая оценка тренировки: {score}/100. Вы хорошо держите тёплый тон и структуру.")

    report = None
    if DIALOG and hasattr(DIALOG, "analyze_session"):
        try:
            report = DIALOG.analyze_session(manager_id=state["manager_id"], session_id=state["sid"])
        except Exception:
            report = None

    state["stage"] = "done"
    save_session(state)
    return {"ok": True, "score": score, "report": report, "state": state}
