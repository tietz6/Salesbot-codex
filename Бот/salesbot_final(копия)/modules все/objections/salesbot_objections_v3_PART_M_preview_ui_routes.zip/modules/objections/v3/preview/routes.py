
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import os, random

router = APIRouter(prefix="/objections/v3/preview", tags=["objections.preview"])

BASE = os.path.dirname(__file__)
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))

@router.get("/static/preview.css")
def css():
    from fastapi.responses import Response
    with open(os.path.join(BASE, "static","preview.css"), "rb") as f:
        return Response(f.read(), media_type="text/css")

@router.get("/dialog", response_class=HTMLResponse)
def dialog(request: Request):
    # demo payload
    history = [
        {"role":"manager","content":"Добрый день! Мы создаём песни по вашей истории — подскажите, к какому событию готовим подарок?"},
        {"role":"client","content":"Дорого. Я подумаю."},
        {"role":"manager","content":"Понимаю 💛 Давайте сделаем так: я предложу два жанра, вы выберете сердцем, и вы почувствуете, что это именно про вас."}
    ]
    ctx = {"request": request, "history": history, "empathy": 8, "value": 8, "cta": 7}
    return templates.TemplateResponse("dialog.html", ctx)
