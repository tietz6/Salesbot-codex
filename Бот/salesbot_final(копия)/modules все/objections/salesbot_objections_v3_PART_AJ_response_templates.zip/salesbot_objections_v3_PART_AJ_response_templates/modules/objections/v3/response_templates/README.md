# objections/v3 addon

Подмодуль для тренажёра возражений. Имеет health, coach, analyze, patterns.