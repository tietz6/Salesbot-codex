
# story_extractor/extractor.py
from __future__ import annotations
import re, json
from pathlib import Path

class StoryExtractor:
    """Deterministic extractor for key slots from free-form story text.
    Slots: names, dates, places, moments, hobbies, kids, pets, vows, gifts
    """
    def __init__(self, patterns_path: str | None = None):
        self.patterns = {}
        if patterns_path and Path(patterns_path).exists():
            self.patterns = json.loads(Path(patterns_path).read_text(encoding="utf-8"))

    def extract(self, text: str) -> dict:
        text_norm = ' '.join(text.split())
        res = {k: [] for k in ["names","dates","places","moments","hobbies","kids","pets","vows","gifts","met","anniversary","nicknames"]}
        # regex-first
        for p in self.patterns.get("regex", []):
            kind = p.get("slot")
            try:
                m = re.findall(p.get("pattern",""), text_norm, flags=re.IGNORECASE)
                if m and kind in res:
                    res[kind].extend([m] if isinstance(m, str) else list(m))
            except re.error:
                continue
        # keyword-hints
        for kw in self.patterns.get("keywords", []):
            kind = kw.get("slot")
            if kind in res:
                for w in kw.get("words", []):
                    if w.lower() in text_norm.lower():
                        res[kind].append(w)
        # post-process unique/trim
        for k,v in res.items():
            seen, out = set(), []
            for item in v:
                item = item.strip() if isinstance(item,str) else item
                if item and item not in seen:
                    seen.add(item); out.append(item)
            res[k] = out
        return res
