
from fastapi import APIRouter, Body
from typing import Dict, Any, List

router = APIRouter(prefix="/objections/v3", tags=["objections.v3"])

# In-memory demo state (replace with core/state in your app)
_SESSIONS: Dict[str, Dict[str, Any]] = {}

def _sid_key(sid:str)->str:
    return sid or "default"

@router.post("/start/{sid}")
def start(sid:str):
    key = _sid_key(sid)
    _SESSIONS[key] = {"history": [], "stage":"objection", "meta": {"started": True}}
    return {"ok": True, "sid": key, "state": _SESSIONS[key]}

@router.post("/handle/{sid}")
def handle(sid:str, payload: Dict[str, Any] = Body(...)):
    key = _sid_key(sid)
    s = _SESSIONS.setdefault(key, {"history": [], "stage":"objection", "meta": {}})
    user = payload.get("text","").strip()
    if user:
        s["history"].append({"role":"manager","content":user})
    # naive reply (placeholder): soft value + CTA
    reply = "Понимаю вас 💛 Мы делаем песню именно по вашей истории. Удобно, если пришлю 2 варианта жанра?"
    s["history"].append({"role":"client","content":reply})
    return {"ok": True, "sid": key, "reply": reply, "state": s}

@router.get("/snapshot/{sid}")
def snapshot(sid:str):
    return {"ok": True, "sid": sid, "state": _SESSIONS.get(_sid_key(sid))}

@router.post("/reset/{sid}")
def reset(sid:str):
    key = _sid_key(sid)
    if key in _SESSIONS:
        del _SESSIONS[key]
    return {"ok": True, "sid": key}
