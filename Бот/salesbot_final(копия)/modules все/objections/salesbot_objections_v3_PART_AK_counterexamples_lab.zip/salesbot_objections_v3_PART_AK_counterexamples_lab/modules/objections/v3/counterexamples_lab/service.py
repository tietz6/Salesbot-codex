
import os, time, json, random
from .schema import *
from .validators import basic_penalties

MICRO_TIPS = [
    "Присоединитесь к эмоции клиента.",
    "Сформулируйте уточняющий вопрос.",
    "Дайте 2 варианта и мягкое CTA.",
    "Подчеркните ценность и персонализацию."
]

DEFAULT_PATTERNS = {
    "price": {
        "template": "Понимаю про бюджет. Что важнее — скорость или индивидуальность?",
        "cta": "Сделаю 2 демо, выберем ближе и зафиксируем."
    },
    "trust": {
        "template": "Понимаю сомнения. Покажу примеры и отзывы, ок?",
        "cta": "Дам 2 фрагмента и вы оцените стиль."
    },
    "hurry": {
        "template": "С дедлайном поможем. Важнее сегодня демо или финал?",
        "cta": "Соберу короткое демо в 2-х вариантах."
    }
}

class Service:
    def __init__(self, module_slug: str):
        self.module_slug = module_slug

    async def health(self) -> HealthResponse:
        return HealthResponse(ok=True, module=self.module_slug, ts=int(time.time()))

    async def coach(self, payload: CoachRequest) -> CoachResponse:
        plan = [
            {"step":1,"say":"Признать эмоцию клиента и переформулировать вопросом."},
            {"step":2,"say":"Дать 2 альтернативы (жанр/темп/голос)."},
            {"step":3,"say":"Закрыть на мини-действие — 2 демо."},
        ]
        tips = random.sample(MICRO_TIPS, 3)
        reply = "Давайте сделаем 2 коротких демо в разном настроении — выберем сердцем?"
        return CoachResponse(
            trace_id=f"{self.module_slug}-trace",
            module=self.module_slug,
            next_utterance=reply,
            rationale="Эмпатия + выбор + CTA снижает сопротивление и открывает диалог.",
            micro_tips=tips,
            plan=plan
        )

    async def analyze(self, payload: AnalysisRequest) -> AnalysisResponse:
        pen = basic_penalties(payload.utterance)
        score = max(0, 10 - len(pen)*2)
        advice = "Добавьте уточняющий вопрос и мягко предложите следующий шаг (2 демо)."
        return AnalysisResponse(ok=True, module=self.module_slug, penalties=pen, score=score, advice=advice)

    async def patterns(self) -> PatternsResponse:
        return PatternsResponse(ok=True, module=self.module_slug, patterns=DEFAULT_PATTERNS)

_services = {}
def get_service(slug: str):
    if slug not in _services:
        _services[slug] = Service(slug)
    return _services[slug]
