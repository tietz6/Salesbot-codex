
from __future__ import annotations
import json, random
from pathlib import Path
from typing import Dict

class ClientSimulator:
    def __init__(self, emotions_path: str, reactions_path: str):
        self.em = json.loads(Path(emotions_path).read_text(encoding="utf-8"))
        self.react = json.loads(Path(reactions_path).read_text(encoding="utf-8"))
    def step(self, manager_text: str, state: Dict) -> Dict:
        mood = state.get("mood", "neutral")
        lvl = state.get("pressure", 0)
        mood_shift = 1 if len(manager_text) < 10 else (-1 if "пожалуйста" in manager_text.lower() else 0)
        mood_idx = max(0, min(len(self.em["scale"])-1, self.em["scale"].index(mood) + mood_shift))
        new_mood = self.em["scale"][mood_idx]
        reply = random.choice(self.react.get(new_mood, self.react["neutral"]))
        state.update({"mood": new_mood, "pressure": max(0, lvl + mood_shift)})
        return {"reply": reply, "state": state}
