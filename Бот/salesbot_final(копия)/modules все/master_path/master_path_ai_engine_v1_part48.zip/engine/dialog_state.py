
class DialogState:
    def __init__(self, sid: str):
        self.sid = sid
        self.stage = "greeting"
        self.history = []

    def set_stage(self, stage: str):
        self.stage = stage

    def append(self, role: str, content: str):
        self.history.append({"role": role, "content": content, "stage": self.stage})
