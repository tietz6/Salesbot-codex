# greeting stage logic
