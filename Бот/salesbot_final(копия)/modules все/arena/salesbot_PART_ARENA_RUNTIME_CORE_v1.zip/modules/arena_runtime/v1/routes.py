from fastapi import APIRouter
from pydantic import BaseModel
from .engine import ArenaEngine

router = APIRouter(prefix="/arena/v1", tags=["arena_v1"])
engine = ArenaEngine()

class StartReq(BaseModel):
    manager_id: str
    scenario: str = "warm_path"

class StepReq(BaseModel):
    sid: str
    manager_text: str

@router.get("/health")
def health():
    return {"ok": True, "module": "arena_runtime_v1"}

@router.post("/start")
def start(req: StartReq):
    return engine.start(req.manager_id, req.scenario)

@router.post("/step")
def step(req: StepReq):
    return engine.step(req.sid, req.manager_text)

@router.get("/stop/{sid}")
def stop(sid: str):
    return engine.stop(sid)
