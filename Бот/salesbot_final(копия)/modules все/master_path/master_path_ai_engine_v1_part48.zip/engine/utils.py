
def strip_text(t: str) -> str:
    return (t or "").strip()
