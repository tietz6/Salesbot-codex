PART_BB placeholder for next package.
