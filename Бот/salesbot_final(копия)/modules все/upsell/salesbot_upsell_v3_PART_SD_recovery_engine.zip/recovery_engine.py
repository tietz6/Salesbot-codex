
# Обработка «срыва почти продажи» — Recovery Engine v1
def detect_risk(reply: str):
    reply_l = reply.lower()
    if any(x in reply_l for x in ["дорого","подум","не знаю","не уверен","позже"]):
        return {"risk": True, "level": "mid"}
    if any(x in reply_l for x in ["нет","не хочу","отмена","не надо"]):
        return {"risk": True, "level": "high"}
    return {"risk": False, "level": "low"}

def build_recovery_pitch(context: dict):
    reason = context.get("reason","вопрос цены")
    return (
        "Понимаю вас. Давайте сделаем мягко. "
        f"Если дело в том, что {reason}, могу показать 2 варианта: один попроще, один премиум. "
        "Хотите сверим, какой подойдёт лучше?"
    )
