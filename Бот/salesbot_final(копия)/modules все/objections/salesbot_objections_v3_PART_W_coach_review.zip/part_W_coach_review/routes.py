from fastapi import APIRouter
from pydantic import BaseModel
from .service import run

router = APIRouter(prefix="/objections/v3/part_W_coach_review", tags=["objections/v3/part_W_coach_review"])

class Inp(BaseModel):
    context: str = ""
    utterance: str

@router.post("/run")
def _run(inp: Inp):
    return run(inp.context, inp.utterance)