
import re, json, os
from .storage import safe_lower

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "keywords.json")
with open(DATA_PATH, "r", encoding="utf-8") as f:
    KW = json.load(f)

def _score_text(txt: str, kw_list: list[str]):
    t = safe_lower(txt)
    return sum(1 for k in kw_list if k in t)

def predict_proba(manager_text: str, client_text: str, context: dict):
    # Heuristic probabilities 0..1
    m_pos = _score_text(manager_text, KW["positive_push"])
    m_value = _score_text(manager_text, KW["value"])
    m_cta = _score_text(manager_text, KW["cta"])
    c_price = _score_text(client_text, KW["price"])
    c_hes = _score_text(client_text, KW["hesitation"])
    c_happy = _score_text(client_text, KW["happy"])

    base_buy = 0.2 + 0.1*m_pos + 0.1*m_value + 0.15*m_cta + 0.1*c_happy - 0.12*c_hes - 0.08*c_price
    base_bundle = 0.15 + 0.1*m_value + 0.08*m_pos + 0.12*(1 if "видео" in manager_text.lower() else 0)
    base_two = 0.1 + 0.12*(1 if "втор" in manager_text.lower() or "2" in manager_text else 0) + 0.08*m_value

    def clamp(x): return max(0.0, min(1.0, x))
    proba = {
        "buy_now": clamp(base_buy),
        "take_bundle": clamp(base_bundle),
        "take_two_versions": clamp(base_two)
    }
    return proba

def advise_next_step(manager_text: str, client_text: str, context: dict, proba: dict):
    # Pick best next step
    best = max(proba, key=proba.get)
    if best == "buy_now":
        pitch = "Если идея откликается — давайте запустим прямо сейчас. Хотите предоплату или сразу полной оплатой?"
    elif best == "take_bundle":
        pitch = "Предлагаю пакет «Песня + видео»: получится готовый подарок сегодня. Это выгоднее, чем по отдельности."
    else:
        pitch = "Давайте сделаем две версии — они по-разному раскрывают эмоции, а вы выберете сердцем. Я дам хорошую скидку на вторую."
    # short nudge
    nudge = "Чтобы вам было приятнее, добавлю персональную скидку на второй вариант."
    return {"best": best, "pitch": pitch, "nudge": nudge}
