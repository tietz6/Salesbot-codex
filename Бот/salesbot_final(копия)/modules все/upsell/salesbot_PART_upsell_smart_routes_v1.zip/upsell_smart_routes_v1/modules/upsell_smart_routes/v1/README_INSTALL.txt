Upsell Smart Routes v1
-----------------------
Карта маршрутов апсейла по сигналам клиента.
Эндпоинты:
  GET  /upsell_smart_routes/v1/health
  POST /upsell_smart_routes/v1/start
  POST /upsell_smart_routes/v1/step
  GET  /upsell_smart_routes/v1/finalize/{session_id}
