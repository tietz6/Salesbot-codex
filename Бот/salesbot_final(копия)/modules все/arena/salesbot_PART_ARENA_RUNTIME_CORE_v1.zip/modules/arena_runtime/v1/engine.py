import time, random
from typing import Dict, Any, List, Optional
from .service import load_personas, load_scenarios, load_lexicon, pick_persona, llm_reply, new_session_id, save_session, load_session

class ArenaEngine:
    def __init__(self):
        self.lex = load_lexicon()
        self.personas = load_personas()
        self.sc_warm = load_scenarios('warm_path')
        self.sc_obj = load_scenarios('objections')
        self.sc_up = load_scenarios('upsell')
        self.sc_end = load_scenarios('endings')

    def start(self, manager_id: str, scenario: str = 'warm_path') -> dict:
        sid = new_session_id()
        persona = pick_persona(self.personas)
        state = {
            'sid': sid,
            'manager_id': manager_id,
            'persona': persona,
            'scenario': scenario,
            'history': [],
            'created_at': int(time.time()),
            'stage': 'greeting',
            'round': 0,
            'score_partial': 0
        }
        opening = persona.get('opening') or "Здравствуйте! Коротко, о чём речь?"
        state['history'].append({'role':'client','content': opening})
        save_session(sid, state)
        return {'ok': True, 'sid': sid, 'client_opening': opening, 'persona': persona}

    def step(self, sid: str, manager_text: str) -> dict:
        state = load_session(sid)
        if not state:
            return {'ok': False, 'error': 'session_not_found'}
        state['round'] += 1
        state['history'].append({'role':'manager','content': manager_text, 'stage': state.get('stage','greeting')})
        order = ['greeting','qualification','texts','demo','final']
        cur = state.get('stage','greeting')
        try:
            idx = order.index(cur)
            nxt = order[min(idx+1, len(order)-1)]
        except Exception:
            nxt = 'qualification'
        state['stage'] = nxt
        reply = llm_reply(state['history'], role='client_emotional')
        state['history'].append({'role':'client','content': reply, 'stage': nxt})
        delta = 0
        low = manager_text.lower()
        if any(w in low for w in ['расскажите','как','к кому','кому дарите','к какому событию']):
            delta += 2
        if any(w in low for w in ['сделаем два','два варианта','выберите сердцем','демо']):
            delta += 2
        if any(w in low for w in ['спасибо','благодарю','с радостью']):
            delta += 1
        state['score_partial'] += delta
        save_session(sid, state)
        return {'ok': True, 'reply': reply, 'stage': nxt, 'score_delta': delta}

    def stop(self, sid: str) -> dict:
        state = load_session(sid)
        if not state:
            return {'ok': False, 'error': 'session_not_found'}
        total = min(100, 60 + state.get('score_partial',0))
        return {'ok': True, 'sid': sid, 'total_score': total, 'rounds': state.get('round',0)}
