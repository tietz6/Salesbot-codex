
from fastapi import APIRouter
from pydantic import BaseModel
from .engine import MultiDemoEngine

router = APIRouter(prefix="/upsell_multi_demo/v1", tags=["upsell_multi_demo"])
eng = MultiDemoEngine()

class StartIn(BaseModel):
    manager_id: str
    sid: str | None = None

class AttachIn(BaseModel):
    sid: str
    label: str
    url_or_note: str

class ReactIn(BaseModel):
    sid: str
    client_text: str

@router.get("/health")
def health():
    return {"ok": True, "module":"upsell_multi_demo_logic.v1"}

@router.post("/start")
def start(inp: StartIn):
    return eng.start(inp.manager_id, sid=inp.sid)

@router.post("/attach_demo")
def attach_demo(inp: AttachIn):
    return eng.attach_demo(inp.sid, inp.label, inp.url_or_note)

@router.post("/react")
def react(inp: ReactIn):
    return eng.react(inp.sid, inp.client_text)
