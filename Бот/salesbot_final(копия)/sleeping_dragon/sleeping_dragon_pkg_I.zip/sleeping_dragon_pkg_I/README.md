# Package I — Official Branded Replies (RU/KY/EN)
- Stages: greeting, qualification, support, offer, demo, final, upsell, payment, objection_soft, followup
- For each stage: RU/KY/EN + short/medium/long variants
- Files: official_responses/<stage>/<lang>/{short|medium|long}.md + bundle.json
- Use: select by stage → lang → length; rotate variants for freshness.
