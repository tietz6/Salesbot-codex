# qualification stage
