
from .weights import WEIGHTS
def score_reply(text:str)->float:
    s=0.0
    if '?' in text: s+=WEIGHTS['question']
    if len(text)>=60: s+=WEIGHTS['length']
    if any(x in text.lower() for x in ['прекрасно','рады','тепло','забота']): s+=WEIGHTS['warmth']
    return round(min(1.0,s),3)
