
import json, os, random, pathlib

# лёгкий форматтер, имитирующий фирменный стиль
def apply_persona(role: str, text: str) -> str:
    if role == "coach":
        prefix = "💡 Совет коуча: "
        suffix = " 🌿"
    else:
        prefix = ""
        suffix = ""
    emojis = ["🌸","✨","🥰","💛","🌿","🎶"]
    return f"{prefix}{text.strip()} {random.choice(emojis)}{suffix}"
