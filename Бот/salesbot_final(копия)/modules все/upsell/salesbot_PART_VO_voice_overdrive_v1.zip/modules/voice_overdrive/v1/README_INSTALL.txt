# Voice Overdrive v1 (PART_VO)
Живой модуль ускорения реакции клиента и динамики эмоций под апсейл.

## Возможности
- Эмо‑модель: calm → neutral → annoyed → angry → excited (с мягкими переходами)
- Быстрые ответы клиента (через DeepSeek, если доступен) + качественный fallback
- Метрики каждого шага: tempo, empathy, clarity, pressure, emotion_label
- Хранение сессий: через core.state.v1 (если есть) или in-memory fallback
- Встроенный стиль бренда («На Счастье»): тёплый, уважительный тон

## Эндпоинты
- GET  /voice_overdrive/v1/health
- POST /voice_overdrive/v1/start        {manager_id, context?}
- POST /voice_overdrive/v1/tune         {session_id, params{emotion,pressure,tempo}}
- POST /voice_overdrive/v1/step         {session_id, text, features?}
- GET  /voice_overdrive/v1/stop/{session_id}

## Установка
1) Распаковать в проект
2) Автосборщик подключит маршруты автоматически (см. manifest.json)
3) Запуск: uvicorn startup:app --port 8080
