# Package S — Coaching Scripts Pro
- scripts/<stage>/<lang>/scripts.json — 100 скриптов на этап и язык (RU/KY/EN)
- transitions/<ru|ky|en>.json — плавные переходы (оплата, апсейл, демо)
- personas/styles.json — пресеты фирменного тона
