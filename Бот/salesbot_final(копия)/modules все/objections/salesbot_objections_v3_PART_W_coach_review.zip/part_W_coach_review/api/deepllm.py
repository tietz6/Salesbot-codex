import os, json

class DeepLLM:
    def __init__(self):
        key = os.getenv("DEEPSEEK_API_KEY", "")
        if not key:
            raise RuntimeError("DEEPSEEK_API_KEY is missing")
        self.key = key

    def chat(self, messages, **opts):
        # Placeholder transport. Replace with real HTTP call.
        # We keep interface consistent so router can swap providers.
        text = messages[-1].get("content","")
        return {
            "ok": True,
            "provider": "deepseek",
            "usage": {"prompt_tokens": len(str(messages))//3, "completion_tokens": 120},
            "message": f"[ai:{opts.get('model','chat')}] Ответ на: {text[:200]}"
        }