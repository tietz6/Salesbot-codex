
from pydantic import BaseModel
from typing import List, Dict, Any

class CoachRequest(BaseModel):
    dialog: List[Dict[str, Any]]
    goal: str = "soft_close"
    persona: str = "mentor"

class CoachResponse(BaseModel):
    trace_id: str
    module: str
    next_utterance: str
    rationale: str
    micro_tips: List[str]
    plan: List[Dict[str, Any]]
