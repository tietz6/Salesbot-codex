# upsell chain reactor module
