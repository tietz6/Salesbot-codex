
"""
Rule heuristics for stage transitions and basic scoring.
"""
import re
from typing import Dict

KEYWORDS = {
    "greeting": ["привет", "добрый", "здравствуйте", "доброго"],
    "qualification": ["как зовут", "сколько", "когда", "где", "к кому"],
    "warmup": ["красиво", "трогательно", "история", "эмоции", "детали"],
    "texts": ["текст", "черновик", "вариант", "набросок"],
    "genre": ["жанр", "поп", "лирик", "роман", "рэп", "исполнит"],
    "payment": ["оплата", "предоплат", "перевод", "к оплате"],
    "demo_cycle": ["демо", "вариант а", "вариант b", "послушайте"],
    "finish": ["готово", "финал", "спасибо", "доставка"]
}

NEXT = {
    "greeting": "qualification",
    "qualification": "warmup",
    "warmup": "texts",
    "texts": "genre",
    "genre": "payment",
    "payment": "demo_cycle",
    "demo_cycle": "finish",
    "finish": "finish"
}

def guess_stage(user_text: str, current: str) -> str:
    t = (user_text or "").lower()
    # if contains a keyword of a later stage, consider moving forward
    for stage, kws in KEYWORDS.items():
        if any(k in t for k in kws):
            return stage
    return current or "greeting"

def next_stage(current: str) -> str:
    return NEXT.get(current or "greeting", "finish")

def score_snippet(user_text: str, stage: str) -> int:
    """Very light score 0..5 based on presence of stage keywords."""
    t = (user_text or "").lower()
    match = sum(1 for k in KEYWORDS.get(stage, []) if k in t)
    return max(0, min(5, match))
