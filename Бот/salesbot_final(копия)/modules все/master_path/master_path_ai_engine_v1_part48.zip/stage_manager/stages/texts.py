def handle(text:str)->str:
    return 'Готовим два текста A/B по вашей истории. '