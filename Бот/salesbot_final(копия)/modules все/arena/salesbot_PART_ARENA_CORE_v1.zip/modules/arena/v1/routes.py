
from fastapi import APIRouter, Body
from . import service

router = APIRouter(prefix="/arena/v1", tags=["arena.v1"])

@router.get("/health")
def health():
    return {"ok": True, "module": "arena.v1"}

@router.post("/start")
def start(payload: dict = Body(...)):
    mid = payload.get("manager_id","unknown")
    ctx = payload.get("context")
    return service.start(mid, ctx)

@router.post("/step/{sid}")
def step(sid: str, payload: dict = Body(...)):
    text = payload.get("text","").strip()
    return service.step(sid, text)

@router.get("/stop/{sid}")
def stop(sid: str):
    return service.stop(sid)

@router.get("/snapshot/{sid}")
def snapshot(sid: str):
    return service.snapshot(sid)
