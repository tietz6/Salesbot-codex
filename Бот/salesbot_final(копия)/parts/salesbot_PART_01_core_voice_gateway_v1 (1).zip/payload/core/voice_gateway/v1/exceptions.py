
class NotConfigured(Exception):
    pass
class ProviderError(Exception):
    pass
