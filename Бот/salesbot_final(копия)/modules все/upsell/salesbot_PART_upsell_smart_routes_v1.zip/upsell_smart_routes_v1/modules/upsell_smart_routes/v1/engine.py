
from __future__ import annotations
import json, os
from dataclasses import dataclass, field
from typing import List, Dict

def _lower(s: str) -> str:
    try:
        return (s or "").lower()
    except:
        return ""

def load_rules() -> dict:
    path = os.path.join(os.path.dirname(__file__), "data", "rules.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

RULES = load_rules()

@dataclass
class Session:
    session_id: str
    flow: str = ""
    cursor: int = 0
    history: List[Dict] = field(default_factory=list)
    score: int = 0

class SmartRoutes:
    def __init__(self):
        self.mem: Dict[str, Session] = {}

    def start(self, session_id: str, last_client_text: str = "") -> dict:
        flow = self._pick_flow(last_client_text)
        sess = Session(session_id=session_id, flow=flow, cursor=0)
        self.mem[session_id] = sess
        return {"ok": True, "session_id": session_id, "flow": flow, "next": self._current_step_text(sess)}

    def step(self, session_id: str, manager_text: str, client_text: str = "") -> dict:
        s = self.mem.get(session_id)
        if not s:
            return {"ok": False, "error": "session_not_found"}
        s.history.append({"manager": manager_text, "client": client_text})
        # простое повышение score за наличие CTA/ценности
        m = _lower(manager_text)
        if any(k in m for k in RULES["keywords"]["ready"]): s.score += 8
        if any(k in m for k in RULES["keywords"]["demo"]): s.score += 5
        if "видео" in m: s.score += 6
        s.cursor += 1
        nxt = self._current_step_text(s)
        done = (nxt is None)
        return {"ok": True, "done": done, "next": nxt, "score": min(100, s.score)}

    def finalize(self, session_id: str) -> dict:
        s = self.mem.get(session_id)
        if not s:
            return {"ok": False, "error": "session_not_found"}
        return {"ok": True, "summary": {
            "flow": s.flow,
            "steps": len(s.history),
            "score": min(100, s.score),
        }}

    def _pick_flow(self, client_text: str) -> str:
        t = _lower(client_text)
        K = RULES["keywords"]
        entry = RULES["entry"]
        if any(k in t for k in K["price"]): return entry["if_price"]
        if any(k in t for k in K["demo"]): return entry["if_demo"]
        if any(k in t for k in K["ready"]): return entry["if_ready"]
        if any(k in t for k in K["unsure"]): return entry["if_unsure"]
        return entry["fallback"]

    def _current_step_text(self, s: Session) -> str | None:
        seq = RULES["flows"].get(s.flow, [])
        if s.cursor >= len(seq): return None
        step_key = seq[s.cursor]
        return RULES["steps"].get(step_key, None)
