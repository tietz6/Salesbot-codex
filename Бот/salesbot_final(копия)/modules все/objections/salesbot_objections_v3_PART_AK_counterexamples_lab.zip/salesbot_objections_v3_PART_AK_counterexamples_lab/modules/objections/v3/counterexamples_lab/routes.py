
from fastapi import APIRouter, HTTPException
from .schema import *
from .service import get_service

router = APIRouter(prefix="/objections/{module_slug}", tags=["objections"])

@router.get("/health", response_model=HealthResponse)
async def health(module_slug: str):
    try:
        svc = get_service(module_slug)
        return await svc.health()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/coach", response_model=CoachResponse)
async def coach(module_slug: str, payload: CoachRequest):
    try:
        svc = get_service(module_slug)
        return await svc.coach(payload)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/analyze", response_model=AnalysisResponse)
async def analyze(module_slug: str, payload: AnalysisRequest):
    try:
        svc = get_service(module_slug)
        return await svc.analyze(payload)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/patterns", response_model=PatternsResponse)
async def patterns(module_slug: str):
    try:
        svc = get_service(module_slug)
        return await svc.patterns()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
