
import re, json
from typing import Dict, List

# very light heuristic extractor; LLM-enhanced later
def load_patterns(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def extract_entities(text: str, patterns: Dict) -> Dict:
    res = {"names": [], "dates": [], "kids": [], "pets": [], "events": [], "notes": []}
    t = text.strip()
    for rx in patterns.get("names", []):
        res["names"] += re.findall(rx, t, flags=re.IGNORECASE)
    for rx in patterns.get("dates", []):
        res["dates"] += re.findall(rx, t, flags=re.IGNORECASE)
    for rx in patterns.get("kids", []):
        res["kids"] += re.findall(rx, t, flags=re.IGNORECASE)
    for rx in patterns.get("pets", []):
        res["pets"] += re.findall(rx, t, flags=re.IGNORECASE)
    for rx in patterns.get("events", []):
        res["events"] += re.findall(rx, t, flags=re.IGNORECASE)
    # Fallback: collect nice notes sentences (simple heuristic)
    for m in re.findall(r'[^.!?\n]{12,120}[.!?]', t):
        if any(w in m.lower() for w in ["любов", "вместе", "встретил", "встретились", "семь", "дети", "мама", "папа", "свад", "годов"]):
            res["notes"].append(m.strip())
    # dedupe & trim
    for k in res:
        if isinstance(res[k], list):
            res[k] = [s.strip() for s in dict.fromkeys(res[k])]
    return res
