import json
import time
from typing import Dict, Any

class _MemoryStore:
    def __init__(self):
        self.db: Dict[str, str] = {}
    def get(self, key: str):
        return self.db.get(key)
    def set(self, key: str, val: str):
        self.db[key] = val
    def scan(self, prefix: str, limit: int = 100):
        return [(k, v) for k, v in self.db.items() if k.startswith(prefix)][:limit]
    def delete(self, key: str):
        return 1 if self.db.pop(key, None) is not None else 0

def _load_kv():
    try:
        from core.state.v1 import StateStore  # type: ignore
        return StateStore("salesbot.db")
    except Exception:
        return _MemoryStore()

KV = _load_kv()

def kv_get_json(key: str):
    raw = KV.get(key)
    if not raw: return None
    try:
        return json.loads(raw)
    except Exception:
        return None

def kv_set_json(key: str, obj: Any):
    try:
        KV.set(key, json.dumps(obj, ensure_ascii=False))
        return True
    except Exception:
        return False
