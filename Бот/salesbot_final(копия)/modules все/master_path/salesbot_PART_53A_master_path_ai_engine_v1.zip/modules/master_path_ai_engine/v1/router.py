
from fastapi import APIRouter
from pydantic import BaseModel
from .engine.pipeline import MasterPathPipeline

router = APIRouter(prefix="/master_path_ai/v1", tags=["master_path_ai"])
PIPE = MasterPathPipeline()

class StartOut(BaseModel):
    sid: str
    stage: str

class StepIn(BaseModel):
    sid: str
    text: str

@router.get("/health")
def health():
    return {"ok": True, "module": "master_path_ai_engine.v1"}

@router.post("/start", response_model=StartOut)
def start():
    st = PIPE.start()
    return {"sid": st.sid, "stage": st.stage}

@router.post("/step")
def step(body: StepIn):
    return PIPE.step(body.sid, body.text)

@router.get("/snapshot/{sid}")
def snapshot(sid: str):
    return PIPE.snapshot(sid)
