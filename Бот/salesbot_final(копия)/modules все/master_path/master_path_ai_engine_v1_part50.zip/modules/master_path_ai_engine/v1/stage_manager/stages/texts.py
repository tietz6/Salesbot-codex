
def handle(text: str, ctx: dict) -> dict:
    return {"stage": "texts", "ok": True, "hint": "brand-tone"}
