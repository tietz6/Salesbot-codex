def handle(text:str)->str:
    return 'Спасибо за доверие! Готовы перейти к финальному шагу? '