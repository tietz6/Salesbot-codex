
PART 19 — Public & Admin API (v1)

Публичные эндпоинты:
  GET /api/public/v1/ping
  GET /api/public/v1/version
  GET /api/public/v1/health

Админ эндпоинты:
  GET /api/admin/v1/db_keys
  GET /api/admin/v1/stats

Установка:
  ADD_ONLY → api/public/v1
  ADD_ONLY → api/admin/v1
