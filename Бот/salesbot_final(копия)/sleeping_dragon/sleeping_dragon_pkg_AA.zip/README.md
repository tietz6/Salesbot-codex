# Package AA — Checklists, FAQ, Voice Calibration, Brand Prompts, Playbooks
- aa_checklists/stage_checklists_*.json — чек-листы этапов (RU/KY/EN)
- aa_faq/objections_faq_*.json — ответы на частые вопросы (RU/KY/EN)
- aa_voice_calibration/*.json — пороги и примеры метрик речи
- aa_brand_prompts/*.json — фирменные подсказки для коуча/клиента
- aa_playbooks/*.md — плейбуки восстановления и допродаж
