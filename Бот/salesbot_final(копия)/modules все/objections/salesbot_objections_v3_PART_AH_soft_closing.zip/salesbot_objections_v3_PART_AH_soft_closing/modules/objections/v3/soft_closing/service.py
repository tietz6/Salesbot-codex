
import re, os, asyncio, random
from .schema import *

class Service:
    async def coach(self, module_slug: str, payload: CoachRequest) -> CoachResponse:
        plan = [
            {"step":1,"say":"Присоединяюсь к вашим чувствам и уточняю, что важнее."},
            {"step":2,"say":"Даю два направления — более лирично или бодро-поп."},
            {"step":3,"say":"Подтверждаю следующий шаг: делаю 2 демо и присылаю."},
        ]
        tips = ["Мягко признать эмоцию", "Дать альтернативу 2-вариантов", "Закрыть на действие"]
        return CoachResponse(
            trace_id=f"{module_slug}-trace",
            module=module_slug,
            next_utterance="Готов прислать 2 демо в разном настроении — выберем сердцем?",
            rationale="Эмпатия + выбор + CTA снижает сопротивление.",
            micro_tips=tips,
            plan=plan
        )

    async def metrics(self, module_slug: str, payload: MetricsRequest) -> MetricsResponse:
        txt = payload.last_reply.strip()
        length = len(txt)
        has_q = "?" in txt
        empathy = 0.9 if any(w in txt.lower() for w in ["понимаю","вижу","слыш","важно"]) else 0.5
        clarity = 0.9 if length>12 and "." in txt else 0.6
        hint = "Добавьте уточняющий вопрос." if not has_q else "Закройте на микро-действие."
        return MetricsResponse(ok=True, module=module_slug, length=length, has_question=has_q, empathy=empathy, clarity=clarity, next_hint=hint)

_svc = Service()
def get_service():
    return _svc
