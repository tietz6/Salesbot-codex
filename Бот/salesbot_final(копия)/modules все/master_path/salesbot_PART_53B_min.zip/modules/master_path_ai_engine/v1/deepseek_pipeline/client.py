class DeepSeekClient:
    def chat(self, messages, temperature=0.6, system=None):
        return 'Тёплый брендовый ответ (fallback).'
client=DeepSeekClient()
