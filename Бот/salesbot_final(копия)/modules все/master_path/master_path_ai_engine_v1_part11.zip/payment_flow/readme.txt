PART 11 payment_flow placeholders
