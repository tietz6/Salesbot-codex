
import json, time
from typing import Any, Dict, List, Optional

try:
    from core.state.v1 import StateStore  # type: ignore
except Exception:
    StateStore = None  # type: ignore

# необязательные зависимости
_analyzer = None
try:
    from modules.master_path_ai_engine.v1.heuristics.analyzer import analyze_history  # type: ignore
    _analyzer = analyze_history
except Exception:
    pass

_pipeline = None
try:
    from core.voice_gateway.v1 import VoicePipeline  # type: ignore
    _pipeline = VoicePipeline()
except Exception:
    pass

_dialog_api = None
try:
    # модуль памяти диалогов (опционально)
    from modules.dialog_memory.v1 import api as dialog_api  # type: ignore
    _dialog_api = dialog_api
except Exception:
    pass

class Finalizer:
    KEY_PREFIX = "mp_final:"

    def __init__(self, state_store):
        self.kv = state_store
        # подгрузим рекомендации
        try:
            import importlib.resources as r
            with r.open_text(__package__, "recommendations.json", encoding="utf-8") as fh:
                self.reco = json.load(fh)
        except Exception:
            self.reco = {
                "issues_map": {},
                "generic_tips": ["Держите тёплый тон", "Добавляйте уточняющий вопрос", "Коротко формулируйте ценность"]
            }

    def _k(self, sid: str) -> str:
        return f"{self.KEY_PREFIX}{sid}"

    def _save(self, sid: str, data: Dict[str, Any]) -> None:
        try:
            self.kv.set(self._k(sid), json.dumps(data, ensure_ascii=False))
        except Exception:
            pass

    def _score_fallback(self, history: List[Dict[str, Any]]) -> Dict[str, Any]:
        # если эвристик нет — простая эвристика
        text = " ".join([h.get("content","") for h in history if h.get("role")=="manager"])[:2000]
        # примитивные показатели
        warm = 1 if any(x in text.lower() for x in ["здравствуйте", "добрый"]) else 0
        ask = text.count("?")
        value = 1 if any(x in text.lower() for x in ["сделаем", "для вас", "удобно", "подарок"]) else 0
        total = min(100, warm*20 + min(30, ask*5) + value*20 + 30)
        details = {"warmth": warm*20, "questions": min(30, ask*5), "value": value*20, "base": 30}
        return {"total": total, "details": details}

    def _make_text(self, summary: Dict[str, Any]) -> str:
        bullet = []
        bullet.append(f"Итоговый балл: {summary['score']['total']} / 100.")
        if summary.get("strengths"):
            bullet.append("Сильные стороны: " + "; ".join(summary["strengths"]) + ".")
        if summary.get("issues"):
            bullet.append("Зоны роста: " + "; ".join(summary["issues"]) + ".")
        if summary.get("next_steps"):
            bullet.append("Следующие шаги: " + "; ".join(summary["next_steps"]) + ".")
        base = " ".join(bullet)
        if _pipeline:
            try:
                out = _pipeline.llm.chat([
                    {"role":"system","content":"Стилизуй под тёплый, уверенный, краткий отчёт коуча бренда «На Счастье»."},
                    {"role":"user","content": base}
                ])
                return out.strip() if out else base
            except Exception:
                return base
        return base

    def finish(self, sid: str, history: List[Dict[str, Any]], manager_id: Optional[str]=None) -> Dict[str, Any]:
        # 1) скоринг
        if _analyzer:
            try:
                metrics = _analyzer(history)
                total = max(0, min(100, int(metrics.get("total_score", 0))))
                score = {"total": total, "details": metrics}
            except Exception:
                score = self._score_fallback(history)
        else:
            score = self._score_fallback(history)

        # 2) извлечь issues/strengths по простым правилам
        issues, strengths = [], []
        text_all = " ".join([x.get("content","").lower() for x in history if x.get("role")=="manager"])
        if text_all.count("?") < 2:
            issues.append("Мало уточняющих вопросов")
        else:
            strengths.append("Есть вопросы на выяснение потребностей")
        if any(w in text_all for w in ["подарок","для вас","приятно","спасибо"]):
            strengths.append("Тёплый, ориентированный на клиента тон")
        else:
            issues.append("Слабый тёплый тон")

        # 3) рекомендации
        tips = []
        issues_map = self.reco.get("issues_map", {})
        for iss in issues:
            for k, v in issues_map.items():
                if k in iss:
                    tips.extend(v)
        if not tips:
            tips = self.reco.get("generic_tips", [])

        summary = {
            "ok": True,
            "sid": sid,
            "score": score,
            "issues": issues,
            "strengths": strengths,
            "next_steps": tips,
            "ts": int(time.time())
        }

        # 4) текст отчёта
        summary["report_text"] = self._make_text(summary)

        # 5) сохранить в KV
        self._save(sid, summary)

        # 6) записать в память диалогов (если доступна)
        try:
            if _dialog_api and manager_id:
                _dialog_api.save_summary(manager_id=manager_id, sid=sid, summary=summary)  # type: ignore
        except Exception:
            pass

        return summary
