
import os, random, time
from typing import Dict, Any, List
from .utils import read_jsonl, read_yaml, safe_join
try:
    from core.state.v1 import StateStore  # KV на SQLite
except Exception:
    StateStore = None
try:
    from core.voice_gateway.v1 import VoicePipeline  # DeepSeek-совместимый интерфейс
except Exception:
    VoicePipeline = None

class ArenaService:
    def __init__(self, base_dir=None, db_path="salesbot.db", lang="ru"):
        self.base_dir = base_dir or os.path.dirname(__file__)
        self.lang = lang
        self.cfg = read_yaml(safe_join(self.base_dir, "config.yaml"), default={})
        self.kv = StateStore(db_path) if StateStore else None
        self.pipeline = VoicePipeline() if VoicePipeline else None
        self.cache = {}
        self._load_all()

    # ----- content loading -----
    def _load_all(self):
        p = self.cfg.get("content_paths", {})
        # personas
        core = read_jsonl(safe_join(self.base_dir, p.get("personas_core","")))
        ext  = read_jsonl(safe_join(self.base_dir, p.get("personas_ext","")))
        self.cache["personas"] = (core or []) + (ext or [])
        # scenarios
        scp = p.get("scenarios", {})
        scenarios = {k: read_jsonl(safe_join(self.base_dir, v)) for k, v in scp.items()}
        self.cache["scenarios"] = scenarios
        # language kits
        lkp = p.get("language_kits", {})
        ru = lkp.get("ru", {}); ky = lkp.get("ky", {})
        self.cache["lang_ru"] = {
            "lexicon": read_jsonl(safe_join(self.base_dir, ru.get("lexicon",""))),
            "analogies": read_jsonl(safe_join(self.base_dir, ru.get("analogies",""))),
        }
        self.cache["lang_ky"] = {
            "lexicon": read_jsonl(safe_join(self.base_dir, ky.get("lexicon",""))),
            "analogies": read_jsonl(safe_join(self.base_dir, ky.get("analogies",""))),
        }
        # rubrics
        rb = p.get("rubrics", {})
        self.cache["rubrics"] = {
            "scoring": read_yaml(safe_join(self.base_dir, rb.get("scoring","")), default={}),
            "dragon": read_yaml(safe_join(self.base_dir, rb.get("dragon","")), default={}),
            "feedback_tpl": self._read_text(safe_join(self.base_dir, rb.get("feedback",""))),
        }

    def _read_text(self, path):
        if not os.path.exists(path): return ""
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    # ----- sessions -----
    def _sid_key(self, manager_id, sid):
        return f"arena:v1:{manager_id}:{sid}"

    def start(self, manager_id:str, context:Dict[str,Any]=None) -> Dict[str,Any]:
        sid = f"a{int(time.time()*1000)}{random.randint(100,999)}"
        state = {
            "manager_id": manager_id,
            "sid": sid,
            "lang": self.lang,
            "history": [],
            "persona": self._pick_persona(),
            "scenario": "warm_path",
            "score": 0,
            "meta": {"context": context or {}}
        }
        self._save(state)
        reply = self._client_reply("Здравствуйте! Расскажите, для кого готовим подарок?")
        state["history"].append({"role":"client","content": reply})
        self._save(state)
        return {"ok": True, "sid": sid, "state": self._public_state(state)}

    def step(self, manager_id:str, sid:str, text:str) -> Dict[str,Any]:
        state = self._load(manager_id, sid)
        if not state: 
            return {"ok": False, "error": "session_not_found"}
        state["history"].append({"role":"manager","content": text})
        # basic score bump by heuristics
        if len(text) >= 15: state["score"] += 1
        if "?" in text: state["score"] += 1
        # client reply via LLM (graceful fallback)
        reply = self._client_reply(text)
        state["history"].append({"role":"client","content": reply})
        self._save(state)
        return {"ok": True, "state": self._public_state(state), "client_reply": reply}

    def snapshot(self, manager_id:str, sid:str) -> Dict[str,Any]:
        state = self._load(manager_id, sid)
        if not state: 
            return {"ok": False, "error": "session_not_found"}
        return {"ok": True, "state": self._public_state(state)}

    # ----- helpers -----
    def _public_state(self, state):
        return {
            "sid": state["sid"],
            "lang": state["lang"],
            "persona": state["persona"],
            "score": state["score"],
            "last_messages": state["history"][-6:],
        }

    def _save(self, state):
        if self.kv:
            self.kv.set(self._sid_key(state["manager_id"], state["sid"]), json_dumps(state))
        else:
            # in-memory fallback (unsafe across processes)
            setattr(self, "_mem", getattr(self, "_mem", {}))
            self._mem[self._sid_key(state["manager_id"], state["sid"])] = state

    def _load(self, manager_id, sid):
        key = self._sid_key(manager_id, sid)
        if self.kv:
            raw = self.kv.get(key)
            return json_loads(raw) if raw else None
        else:
            return getattr(self, "_mem", {}).get(key)

    def _pick_persona(self):
        persons = self.cache.get("personas", [])
        if not persons:
            return {"id":"generic","style":"нейтральный"}
        return random.choice(persons)

    def _client_reply(self, manager_text:str)->str:
        prompt = self._build_prompt(manager_text)
        if self.pipeline and hasattr(self.pipeline, "llm"):
            try:
                return self.pipeline.llm.chat([
                    {"role":"system","content":prompt["system"]},
                    {"role":"user","content":prompt["user"]}
                ])
            except Exception:
                pass
        # graceful fallback
        return "Понимаю вас. Давайте уточним пару деталей, чтобы сделать песню именно по вашей истории 🌿"

    def _build_prompt(self, manager_text:str)->dict:
        persona = self._pick_persona()
        sys = "Ты — клиент бренда «На Счастье». Говори тёпло и реалистично, отвечай коротко (1–3 фразы)."
        usr = f"Менеджер сказал: «{manager_text}». Персона: {persona.get('style','нейтральный')}."
        return {"system": sys, "user": usr}

# small JSON helpers without importing extra deps
def json_dumps(obj):
    import json
    return json.dumps(obj, ensure_ascii=False)
def json_loads(s):
    import json
    return json.loads(s or "{}")
