
import re, math, time
def analyze_turn(text:str)->dict:
    t = text or ""
    low = t.lower()
    # naive proxies
    speed_score = 0.8 if len(t.split())>8 else 0.6
    contains_question = "?" in t
    clarity = 0.8 if len(t) < 280 else 0.6
    warmth = 0.9 if any(x in low for x in ["спасибо","пожалуйста","рад","рада","прекрасно"]) else 0.7
    cta = 0.9 if contains_question else 0.6
    # emotion label
    if any(x in low for x in ["дорого","неверю","обман","потом"]):
        emotion = "neutral"
    elif any(x in low for x in ["спасибо","понравилось","здорово","класс"]):
        emotion = "positive"
    else:
        emotion = "neutral"
    return {
        "ts": time.time(),
        "speed_score": round(speed_score,2),
        "clarity_score": round(clarity,2),
        "warmth_score": round(warmth,2),
        "cta_score": round(cta,2),
        "label": emotion
    }
