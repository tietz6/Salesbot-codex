
from fastapi import APIRouter
from pydantic import BaseModel
from .engine import SmartRoutes

router = APIRouter(prefix="/upsell_smart_routes/v1", tags=["upsell_smart_routes"])
engine = SmartRoutes()

class StartIn(BaseModel):
    session_id: str
    last_client_text: str | None = ""

class StepIn(BaseModel):
    session_id: str
    manager_text: str
    client_text: str | None = ""

@router.get("/health")
def health():
    return {"ok": True, "module": "upsell_smart_routes.v1"}

@router.post("/start")
def start(inp: StartIn):
    return engine.start(inp.session_id, last_client_text=inp.last_client_text or "")

@router.post("/step")
def step(inp: StepIn):
    return engine.step(inp.session_id, inp.manager_text, inp.client_text or "")

@router.get("/finalize/{session_id}")
def finalize(session_id: str):
    return engine.finalize(session_id)
