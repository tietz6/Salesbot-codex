from __future__ import annotations
import json
from pathlib import Path
DEFAULT = {
  "coach": "Ты тёплый коуч бренда «На Счастье». 1–2 фразы + 1 уточнение.",
  "client": "Ты реалистичный клиент. 1–3 короткие фразы."
}
def load_prompts(path: str):
    p = Path(path)
    if p.exists():
        return json.loads(p.read_text(encoding='utf-8'))
    return DEFAULT
