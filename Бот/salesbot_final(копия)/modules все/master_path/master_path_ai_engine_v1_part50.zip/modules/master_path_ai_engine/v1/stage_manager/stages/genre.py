
def handle(text: str, ctx: dict) -> dict:
    return {"stage": "genre", "ok": True, "hint": "brand-tone"}
