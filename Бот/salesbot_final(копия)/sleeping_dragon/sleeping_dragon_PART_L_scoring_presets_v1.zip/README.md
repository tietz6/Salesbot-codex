# PART L — Scoring Presets
Готовые пресеты весов, штрафов и формул для разных режимов (soft/aggressive/exam/arena).
