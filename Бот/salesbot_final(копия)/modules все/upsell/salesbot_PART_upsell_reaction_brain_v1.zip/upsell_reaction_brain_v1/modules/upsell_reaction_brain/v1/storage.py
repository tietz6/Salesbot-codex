
import json, os, threading
from typing import Any, Optional

def safe_lower(x: str) -> str:
    try:
        return (x or "").lower()
    except:
        return ""

class Storage:
    def __init__(self, namespace: str = "default"):
        self.ns = namespace
        self._lock = threading.Lock()
        self._mem = {}
        # Try import StateStore if available
        self._kv = None
        try:
            from core.state.v1 import StateStore  # type: ignore
            self._kv = StateStore("salesbot.db")
        except Exception:
            self._kv = None

    def _k(self, k: str) -> str:
        return f"{self.ns}:{k}"

    def get(self, key: str) -> Optional[dict]:
        K = self._k(key)
        if self._kv:
            raw = self._kv.get(K)
            if raw is None:
                return None
            try:
                return json.loads(raw)
            except Exception:
                return None
        return self._mem.get(K)

    def set(self, key: str, value: dict) -> None:
        K = self._k(key)
        if self._kv:
            self._kv.set(K, json.dumps(value, ensure_ascii=False))
        else:
            self._mem[K] = value
