
Place this into salesbot/core/acl/v1
Exposes:
  - Role, Permission, PERMISSIONS_BY_ROLE
  - has_permission(), require_permission()
  - ACLMiddleware (Starlette-compatible)
