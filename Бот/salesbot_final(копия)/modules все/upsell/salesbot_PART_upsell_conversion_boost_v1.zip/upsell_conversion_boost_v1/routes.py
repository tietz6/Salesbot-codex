
from fastapi import APIRouter
from .engine import ConversionBoost

router = APIRouter(prefix="/upsell_conversion_boost/v1", tags=["upsell_conversion"])
boost = ConversionBoost()

@router.get("/health")
def health():
    return {"ok": True}

@router.post("/start")
def start(session_id: str):
    return boost.start(session_id)

@router.post("/step")
def step(session_id: str, manager_text: str, client_state: dict):
    return boost.record(session_id, manager_text, client_state)

@router.get("/finalize/{session_id}")
def finalize(session_id: str):
    return boost.finalize(session_id)
