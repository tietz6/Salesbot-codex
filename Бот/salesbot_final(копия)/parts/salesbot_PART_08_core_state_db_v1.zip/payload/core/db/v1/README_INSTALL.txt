SQLite wrapper for salesbot
