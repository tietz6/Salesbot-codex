from fastapi.testclient import TestClient
from fastapi import FastAPI
from .routes import router

app = FastAPI()
app.include_router(router)

def test_smoke():
    if "DEEPSEEK_API_KEY" not in os.environ:
        # Skip when key missing in CI
        return
    client = TestClient(app)
    r = client.post("/objections/v3/part_W_coach_review/run", json={"context":"", "utterance":"Цена?"})
    assert r.status_code in (200, 500)