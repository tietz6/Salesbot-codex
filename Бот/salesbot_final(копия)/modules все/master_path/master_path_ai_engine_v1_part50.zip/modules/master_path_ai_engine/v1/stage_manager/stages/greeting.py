
def handle(text: str, ctx: dict) -> dict:
    return {"stage": "greeting", "ok": True, "hint": "brand-tone"}
