from __future__ import annotations
from typing import List, Dict
try:
    from core.voice_gateway.v1 import VoicePipeline
except Exception:
    VoicePipeline = None
def chat(messages: List[Dict[str,str]], fallback_note: str = "") -> str:
    if VoicePipeline is not None:
        try:
            vp = VoicePipeline()
            out = vp.llm.chat(messages)
            if out and isinstance(out, str):
                return out
        except Exception:
            pass
    last = next((m["content"] for m in reversed(messages) if m.get("role")=='user'), "")
    hint = (fallback_note or "Тёплый бренд‑совет: коротко, с ценностью и 1 уточнением.")
    return f"{hint}\nОтвет: {last[:180]}..."
