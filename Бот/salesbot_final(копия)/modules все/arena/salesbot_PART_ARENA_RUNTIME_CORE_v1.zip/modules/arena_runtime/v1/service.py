import os, json, time, uuid, random, glob
from typing import Dict, Any, List, Optional

def _try_import(path):
    try:
        module = __import__(path, fromlist=['*'])
        return module
    except Exception:
        return None

# Soft deps
state_mod = _try_import('core.state.v1')
kv = getattr(state_mod, 'StateStore', None)
voice_mod = _try_import('core.voice_gateway.v1')
VoicePipeline = getattr(voice_mod, 'VoicePipeline', None)
persona_mod = _try_import('modules.deepseek_persona.v1')
persona_chat = getattr(persona_mod, 'persona_chat', None)

BASE_CONTENT = os.environ.get('ARENA_CONTENT_BASE', 'modules/arena/v1')

def _read_jsonl(path: str) -> List[dict]:
    if not os.path.exists(path):
        return []
    out = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
    return out

def load_personas() -> List[dict]:
    path = os.path.join(BASE_CONTENT, 'personas', 'personas_core.jsonl')
    return _read_jsonl(path)

def load_scenarios(name: str) -> List[dict]:
    path = os.path.join(BASE_CONTENT, 'scenarios', f'{name}.jsonl')
    return _read_jsonl(path)

def load_lexicon() -> Dict[str, Any]:
    path = os.path.join(BASE_CONTENT, 'language_kits', 'ru', 'lexicon.jsonl')
    rows = _read_jsonl(path)
    lex = {r.get('key'): r.get('variants') for r in rows if r.get('key')}
    return lex

def store() -> Any:
    if kv is not None:
        db_path = os.environ.get('ARENA_DB', 'salesbot.db')
        return kv(db_path)
    class FileKV:
        def __init__(self, base='modules/arena_runtime/v1/tmp'):
            self.base = base
            os.makedirs(base, exist_ok=True)
        def _path(self, k):
            return os.path.join(self.base, k.replace(':','__') + '.json')
        def set(self, k, v):
            with open(self._path(k), 'w', encoding='utf-8') as f:
                f.write(v)
        def get(self, k):
            p = self._path(k)
            if not os.path.exists(p): return None
            with open(p, 'r', encoding='utf-8') as f:
                return f.read()
        def scan(self, prefix, limit=100):
            out = []
            for fn in os.listdir(self.base):
                if fn.endswith('.json') and fn.startswith(prefix.replace(':','__')):
                    with open(os.path.join(self.base, fn), 'r', encoding='utf-8') as f:
                        out.append((fn, f.read()))
                if len(out)>=limit: break
            return out
    return FileKV()

def pick_persona(personas: List[dict]) -> dict:
    if not personas:
        return {"id":"fallback","type":"warm","name":"Warm","desc":"Тёплый","opening":"Здравствуйте! О чём речь?","style_rules":[]}
    import random
    return random.choice(personas)

def llm_reply(history: List[dict], role='client_emotional') -> str:
    if callable(persona_chat):
        try:
            prompt = history[-1]['content'] if history else 'Здравствуйте'
            return persona_chat(prompt, role=role)[:800]
        except Exception:
            pass
    if VoicePipeline is not None:
        try:
            vp = VoicePipeline()
            msgs = history[-5:] if len(history)>5 else history
            if not msgs:
                msgs = [{"role":"user","content":"Здравствуйте"}]
            return vp.llm.chat(msgs)[:800]
        except Exception:
            pass
    base = [
        "Понимаю вас. Давайте сделаем первый шаг — коротко расскажите, к какому событию готовите подарок?",
        "Хочется передать тепло вашей истории. Что особенно важно упомянуть в песне?",
        "Можем подготовить два варианта — вы выберете сердцем. С чего начнём?"
    ]
    import random
    return random.choice(base)

def new_session_id() -> str:
    import uuid
    return str(uuid.uuid4())

def session_key(sid: str) -> str:
    return f"arena:session:{sid}"

def save_session(sid: str, data: dict):
    st = store()
    st.set(session_key(sid), json.dumps(data, ensure_ascii=False))

def load_session(sid: str) -> Optional[dict]:
    st = store()
    raw = st.get(session_key(sid))
    if not raw: return None
    try:
        return json.loads(raw)
    except Exception:
        return None
