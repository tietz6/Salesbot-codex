
from fastapi import APIRouter
from pydantic import BaseModel
from .engine import ReactionBrain

router = APIRouter(prefix="/upsell_reaction_brain/v1", tags=["upsell_reaction_brain"])
brain = ReactionBrain()

class StepIn(BaseModel):
    session_id: str
    manager_text: str
    client_text: str | None = ""
    meta: dict | None = None

@router.get("/health")
def health():
    return {"ok": True, "module": "upsell_reaction_brain.v1"}

@router.post("/start")
def start(session_id: str, context: dict | None = None):
    return brain.start(session_id, context=context)

@router.post("/step")
def step(inp: StepIn):
    return brain.step(inp.session_id, inp.manager_text, inp.client_text or "", meta=inp.meta or {})

@router.get("/predict/{session_id}")
def predict(session_id: str):
    return brain.predict(session_id)

@router.get("/finalize/{session_id}")
def finalize(session_id: str):
    return brain.finalize(session_id)
