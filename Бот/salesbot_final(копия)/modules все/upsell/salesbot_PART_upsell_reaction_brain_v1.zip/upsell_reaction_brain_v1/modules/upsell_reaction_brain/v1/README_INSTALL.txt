
Upsell Reaction Brain v1
------------------------
ИИ-движок, который оценивает реакцию клиента на реплики менеджера и прогнозирует вероятность допродажи.
Эндпоинты:
  GET  /upsell_reaction_brain/v1/health
  POST /upsell_reaction_brain/v1/start?session_id=SID
  POST /upsell_reaction_brain/v1/step  (json: {session_id, manager_text, client_text})
  GET  /upsell_reaction_brain/v1/predict/{SID}
  GET  /upsell_reaction_brain/v1/finalize/{SID}
