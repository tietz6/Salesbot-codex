# Emotional intensity model

class EmotionalIntensity:
    def evaluate(self, reply):
        return {'level':'neutral','score':0.5}
