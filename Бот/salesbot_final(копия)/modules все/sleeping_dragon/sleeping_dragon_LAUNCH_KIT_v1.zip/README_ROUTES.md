# ROUTES QUICK LOOK
GET  /api/public/v1/health
GET  /api/public/v1/ping
GET  /mini/brand/health
GET  /api/public/v1/routes_summary
POST /voice/v1/llm/chat {messages:[...]}
GET  /sleeping_dragon/v4/health
