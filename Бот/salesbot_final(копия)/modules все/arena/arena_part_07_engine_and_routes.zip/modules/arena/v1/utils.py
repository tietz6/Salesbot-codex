
import os, json, yaml

def read_jsonl(path):
    items = []
    if not os.path.exists(path): 
        return items
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line: 
                continue
            try:
                items.append(json.loads(line))
            except Exception:
                continue
    return items

def read_yaml(path, default=None):
    if not os.path.exists(path):
        return default if default is not None else {}
    with open(path, "r", encoding="utf-8") as f:
        try:
            return yaml.safe_load(f) or {}
        except Exception:
            return default if default is not None else {}

def safe_join(*parts):
    return os.path.normpath(os.path.join(*parts))
