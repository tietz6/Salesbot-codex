
"""
Glue к modules.sleeping_dragon_rules.v1
Комбинированный скоринг реплики: rule + llm + итог.
"""
from typing import Dict, Any

def dragon_analyze(reply: str, stage: str = "offer") -> Dict[str, Any]:
    try:
        from modules.sleeping_dragon_rules.v1 import score as _score  # type: ignore
        return _score(history=None, reply=reply, stage=stage)
    except Exception:
        # базовый оффлайн-скорая оценка
        penalties = []
        rs = 10
        if len(reply.strip()) < 8:
            rs -= 2; penalties.append("too_short")
        if reply.strip().endswith("?") is False:
            rs -= 1; penalties.append("no_question")
        return {"ok": True, "rule": {"penalties": penalties, "rule_score": max(0, rs)},
                "llm": {"llm_score": 6, "reasons": ["LLM недоступен"]},
                "combined": round(0.6*max(0, rs)+0.4*6)}

def dragon_suggest(reply: str, stage: str = "offer") -> Dict[str, Any]:
    try:
        from modules.sleeping_dragon_rules.v1 import suggest as _suggest  # type: ignore
        return _suggest(history=None, reply=reply, stage=stage)
    except Exception:
        return {"ok": True, "suggestion": "Добавьте ценность (зачем это клиенту), 1 уточняющий вопрос и мягкое приглашение к следующему шагу."}
