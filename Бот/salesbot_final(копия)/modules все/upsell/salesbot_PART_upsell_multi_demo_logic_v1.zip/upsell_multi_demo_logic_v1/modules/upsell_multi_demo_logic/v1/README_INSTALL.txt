Upsell Multi Demo Logic v1
--------------------------------
A/B-логика демо + мягкие допродажи:
- выбор A/B, скидка на вторую
- лестница 2→4
- видео-пакет 9:16

Эндпоинты:
  GET  /upsell_multi_demo/v1/health
  POST /upsell_multi_demo/v1/start
  POST /upsell_multi_demo/v1/attach_demo
  POST /upsell_multi_demo/v1/react
