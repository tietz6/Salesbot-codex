
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from .templates import render_start, render_session
from ..runtime.engine import ArenaEngine

router = APIRouter(prefix="/arena/v1/ui", tags=["Arena UI"])
_engine = ArenaEngine()

@router.get("/health")
def health():
    return {"ok": True, "ui": "arena_ui_v1"}

@router.get("/start/{manager_id}", response_class=HTMLResponse)
def start_ui(manager_id: str):
    init = _engine.start(manager_id=manager_id)
    sid = init["sid"]
    state = init["state"]
    reply = init["client_reply"]
    return HTMLResponse(render_session(manager_id, sid, state, reply))

@router.get("/session/{manager_id}/{sid}", response_class=HTMLResponse)
def session_ui(manager_id: str, sid: str):
    snap = _engine.snapshot(sid)
    if not snap.get("ok"):
        return HTMLResponse("<h2>Session not found</h2>", status_code=404)
    state = snap["state"]
    last = ""
    for m in reversed(state["history"]):
        if m["role"] == "client":
            last = m["content"]; break
    return HTMLResponse(render_session(manager_id, sid, state, last))

@router.get("/static/arena_ui.css")
def css():
    from fastapi.responses import Response
    try:
        with open(__file__.replace("routes_ui.py","static/arena_ui.css"), "r", encoding="utf-8") as f:
            return Response(f.read(), media_type="text/css")
    except Exception:
        return Response("/* no css */", media_type="text/css")
