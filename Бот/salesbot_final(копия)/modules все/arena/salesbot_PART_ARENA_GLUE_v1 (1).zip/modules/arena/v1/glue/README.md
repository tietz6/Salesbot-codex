# Arena Glue v1

Безопасная прослойка, которая связывает Runtime Арены с окружающими модулями:
- deepseek_persona (фирменный стиль речи)
- arena_psychotypes (динамика клиента)
- master_path_rubrics (оценка истории)
- sleeping_dragon_rules (скоринг/советы)
- objections_classifier (определение возражения)
- upsell_pricing_glue (цены/купон/НДС + питч)

Если какой‑то модуль отсутствует — используются мягкие fallback-и, чтобы диалог не ломался.

Маршруты:
- GET  /arena/v1/glue/health
- POST /arena/v1/glue/persona       {prompt, role?}
- POST /arena/v1/glue/psy_spawn     {difficulty?, type?, context?}
- POST /arena/v1/glue/psy_step      {state, manager_reply}
- POST /arena/v1/glue/master_score  {history:[...]}
- POST /arena/v1/glue/dragon_score  {reply, history?, stage?}
- POST /arena/v1/glue/dragon_suggest{reply, history?, stage?}
- POST /arena/v1/glue/obj_classify  {utterance, history?}
- POST /arena/v1/glue/upsell_offer  {tier,currency,discount,coupon,vat,context,current_tier}

ENV (через integrations.patch_v4.env.get_env, есть дефолты):
- ARENA_ENABLE_PSYCOTYPES=1
- ARENA_ENABLE_PERSONA=1
- ARENA_ENABLE_RUBRICS=1
- ARENA_ENABLE_DRAGON=1
- ARENA_ENABLE_OBJECTIONS=1
- ARENA_ENABLE_UPSELL=1