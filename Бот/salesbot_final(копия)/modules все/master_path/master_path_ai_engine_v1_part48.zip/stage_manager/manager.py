
import json, os, random, pathlib

class StageManager:
    def __init__(self):
        cfg = pathlib.Path(__file__).resolve().parents[2] / "config" / "stages.json"
        with open(cfg, "r", encoding="utf-8") as f:
            self.stages = json.load(f)
        self.order = self.stages.get("order", [])

    def next_stage(self, current: str, last_text: str):
        # простая эвристика: если менеджер что-то утвердил — шаг вперёд
        idx = self.order.index(current) if current in self.order else 0
        if any(x in (last_text or "").lower() for x in ["готов","давайте","дальше","ок","понятно","поехали"]):
            return self.order[min(idx+1, len(self.order)-1)]
        return current

    def system_prompt(self, stage: str):
        # подбираем системное описание из prompts
        p = pathlib.Path(__file__).resolve().parents[2] / "deepseek_pipeline" / "prompts.py"
        data = {}
        ns = {}
        with open(p, "r", encoding="utf-8") as f:
            txt = f.read()
            # грубый парс: prompts = {...}
            start = txt.find("prompts = ")
            if start >= 0:
                js = txt[start+10:]
                data = eval(js)  # безопасно в данном стенде: локальный файл
        tmpl = data.get("templates",{}).get(stage, "Отвечай дружелюбно и по делу.")
        return "Ты реалистичный клиент бренда. " + tmpl
