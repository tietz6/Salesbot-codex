
import re, json, os, math

def _load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

BASE = os.path.dirname(__file__)
RULES = _load_json(os.path.join(BASE,"rules.json"), {})

def rule_score(reply:str)->dict:
    s = 10
    penalties = []
    r = reply or ""
    low = r.lower()
    if len(r.strip()) < 12:
        s += RULES.get("penalties",{}).get("too_short",-2)
        penalties.append("too_short")
    if not ("?" in r):
        s += RULES.get("penalties",{}).get("no_question",-2)
        penalties.append("no_question")
    if any(x in low for x in ["дурак","идиот","заткнись"]):
        s += RULES.get("penalties",{}).get("aggressive",-3)
        penalties.append("aggressive")
    if "!!" in r or "??" in r:
        s += RULES.get("penalties",{}).get("many_punct",-1)
        penalties.append("many_punct")
    s = max(0, min(10, s))
    return {"rule_score": s, "penalties": penalties}

def llm_score_stub(history, reply)->dict:
    # Fallback если внешний LLM недоступен
    base = 6
    if "спасибо" in (reply or "").lower():
        base += 1
    if "могу предложить" in (reply or "").lower():
        base += 1
    base = max(3, min(9, base))
    return {"llm_score": base, "reasons": ["тон тёплый","есть ценность","есть CTA"], "tip": "добавьте короткий уточняющий вопрос"}

def combined(history, reply)->dict:
    r = rule_score(reply)
    l = llm_score_stub(history, reply)
    final = round(0.6*r["rule_score"] + 0.4*l["llm_score"])
    return {"ok": True, "rule": r, "llm": l, "combined": final}

def report(history)->dict:
    # простая метрика по последнему ответу менеджера
    last = ""
    for m in reversed(history or []):
        if m.get("role") == "manager":
            last = m.get("content","")
            break
    res = combined(history, last)
    return {"ok": True, "last_reply": last, **res}
