PART_BC placeholder for deepseek behaviors.
