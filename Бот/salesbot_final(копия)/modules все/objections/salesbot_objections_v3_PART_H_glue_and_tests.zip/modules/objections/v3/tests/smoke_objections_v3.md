
# Smoke checklist
- /objections/v3/health returns ok
- /objections/v3/start/{sid} creates session
- /objections/v3/handle/{sid} appends history and returns client reply
- /objections/v3/snapshot/{sid} shows state
- /objections/v3/reset/{sid} clears session
