
from enum import Enum, auto
class Role(Enum):
    ADMIN = auto()
    MANAGER = auto()
    TRAINEE = auto()
