
from fastapi import APIRouter, Body, HTTPException
from .service import ArenaService

router = APIRouter(prefix="/arena/v1", tags=["arena.v1"])
_svc = ArenaService()

@router.get("/health")
def health():
    return {"ok": True, "content_loaded": bool(_svc.cache)}

@router.post("/start")
def start(payload: dict = Body(...)):
    manager_id = payload.get("manager_id") or "manager"
    context = payload.get("context") or {}
    return _svc.start(manager_id, context)

@router.post("/step")
def step(payload: dict = Body(...)):
    manager_id = payload.get("manager_id")
    sid = payload.get("sid")
    text = payload.get("text","").strip()
    if not manager_id or not sid or not text:
        raise HTTPException(400, "manager_id, sid, text required")
    return _svc.step(manager_id, sid, text)

@router.get("/snapshot")
def snapshot(manager_id: str, sid: str):
    return _svc.snapshot(manager_id, sid)
