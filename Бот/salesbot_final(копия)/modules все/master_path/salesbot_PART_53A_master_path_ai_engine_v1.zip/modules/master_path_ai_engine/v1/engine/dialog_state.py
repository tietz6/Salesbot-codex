
ALLOWED_STAGES=['greeting','qualification','warmup','texts','genre','payment','demo_cycle','finish']
class DialogState:
    def __init__(self, sid, stage='greeting'):
        self.sid=sid
        self.stage=stage
        self.history=[]
        self.score=0.0
        self.meta={}
    def to_dict(self):
        return {'sid':self.sid,'stage':self.stage,'history':self.history,'score':self.score,'meta':self.meta}
    @classmethod
    def from_dict(cls,d):
        o=cls(d.get('sid',''),d.get('stage','greeting'))
        o.history=d.get('history',[]); o.score=d.get('score',0.0); o.meta=d.get('meta',{})
        return o
    def move_to(self, stage):
        if stage in ALLOWED_STAGES: self.stage=stage
