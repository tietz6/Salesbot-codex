import json
def apply_persona(text, role, rules):
    r = rules.get('roles', {}).get(role, {})
    return ' '.join(filter(None, [r.get('prefix',''), text.strip(), r.get('suffix','')]))
