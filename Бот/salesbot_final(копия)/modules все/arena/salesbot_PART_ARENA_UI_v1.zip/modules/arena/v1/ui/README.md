# Arena UI v1

Интерфейс под Mini WebKit Brand (тёмная тема). Открывает сессию и позволяет вести диалог.
Маршруты:
- GET /arena/v1/ui/health
- GET /arena/v1/ui/start/{manager_id}
- GET /arena/v1/ui/session/{manager_id}/{sid}
- GET /arena/v1/ui/static/arena_ui.css

Зависит от: modules/arena/v1/runtime (ArenaEngine).