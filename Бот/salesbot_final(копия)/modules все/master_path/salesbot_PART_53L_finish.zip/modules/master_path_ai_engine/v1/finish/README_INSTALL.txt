PART 53-L — finish

Папка: modules/master_path_ai_engine/v1/finish/

Назначение
----------
Финальный этап «Пути Мастера»: формирует отчёт по сессии, краткое резюме,
персональные рекомендации и сохраняет результат (если доступен dialog_memory/v1).
Работает без внешних интеграций (graceful fallback), но умеет использовать:
- heuristics/analyzer.py — для метрик и штрафов
- dialog_memory/v1 — для сохранения истории и аналитики
- core/voice_gateway/v1 — для фирменной формулировки текста отчёта

Основные функции
----------------
from modules.master_path_ai_engine.v1.finish.summary import Finalizer

f = Finalizer(state_store)
f.finish(sid, history=[{role, content, stage}], manager_id="alex")

Возвращает структуру
--------------------
{
  "ok": true,
  "sid": "...",
  "score": { "total": 0..100, "details": {...} },
  "issues": [...],
  "strengths": [...],
  "next_steps": [...],
  "report_text": "человеческое формулирование отчёта"
}

Файлы
-----
- summary.py — логика финализации/отчёта
- recommendations.json — каталог советов по типичным недочётам
- __init__.py, manifest.json, README_INSTALL.txt
