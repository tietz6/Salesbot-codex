# Large Knowledge Base
Содержит расширенную базу знаний для Sleeping Dragon.
