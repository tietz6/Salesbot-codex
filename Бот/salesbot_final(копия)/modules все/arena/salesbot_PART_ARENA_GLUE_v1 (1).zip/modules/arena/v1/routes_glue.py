
from fastapi import APIRouter, Body
from .glue_deepseek_persona import persona_chat, stylize
from .glue_dialog_memory import start_session, append_message, analyze_session, list_sessions
from .glue_psychotypes import psy_spawn, psy_step
from .glue_rules import dragon_analyze, dragon_suggest

router = APIRouter(prefix="/arena/v1/glue", tags=["Arena Glue"])

@router.get("/health")
def health():
    return {"ok": True, "pack": "arena_glue_pack_v1"}

@router.post("/persona/chat")
def persona_chat_api(payload: dict = Body(...)):
    prompt = payload.get("prompt", "")
    role = payload.get("role", "coach")
    return {"output": persona_chat(prompt, role=role)}

@router.post("/memory/start")
def memory_start(payload: dict = Body(...)):
    mid = payload.get("manager_id", "anon")
    sid = start_session(mid)
    return {"manager_id": mid, "session_id": sid}

@router.post("/memory/append")
def memory_append(payload: dict = Body(...)):
    ok = append_message(payload.get("manager_id","anon"), payload.get("session_id","-"),
                        payload.get("role","manager"), payload.get("content",""), payload.get("stage","arena"))
    return {"ok": ok}

@router.post("/memory/analyze")
def memory_analyze(payload: dict = Body(...)):
    return analyze_session(payload.get("manager_id","anon"), payload.get("session_id","-"))

@router.get("/memory/list/{manager_id}")
def memory_list(manager_id: str):
    return {"sessions": list_sessions(manager_id)}

@router.post("/psy/spawn")
def psy_spawn_api(payload: dict = Body(...)):
    return psy_spawn(payload.get("difficulty","medium"), payload.get("type","emotional"), payload.get("context",""))

@router.post("/psy/step")
def psy_step_api(payload: dict = Body(...)):
    return psy_step(payload.get("state",{}), payload.get("manager_reply",""))

@router.post("/rules/analyze")
def rules_analyze(payload: dict = Body(...)):
    return dragon_analyze(payload.get("reply",""), payload.get("stage","offer"))

@router.post("/rules/suggest")
def rules_suggest(payload: dict = Body(...)):
    return dragon_suggest(payload.get("reply",""), payload.get("stage","offer"))
