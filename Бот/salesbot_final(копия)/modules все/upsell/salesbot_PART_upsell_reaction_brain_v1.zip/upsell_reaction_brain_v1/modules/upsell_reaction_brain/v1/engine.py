
from datetime import datetime
from .predictors import predict_proba, advise_next_step
from .storage import Storage

class ReactionBrain:
    def __init__(self):
        self.store = Storage(namespace="upsell_reaction_brain")

    def start(self, session_id: str, context: dict | None = None):
        key = f"session:{session_id}"
        self.store.set(key, {"created": datetime.utcnow().isoformat(), "steps": [], "context": context or {}, "score": 0})
        return {"ok": True, "session_id": session_id}

    def step(self, session_id: str, manager_text: str, client_text: str | None = "", meta: dict | None = None):
        key = f"session:{session_id}"
        state = self.store.get(key) or {"steps": [], "score": 0, "context": {}}
        proba = predict_proba(manager_text=manager_text, client_text=client_text or "", context=state.get("context", {}))
        advice = advise_next_step(manager_text=manager_text, client_text=client_text or "", context=state.get("context", {}), proba=proba)
        entry = {
            "t": datetime.utcnow().isoformat(),
            "manager": manager_text,
            "client": client_text or "",
            "meta": meta or {},
            "proba": proba,
            "advice": advice
        }
        state["steps"].append(entry)
        # accumulate a simple score (cap at 100)
        state["score"] = min(100, state.get("score", 0) + int(proba.get("buy_now", 0) * 20) + int(proba.get("take_bundle", 0) * 15))
        self.store.set(key, state)
        return {"ok": True, "session_id": session_id, "proba": proba, "advice": advice, "score": state["score"]}

    def predict(self, session_id: str):
        key = f"session:{session_id}"
        state = self.store.get(key) or {"steps": []}
        if not state["steps"]:
            return {"ok": False, "error": "no_steps"}
        last = state["steps"][-1]
        return {"ok": True, "last_proba": last["proba"], "last_advice": last["advice"], "score": state.get("score", 0)}

    def finalize(self, session_id: str):
        key = f"session:{session_id}"
        state = self.store.get(key) or {"steps": [], "score": 0}
        summary = {
            "total_steps": len(state["steps"]),
            "score": state.get("score", 0),
            "last_proba": state["steps"][-1]["proba"] if state["steps"] else {},
            "recommendation": "Перейти к оплате" if state.get("score", 0) >= 70 else "Сделать мягкий оффер/второй жанр"
        }
        return {"ok": True, "session_id": session_id, "summary": summary}
