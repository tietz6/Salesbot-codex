
import re, json, pathlib, random

def score_reply(text: str, stage: str):
    base = 7
    if len(text.strip()) < 5: base -= 2
    if "?" not in text and stage in ("qualification","warmup","texts","genre"): base -= 2
    if any(x in text for x in ["!!","??"]): base -= 1
    return max(0, min(10, base))
