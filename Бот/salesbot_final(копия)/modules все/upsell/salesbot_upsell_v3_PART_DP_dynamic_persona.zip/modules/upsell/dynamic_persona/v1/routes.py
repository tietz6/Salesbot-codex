
from fastapi import APIRouter, Body
from .engine import DynamicPersona

router = APIRouter(prefix="/upsell/dynamic_persona/v1", tags=["upsell_dynamic_persona_v1"])

@router.post("/spawn")
def spawn(seed: dict = Body(None)):
    dp = DynamicPersona(seed or {})
    return {"ok": True, "state": dp.state.__dict__}

@router.post("/step")
def step(payload: dict = Body(...)):
    dp = DynamicPersona(payload.get("state"))
    res = dp.step(payload.get("manager_reply", ""))
    return {"ok": True, **res}

@router.get("/health")
def health():
    return {"ok": True}
