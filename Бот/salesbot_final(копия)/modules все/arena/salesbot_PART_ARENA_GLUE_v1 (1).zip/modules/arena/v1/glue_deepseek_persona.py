
"""
Glue к modules.deepseek_persona.v1
Безопасные вызовы persona_chat/stylize для Арены.
"""
from typing import Optional, List, Dict

def _fallback_style(text: str, role: str = "coach") -> str:
    if role.startswith("client"):
        return f"{text}"
    return f"{text}\n\n(совет бренда: теплый тон, 1–2 уточняющих вопроса, без давления)"

def persona_chat(prompt: str, role: str = "coach") -> str:
    try:
        from modules.deepseek_persona.v1 import persona_chat as _chat  # type: ignore
        return _chat(prompt, role=role)
    except Exception:
        return _fallback_style(prompt, role=role)

def stylize(text: str, role: str = "coach") -> str:
    try:
        from modules.deepseek_persona.v1 import stylize as _stylize  # type: ignore
        return _stylize(text, role=role)
    except Exception:
        return _fallback_style(text, role=role)
