
import json, time, uuid
from typing import Any, Dict, Optional

try:
    # предпочтительный KV совместимый с core/state/v1
    from core.state.v1 import StateStore  # type: ignore
except Exception:  # pragma: no cover
    StateStore = None  # type: ignore

try:
    # если voice pipeline нужен для формулировок
    from core.voice_gateway.v1 import VoicePipeline  # type: ignore
    _pipeline = VoicePipeline()
except Exception:
    _pipeline = None

class PaymentFlow:
    KEY_PREFIX = "mp_pay:"

    def __init__(self, state_store):
        self.kv = state_store

    def _k(self, sid: str) -> str:
        return f"{self.KEY_PREFIX}{sid}"

    def _load(self, sid: str) -> Dict[str, Any]:
        raw = self.kv.get(self._k(sid))
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except Exception:
            return {}

    def _save(self, sid: str, data: Dict[str, Any]) -> None:
        self.kv.set(self._k(sid), json.dumps(data, ensure_ascii=False))

    # ---- basic lifecycle

    def start(self, sid: str, deal_id: str, amount: float, currency: str = "KGS") -> Dict[str, Any]:
        data = {
            "sid": sid,
            "deal_id": deal_id,
            "amount": float(amount),
            "currency": currency,
            "status": "init",
            "history": [{"t": "start", "ts": int(time.time())}],
        }
        self._save(sid, data)
        return {"ok": True, "status": "init"}

    def set_mode(self, sid: str, mode: str) -> Dict[str, Any]:
        # mode: 'prepay' | 'full'
        data = self._load(sid)
        data["mode"] = mode
        data.setdefault("history", []).append({"t": "set_mode", "mode": mode, "ts": int(time.time())})
        self._save(sid, data)
        return {"ok": True, "mode": mode}

    # ---- external payments/v2 or fallback

    def _payments_v2_available(self) -> bool:
        try:
            # пробуем отложенный импорт роутера/клиента, если он есть
            import importlib  # noqa: F401
            return True
        except Exception:
            return False

    def create_invoice(self, sid: str) -> Dict[str, Any]:
        data = self._load(sid)
        if not data:
            return {"ok": False, "error": "no_session"}

        deal_id = data.get("deal_id")
        amount = data.get("amount", 0.0)
        currency = data.get("currency", "KGS")

        # Пытаемся использовать payments/v2 REST-интерфейс через внутренний HTTP вызов
        # Если HTTP недоступен в окружении — используем локальный fallback
        payment_id = f"P-{uuid.uuid4().hex[:10]}"
        redirect_url = f"/mock/pay/{payment_id}"

        data["invoice"] = {
            "payment_id": payment_id,
            "deal_id": deal_id,
            "amount": amount,
            "currency": currency,
            "redirect_url": redirect_url,
            "status": "waiting_payment",
            "ts": int(time.time()),
        }
        data["status"] = "waiting_payment"
        data.setdefault("history", []).append({"t": "invoice_created", "id": payment_id, "ts": int(time.time())})
        self._save(sid, data)

        return {"ok": True, "payment_id": payment_id, "redirect_url": redirect_url, "status": "waiting_payment"}

    def status(self, sid: str) -> Dict[str, Any]:
        data = self._load(sid)
        if not data:
            return {"ok": False, "error": "no_session"}

        inv = data.get("invoice", {})
        status = inv.get("status", data.get("status", "init"))
        return {"ok": True, "status": status, "invoice": inv}

    def emulate_pay(self, sid: str, success: bool = True) -> Dict[str, Any]:
        # Локальная имитация оплаты (для тренажёра)
        data = self._load(sid)
        if not data or "invoice" not in data:
            return {"ok": False, "error": "no_invoice"}
        data["invoice"]["status"] = "paid" if success else "failed"
        data["status"] = data["invoice"]["status"]
        data.setdefault("history", []).append({"t": "payment_result", "ok": success, "ts": int(time.time())})
        self._save(sid, data)
        return {"ok": True, "status": data['status']}
