# Финальная чек‑листа
- [ ] .env заполнен
- [ ] Все must_have модули на месте
- [ ] База salesbot.db доступна для записи
- [ ] /api/public/v1/health = 200
- [ ] /mini/brand/hub открывается
- [ ] Оплата v2: invoice → webhook → status
- [ ] Dialog Memory пишет сессии
- [ ] Voice LLM отвечает с graceful fallback
