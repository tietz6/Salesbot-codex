def handle(message:str): return {'answer':'Пинг без давления, прикладываю 1–2 причины ответить 🙂'}
