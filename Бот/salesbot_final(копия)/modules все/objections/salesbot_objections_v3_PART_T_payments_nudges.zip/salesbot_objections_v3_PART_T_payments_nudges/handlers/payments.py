def handle(msg:str): return {'answer':'Отправляю QR на предоплату и фиксирую слот ✨'}
