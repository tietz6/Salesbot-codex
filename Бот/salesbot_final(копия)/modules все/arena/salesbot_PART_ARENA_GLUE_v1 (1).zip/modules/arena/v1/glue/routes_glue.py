
from fastapi import APIRouter
from .adapters import Glue

router = APIRouter(prefix="/arena/v1/glue", tags=["Arena Glue"])
g = Glue()

@router.get("/health")
def health():
    return {"ok": True, "glue": "arena_glue_v1"}

@router.post("/persona")
def persona(payload: dict):
    return g.persona_chat(payload.get("prompt",""), role=payload.get("role"))

@router.post("/psy_spawn")
def psy_spawn(payload: dict):
    return g.psy_spawn(payload.get("difficulty","medium"), payload.get("type"), payload.get("context",""))

@router.post("/psy_step")
def psy_step(payload: dict):
    return g.psy_step(payload.get("state",{}), payload.get("manager_reply",""))

@router.post("/master_score")
def master_score(payload: dict):
    return g.master_score(payload.get("history", []))

@router.post("/dragon_score")
def dragon_score(payload: dict):
    return g.dragon_score(payload.get("reply",""), history=payload.get("history"), stage=payload.get("stage"))

@router.post("/dragon_suggest")
def dragon_suggest(payload: dict):
    return g.dragon_suggest(payload.get("reply",""), history=payload.get("history"), stage=payload.get("stage"))

@router.post("/obj_classify")
def obj_classify(payload: dict):
    return g.classify_objection(payload.get("utterance",""), history=payload.get("history"))

@router.post("/upsell_offer")
def upsell_offer(payload: dict):
    return g.upsell_offer(
        catalog=payload.get("catalog"),
        tier=payload.get("tier","premium"),
        currency=payload.get("currency","KGS"),
        discount=payload.get("discount",0.0),
        coupon=payload.get("coupon"),
        vat=payload.get("vat",0.12),
        context=payload.get("context"),
        current_tier=payload.get("current_tier","basic"),
    )
