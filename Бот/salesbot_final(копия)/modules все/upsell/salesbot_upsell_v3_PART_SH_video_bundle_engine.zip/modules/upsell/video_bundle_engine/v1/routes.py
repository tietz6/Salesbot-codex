
from fastapi import APIRouter, Body
from .engine import VideoBundleEngine

router = APIRouter(prefix="/upsell/video_bundle/v1", tags=["upsell_video_bundle_v1"])
eng = VideoBundleEngine()

@router.get("/health")
def health():
    return {"ok": True}

@router.post("/build")
def build(payload: dict = Body(...)):
    b = eng.build(
        song = bool(payload.get("song", True)),
        video = bool(payload.get("video", False)),
        story = bool(payload.get("story", False))
    )
    return {"ok": True, "bundle": b}

@router.post("/price")
def price(payload: dict = Body(...)):
    b = payload.get("bundle") or eng.build(
        song = bool(payload.get("song", True)),
        video = bool(payload.get("video", False)),
        story = bool(payload.get("story", False))
    )
    res = eng.price(
        b,
        currency = payload.get("currency", "KGS"),
        coupon = payload.get("coupon"),
        promo = payload.get("promo"),
        vat_rate = float(payload.get("vat", 0.0)),
    )
    return {"ok": True, "price": res}
