# Package Z — Reports, Exporters, Webhooks, Validators
- z_reports/templates/report_*.html — HTML-шаблоны отчётов (20 шт.)
- z_exporters/schemas/*.json — схемы экспорта (session, errors, score, invoice)
- z_webhooks/events.json — примеры полезных вебхуков
- z_validators/rules.json — 80 правил с подсказками на 3 языках
