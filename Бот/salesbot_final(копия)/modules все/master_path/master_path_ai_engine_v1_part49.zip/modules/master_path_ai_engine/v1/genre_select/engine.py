
# genre_select/engine.py
from __future__ import annotations
import json
from pathlib import Path

class GenreSelect:
    def __init__(self, genres_path: str):
        self.data = json.loads(Path(genres_path).read_text(encoding="utf-8"))

    def recommend(self, mood: str = "romance", voice: str = "female") -> dict:
        mood = (mood or "romance").lower()
        voice = (voice or "female").lower()
        # simple pick with fallbacks
        moods = self.data.get("moods", {})
        g = moods.get(mood) or moods.get("romance", [])
        base = g[0] if g else {"genre":"pop","voice":"female","reason":"default"}
        base["voice"] = voice
        return base

    def list(self) -> dict:
        return self.data
