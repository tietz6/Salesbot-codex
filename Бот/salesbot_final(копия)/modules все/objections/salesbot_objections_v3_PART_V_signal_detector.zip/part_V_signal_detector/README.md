# Conversation Signal Detector
Part **V** · objections/v3

Детектирование риск-фраз, маркеров намерений и триггеров для запуска нужных плейбуков.

## How it works
- `routes.py` exposes fastapi routes under `/objections/v3/part_V_signal_detector`
- `service.py` hosts orchestration and calls LLM through `deepllm.py`
- `prompts/` houses system/assistant/user templates
- `data/` contains seed dialogues (jsonl) and eval checks
- `tests/` has smoke tests for routing & generation

## Env
- `DEEPSEEK_API_KEY` required (read from `os.environ`).