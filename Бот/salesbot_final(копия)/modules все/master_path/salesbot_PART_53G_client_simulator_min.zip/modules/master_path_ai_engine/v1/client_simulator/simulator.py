
"""
ClientSimulator v1 (minimal, deterministic with persona + emotion graph).
Designed to be replaced by DeepSeek at runtime; provides stable local behavior.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import json, os, random, re

EMO_PATH = os.path.join(os.path.dirname(__file__), "emotional_model.json")
REACT_PATH = os.path.join(os.path.dirname(__file__), "reactions.json")

def _load_json(p: str) -> dict:
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

EMO = _load_json(EMO_PATH)
RX = _load_json(REACT_PATH)

@dataclass
class SimState:
    persona: str = "warm"
    emotion: str = "neutral"
    difficulty: str = "medium"
    stage: str = "greeting"
    history: List[Dict] = field(default_factory=list)
    score_shift: int = 0

class ClientSimulator:
    def __init__(self, persona: str = "warm", difficulty: str = "medium", seed: Optional[int] = None):
        self.state = SimState(persona=persona, difficulty=difficulty)
        if seed is not None:
            random.seed(seed)

    def _match(self, text: str, keys: List[str]) -> bool:
        t = text.lower()
        return any(k in t for k in keys)

    def _pick(self, arr: List[str]) -> str:
        if not arr: return "..."
        return random.choice(arr)

    def _emotion_step(self, manager_text: str):
        """Adjust emotion based on quality markers."""
        good = 0
        bad = 0
        # good markers
        if self._match(manager_text, ["пожалуйста","спасибо","буду рада","эмоци","тепло","подскажите"]):
            good += 1
        if self._match(manager_text, ["как","кому","когда","что важнее", "расскажите"]):
            good += 1
        # bad markers
        if self._match(manager_text, ["срочно","быстрее","давайте уже","обязаны"]):
            bad += 2
        if re.search(r"[!?]{3,}", manager_text):
            bad += 1
        if len(manager_text.strip()) < 8:
            bad += 1

        # map emotion shifts
        emo_order = ["calm","neutral","annoyed","angry","excited"]
        idx = max(0, emo_order.index(self.state.emotion) if self.state.emotion in emo_order else 1)
        if good > bad:
            idx = max(0, idx-1)
        elif bad > good:
            idx = min(len(emo_order)-1, idx+1)
        self.state.emotion = emo_order[idx]

    def _stage_hint(self, stage: str) -> Dict:
        return RX.get("stage_hints", {}).get(stage, {"keys":[], "fallbacks":["Хм... расскажите чуть подробнее?"],"next":"greeting"})

    def _persona_bank(self) -> Dict:
        return RX.get("personas", {}).get(self.state.persona, {})

    def _emotion_bank(self) -> Dict:
        return RX.get("emotions", {}).get(self.state.emotion, {})

    def _compose_reply(self, manager_text: str) -> str:
        # persona + emotion templates + stage hints
        pb = self._persona_bank()
        eb = self._emotion_bank()
        st = self._stage_hint(self.state.stage)
        base = []
        if "openers" in pb: base += pb["openers"]
        if "tones" in eb: base += eb["tones"]
        # if manager touched stage keys -> positive branch
        if self._match(manager_text, st.get("keys", [])):
            bank = st.get("positive", []) or eb.get("positive", []) or pb.get("neutral", [])
        else:
            bank = st.get("fallbacks", []) or eb.get("neutral", []) or pb.get("neutral", [])
        base += bank
        # pick two short snippets
        part1 = self._pick(base)
        part2 = self._pick(bank)
        return (part1 + " " + part2).strip()

    def step(self, manager_text: str, stage: Optional[str] = None) -> Dict:
        if stage: self.state.stage = stage
        self._emotion_step(manager_text)
        reply = self._compose_reply(manager_text)
        self.state.history.append({"role":"manager","content":manager_text,"stage":self.state.stage})
        self.state.history.append({"role":"client","content":reply,"stage":self.state.stage})
        # naive next-stage suggestion
        next_stage = self._stage_hint(self.state.stage).get("next","greeting")
        return {
            "ok": True,
            "persona": self.state.persona,
            "emotion": self.state.emotion,
            "stage": self.state.stage,
            "next_suggested": next_stage,
            "reply": reply
        }

def spawn(persona: str = "warm", difficulty: str = "medium", seed: int = None) -> ClientSimulator:
    return ClientSimulator(persona=persona, difficulty=difficulty, seed=seed)
