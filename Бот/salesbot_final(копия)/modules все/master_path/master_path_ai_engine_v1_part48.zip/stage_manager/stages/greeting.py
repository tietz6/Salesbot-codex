def handle(text:str)->str:
    return 'Рада знакомству! Для кого готовите подарок? '