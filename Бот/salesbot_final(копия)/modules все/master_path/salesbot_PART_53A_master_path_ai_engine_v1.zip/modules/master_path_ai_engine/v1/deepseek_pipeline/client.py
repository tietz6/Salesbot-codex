
def chat(messages, fallback_note=''):
    try:
        from core.voice_gateway.v1 import VoicePipeline
        vp = VoicePipeline()
        return vp.llm.chat(messages)
    except Exception:
        last = ''
        for m in reversed(messages):
            if m.get('role')=='user':
                last = m.get('content','')
                break
        return f"{fallback_note or 'Совет'}: добавьте тепла и задайте один уточняющий вопрос. Основа: {last[:160]}"
