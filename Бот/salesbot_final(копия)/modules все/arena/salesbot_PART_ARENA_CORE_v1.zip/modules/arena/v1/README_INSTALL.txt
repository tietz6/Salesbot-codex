
Arena Core v1 — рабочее ядро
============================
Назначение:
- Запуск тренировки (start)
- Ходы менеджера и ответ "клиента бренда" (step)
- Снимок/стоп и краткая оценка (snapshot/stop)

Зависимости (мягкие):
- core/state/v1 (KV SQLite) — если нет, всё равно работает (без сохранения)
- core/voice_gateway/v1 (VoicePipeline.llm.chat) — если недоступно, включается локальный fallback

Эндпоинты:
- POST /arena/v1/start         {manager_id, context?}
- POST /arena/v1/step/{sid}    {text}
- GET  /arena/v1/stop/{sid}
- GET  /arena/v1/snapshot/{sid}

Автосборка:
- manifest.json: ADD_ONLY, post_hooks: rebuild_routes, touch_startup
- путь роутера: modules.arena.v1.routes:router
