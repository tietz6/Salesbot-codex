PART 53-M — payment_flow

Папка: modules/master_path_ai_engine/v1/payment_flow/

Назначение
----------
Единый «платёжный шаг» для Пути Мастера: рассчитать цену/валюту/НДС/скидки,
создать инвойс (через modules/payments/v2), обновить CRM (через crm_api_bridge/v4)
и вернуть менеджеру тёплую фразу подтверждения.

Зависимости (мягкие, с graceful fallback)
-----------------------------------------
- products.bundle.v1 (apply_pricing, deal_title)
- bridges.crm_api_bridge.v4 (CRMClient) — опционально
- modules/payments/v2 (HTTP API: /payments/v2/invoice/{deal_id}, /payments/v2/status/{deal_id})
- core.voice_gateway.v1 (стилизация подтверждений)

Основные вызовы
---------------
from modules.master_path_ai_engine.v1.payment_flow.engine import PaymentFlow

pf = PaymentFlow(kv)  # kv = core.state.v1.StateStore
quote = pf.quote_bundle(song=True, video=False, premium=False, currency="KGS", coupon=None, promo=None, vat=True)
inv = pf.create_invoice(deal_id, amount=quote["total"], currency=quote["currency"])
status = pf.status(deal_id)
