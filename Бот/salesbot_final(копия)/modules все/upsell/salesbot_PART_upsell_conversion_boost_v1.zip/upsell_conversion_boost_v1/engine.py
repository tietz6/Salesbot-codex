
import math
from datetime import datetime

class ConversionBoost:
    def __init__(self):
        self.state = {}

    def start(self, session_id):
        self.state[session_id] = {
            "steps": [],
            "score": 0,
            "created": datetime.utcnow().isoformat()
        }
        return self.state[session_id]

    def record(self, session_id, manager_text, client_state):
        entry = {
            "manager": manager_text,
            "client": client_state,
            "ts": datetime.utcnow().isoformat()
        }
        self.state[session_id]["steps"].append(entry)
        # Simple scoring logic
        score = 0
        if "видео" in manager_text.lower(): score += 10
        if "песня" in manager_text.lower(): score += 8
        if "давайте" in manager_text.lower(): score += 5
        self.state[session_id]["score"] += score
        return {"delta": score, "total": self.state[session_id]["score"]}

    def finalize(self, session_id):
        data = self.state.get(session_id)
        if not data:
            return {"ok": False, "error": "no_session"}
        base = data["score"]
        final = min(100, base)
        return {"ok": True, "score": final, "steps": data["steps"]}
