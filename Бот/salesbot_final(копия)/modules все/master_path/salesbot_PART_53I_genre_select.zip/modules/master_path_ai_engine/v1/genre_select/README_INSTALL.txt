MASTER PATH AI ENGINE — genre_select (PART 53-I)
Назначение: выбор жанра/голоса на основе предпочтений и истории. 
Опционально генерирует короткую LLM-подсказку через VoicePipeline.
Интеграция:
from modules.master_path_ai_engine.v1.genre_select.engine import GenreSelector
gs = GenreSelector(); res = gs.select({"mood":"romantic","tempo":"mid","voice":"f_soft"})
