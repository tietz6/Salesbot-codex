
import json
from typing import Any, Dict, Optional

try:
    from core.state.v1 import StateStore  # type: ignore
except Exception:
    StateStore = None  # type: ignore

# Опциональные зависимости
_bundle = None
_deal_title = None
try:
    from products.bundle.v1 import apply_pricing, build_bundle, deal_title  # type: ignore
    _bundle = (apply_pricing, build_bundle)
    _deal_title = deal_title
except Exception:
    pass

_pipeline = None
try:
    from core.voice_gateway.v1 import VoicePipeline  # type: ignore
    _pipeline = VoicePipeline()
except Exception:
    pass

_http = None
try:
    import requests as _http  # type: ignore
except Exception:
    _http = None

def _post(url: str, json_body: Dict[str, Any]) -> Dict[str, Any]:
    if _http:
        try:
            r = _http.post(url, json=json_body, timeout=10)
            return r.json()
        except Exception as e:
            return {"ok": False, "error": f"http_error: {e}"}
    # Фоллбек: имитация запроса
    return {"ok": True, "mock": True, "echo": json_body, "url": url}

class PaymentFlow:
    KEY_PREFIX = "mp_pay:"

    def __init__(self, state_store):
        self.kv = state_store

    def _k(self, deal_id: str) -> str:
        return f"{self.KEY_PREFIX}{deal_id}"

    # Расчёт стоимости бандла
    def quote_bundle(self, song: bool=True, video: bool=False, premium: bool=False,
                      currency: str="KGS", coupon: Optional[dict]=None, promo: Optional[dict]=None,
                      vat: bool=True) -> Dict[str, Any]:
        # если нет products.bundle — простой фоллбек
        if not _bundle:
            base = 3500 + (5000 if video else 0) + (8000 if premium else 0)
            total = base
            if vat:
                total = int(total * 1.12)
            return {"ok": True, "currency": currency, "total": total, "items": {"song":song,"video":video,"premium":premium}, "fallback": True}

        apply_pricing, build_bundle = _bundle
        b = build_bundle(song=song, video=video, premium=premium)
        priced = apply_pricing(b, currency=currency, coupon=(coupon or {}).get("percent"), promo=(promo or {}).get("amount"), vat=vat)
        return {"ok": True, "currency": currency, "total": priced.get("total"), "details": priced, "fallback": False}

    # Создание инвойса через payments/v2
    def create_invoice(self, deal_id: str, amount: int, currency: str="KGS", base_url: str="http://127.0.0.1:8080") -> Dict[str, Any]:
        url = f"{base_url}/payments/v2/invoice/{deal_id}"
        res = _post(url, {"amount": amount, "currency": currency})
        # сохранить локально
        try:
            self.kv.set(self._k(deal_id), json.dumps({"deal_id": deal_id, "amount": amount, "currency": currency, "invoice": res}, ensure_ascii=False))
        except Exception:
            pass
        return res

    # Проверка статуса
    def status(self, deal_id: str, base_url: str="http://127.0.0.1:8080") -> Dict[str, Any]:
        if _http:
            try:
                r = _http.get(f"{base_url}/payments/v2/status/{deal_id}", timeout=10)
                return r.json()
            except Exception as e:
                return {"ok": False, "error": f"http_error: {e}"}
        # фоллбек — из KV
        try:
            data = self.kv.get(self._k(deal_id))
            if data:
                j = json.loads(data)
                return {"ok": True, "status": j.get("invoice", {}).get("status","waiting_payment"), "invoice": j.get("invoice")}
        except Exception:
            pass
        return {"ok": True, "status": "unknown"}

    # Тёплая фраза подтверждения
    def confirm_phrase(self, amount: int, currency: str="KGS") -> str:
        base = f"Оплату отметили 💛 Сумма — {amount} {currency}. Запускаем финальный рендер и отправку!"
        if _pipeline:
            try:
                out = _pipeline.llm.chat([
                    {"role":"system","content":"Стилизуй фразу под тёплый бренд «На Счастье» (кратко, дружелюбно)."},
                    {"role":"user","content": base}
                ])
                return out.strip() or base
            except Exception:
                return base
        return base
