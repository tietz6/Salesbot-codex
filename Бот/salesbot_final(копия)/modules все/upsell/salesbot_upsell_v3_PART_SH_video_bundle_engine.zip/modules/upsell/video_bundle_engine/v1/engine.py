
import json

class VideoBundleEngine:
    """Подбирает пакет (song+video/story) и считает цену/скидку/НДС."""
    BASE = {
        "song": 3500,
        "video": 5000,
        "story": 8000
    }

    def build(self, song=True, video=False, story=False):
        items = []
        if song: items.append(("song", self.BASE["song"]))
        if video: items.append(("video", self.BASE["video"]))
        if story: items.append(("story", self.BASE["story"]))
        total = sum(x[1] for x in items)
        return {"items": [k for k,_ in items], "total": total}

    def price(self, bundle: dict, currency="KGS", coupon=None, promo=None, vat_rate=0.0):
        total = bundle.get("total", 0)
        # купон (процент)
        if coupon:
            total = total * (1 - (coupon/100.0))
        # промо (фикс)
        if promo:
            total = max(0, total - promo)
        # НДС
        if vat_rate:
            total = round(total * (1 + vat_rate), 2)
        return {
            "currency": currency,
            "amount": total
        }
