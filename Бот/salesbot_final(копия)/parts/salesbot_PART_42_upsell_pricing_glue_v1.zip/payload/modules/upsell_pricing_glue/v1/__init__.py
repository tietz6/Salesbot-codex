from .service import compute_offer, suggest_upsell
from .routes import router
__all__=['compute_offer','suggest_upsell','router']
