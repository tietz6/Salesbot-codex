def handle(text:str)->str:
    return 'Отправлю два демо по 40–50 сек, выберите по ощущениям. '