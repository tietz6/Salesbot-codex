PART 53-J — demo_cycle

Папка: modules/master_path_ai_engine/v1/demo_cycle/

Назначение
----------
Управляет циклом отправки демо A/B: учёт состояния, мягкие подсказки DeepSeek,
эскалация к «Вкусу Победы», фиксация выбора.

Интеграция
----------
from modules.master_path_ai_engine.v1.demo_cycle.demo_manager import DemoManager

dm = DemoManager(state_store)  # state_store совместим с core/state/v1
