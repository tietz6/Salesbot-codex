# Package R — Rich Content Pack
- diagnostic_playgrounds/playgrounds.json (50)
- scenario_bundles/bundles.json (40 x 5–7 ходов)
- templates/messages.json (120 готовых сообщений)
- benchmarks/gold.json + weak.json
- llm_prompts/system.txt + user.txt
