from .routes import router  # FastAPI router
