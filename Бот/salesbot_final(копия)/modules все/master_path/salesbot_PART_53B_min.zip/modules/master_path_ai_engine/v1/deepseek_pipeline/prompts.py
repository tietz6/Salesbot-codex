BRAND_SYSTEM_PROMPT='На Счастье — тепло и забота.'
