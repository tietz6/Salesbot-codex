
Exam AutoCheck Module v1
Provides:
  - Automatic scoring of exam answers
  - Rule-based + LLM-based hybrid evaluation
  - JSON result output
