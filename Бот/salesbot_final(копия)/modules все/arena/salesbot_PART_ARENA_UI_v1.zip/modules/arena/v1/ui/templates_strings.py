
BASE_HTML = """
<!doctype html>
<html><head>
<meta charset="utf-8"/>
<title>Arena UI</title>
<link rel="stylesheet" href="/arena/v1/ui/static/arena_ui.css"/>
</head><body>
<div class="container">
{content}
</div>
</body></html>
"""

SESSION_HTML = """
<!doctype html>
<html><head>
<meta charset="utf-8"/>
<title>Arena Session</title>
<link rel="stylesheet" href="/arena/v1/ui/static/arena_ui.css"/>
<script>
async function sendTurn(e){
  e.preventDefault();
  const sid = document.getElementById('sid').value;
  const text = document.getElementById('msg').value;
  document.getElementById('msg').value = "";
  const res = await fetch(`/arena/v1/handle/${'{'}sid{'}'}`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({text})});
  const data = await res.json();
  if(data && data.client_reply){
    location.reload();
  }
}
async function stopSession(){
  const sid = document.getElementById('sid').value;
  const res = await fetch(`/arena/v1/stop/${'{'}sid{'}'}`, {method:'POST'});
  const data = await res.json();
  alert('Финальный отчёт сформирован. Score: ' + ((data.final && data.final.score) || '—'));
  location.href = '/mini/brand/hub';
}
</script>
</head><body>
<div class="container">
  <div class="topbar">
    <div class="brand">На Счастье — Arena</div>
    <div class="meta">Менеджер: <b>{manager_id}</b> • Сессия: <code>{sid}</code></div>
  </div>
  {content}
</div>
</body></html>
"""
