# AI Coach Review
Part **W** · objections/v3

Пост-анализ диалога: краткое ревью шага возражений, что улучшить, примеры формулировок.

## How it works
- `routes.py` exposes fastapi routes under `/objections/v3/part_W_coach_review`
- `service.py` hosts orchestration and calls LLM through `deepllm.py`
- `prompts/` houses system/assistant/user templates
- `data/` contains seed dialogues (jsonl) and eval checks
- `tests/` has smoke tests for routing & generation

## Env
- `DEEPSEEK_API_KEY` required (read from `os.environ`).