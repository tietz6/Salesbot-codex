
import os, json, random, time
from ..deepseek_pipeline.client import DeepSeekClient
from ..persona_layer.formatter import apply_persona

class DeepSeekPipeline:
    def __init__(self):
        self.client = DeepSeekClient()

    def chat(self, system: str, history):
        try:
            out = self.client.chat(system=system, messages=history)
            if not out:
                raise RuntimeError("empty")
            return apply_persona("client_emotional", out)
        except Exception:
            # fallback
            txts = [
                "Понимаю вас. Давайте подберём то, что по-настоящему отзовётся. ",
                "Звучит важно. Подскажите, для кого готовите подарок — и что хочется передать? "
            ]
            return apply_persona("client_emotional", random.choice(txts))

    def coach_suggest(self, stage: str, manager_text: str):
        prompt = f"Короткий тёплый совет менеджеру на этапе {stage}. Реплика: {manager_text}"
        try:
            out = self.client.chat(system="Ты тёплый коуч бренда.", messages=[{"role":"user","content":prompt}])
            return apply_persona("coach", out)
        except Exception:
            return apply_persona("coach", "Хорошо держишь тон. Добавь 1 уточняющий вопрос и мягко подсвети ценность.")
