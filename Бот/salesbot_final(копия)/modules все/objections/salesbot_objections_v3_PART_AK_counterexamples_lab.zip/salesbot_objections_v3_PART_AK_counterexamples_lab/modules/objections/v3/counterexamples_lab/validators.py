
import re

def basic_penalties(text: str):
    p = text.strip().lower()
    penalties = []
    if len(p) < 6:
        penalties.append("too_short")
    if not re.search(r"[?]", p):
        penalties.append("no_question")
    if re.search(r"[!]{2,}|[?]{2,}", p):
        penalties.append("many_punct")
    if re.search(r"\b(бери|давай оплату|быстрее)\b", p):
        penalties.append("pushy_tone")
    return penalties
