# Objections v3 — скелет + базовые данные
