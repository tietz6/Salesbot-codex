
# Value Engine — semantic upsell evaluator (LLM-ready hooks)
def compute_value_score(context: dict):
    base = 50
    if context.get("client_interest"): base += 15
    if context.get("emotional_hook"): base += 20
    if context.get("budget_fit"): base += 10
    return min(base, 100)

def build_value_pitch(context: dict):
    name = context.get("name", "друг")
    benefit = context.get("benefit", "эмоциональная ценность")
    return f"Если говорить честно, {name}, этот вариант даёт самую сильную {benefit}. Хочешь покажу разницу?"
