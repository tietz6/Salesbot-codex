import json
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional
import time

try:
    from core.voice_gateway.v1 import VoicePipeline  # type: ignore
    _pipeline = VoicePipeline()
except Exception:
    _pipeline = None

@dataclass
class DemoItem:
    demo_id: str
    url: str
    preview_s: int = 50
    notes: Optional[str] = None

class DemoManager:
    def __init__(self, state_store):
        self.kv = state_store

    def _k(self, sid: str) -> str:
        return f"mp_demo:{sid}"

    def _load(self, sid: str) -> Dict[str, Any]:
        raw = self.kv.get(self._k(sid))
        if not raw:
            return {"stage": "idle", "history": [], "demos": {}, "selected": None}
        try:
            return json.loads(raw)
        except Exception:
            return {"stage": "idle", "history": [], "demos": {}, "selected": None}

    def _save(self, sid: str, data: Dict[str, Any]) -> None:
        self.kv.set(self._k(sid), json.dumps(data, ensure_ascii=False))

    async def start(self, sid: str) -> Dict[str, Any]:
        data = {"stage": "ready", "history": [], "demos": {}, "selected": None, "ts": int(time.time())}
        self._save(sid, data)
        return {"ok": True, "stage": "ready"}

    async def push_demo(self, sid: str, demo_id: str, url: str, preview_s: int = 50, notes: Optional[str]=None) -> Dict[str, Any]:
        data = self._load(sid)
        data.setdefault("demos", {})
        data["demos"][demo_id] = asdict(DemoItem(demo_id, url, preview_s, notes))
        data["stage"] = "wait_feedback"
        data.setdefault("history", []).append({"t":"send_demo", "id": demo_id, "url": url, "ts": int(time.time())})
        self._save(sid, data)
        return {"ok": True, "next": "wait_feedback", "sent": demo_id}

    async def feedback(self, sid: str, demo_id: str, reaction: str, comment: Optional[str]=None) -> Dict[str, Any]:
        data = self._load(sid)
        data.setdefault("history", []).append({"t":"feedback", "id": demo_id, "reaction": reaction, "comment": comment, "ts": int(time.time())})
        self._save(sid, data)
        next_action = "send_next_or_fix"
        if reaction == "like" and len(data.get("demos", {})) >= 2:
            next_action = "propose_choice"
        return {"ok": True, "next": next_action}

    async def choose(self, sid: str, demo_id: str) -> Dict[str, Any]:
        data = self._load(sid)
        if demo_id not in data.get("demos", {}):
            return {"ok": False, "error": "unknown_demo"}
        data["selected"] = demo_id
        data["stage"] = "selected"
        data.setdefault("history", []).append({"t":"choose", "id": demo_id, "ts": int(time.time())})
        self._save(sid, data)
        return {"ok": True, "stage": "selected"}
