# PART K — Reports (data-only)
Схема отчёта + HTML/MD шаблоны + пример. Готово для рендера в mini_webkit/brand.
