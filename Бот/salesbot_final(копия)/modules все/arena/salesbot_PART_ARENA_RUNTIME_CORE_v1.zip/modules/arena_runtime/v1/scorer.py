from typing import List, Dict

def quick_score(history: List[Dict]) -> int:
    text = ' '.join([h.get('content','').lower() for h in history if h.get('role')=='manager'])
    score = 60
    if 'здравствуйте' in text or 'добрый день' in text: score += 5
    if 'расскажите' in text or 'история' in text: score += 5
    if 'два варианта' in text or 'демо' in text: score += 5
    return min(score, 100)
