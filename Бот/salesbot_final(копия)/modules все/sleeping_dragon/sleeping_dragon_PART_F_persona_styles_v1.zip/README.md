# PART F — Persona Styles
Стилизация голоса коуча и клиента для Sleeping Dragon.
