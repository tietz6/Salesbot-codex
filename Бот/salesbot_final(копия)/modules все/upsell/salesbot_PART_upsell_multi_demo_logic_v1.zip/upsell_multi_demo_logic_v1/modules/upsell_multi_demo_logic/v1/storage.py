
from __future__ import annotations
import os, json, time, uuid
from typing import Optional, Dict, Any

DATA_DIR = os.path.join(os.path.dirname(__file__), "data", "sessions")

def _path(sid: str) -> str:
    os.makedirs(DATA_DIR, exist_ok=True)
    return os.path.join(DATA_DIR, f"{sid}.json")

def create_session(manager_id: str) -> str:
    sid = str(uuid.uuid4())
    save_state(sid, {
        "sid": sid,
        "manager_id": manager_id,
        "created_at": int(time.time()),
        "history": [],
        "state": {
            "demos": {"A": None, "B": None},
            "selection": None,
            "offers": [],
            "score": 0
        }
    })
    return sid

def load_state(sid: str) -> Optional[Dict[str, Any]]:
    p = _path(sid)
    if not os.path.exists(p): return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def save_state(sid: str, data: Dict[str, Any]) -> None:
    p = _path(sid)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
